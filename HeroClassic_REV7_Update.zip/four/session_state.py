"""Diagnostic resume hints. Recorded state never authorizes a new entry/payment."""
import json
from datetime import datetime, timezone, timedelta
from pathlib import Path

FILE = Path(__file__).resolve().parent / 'four_session.json'
KST = timezone(timedelta(hours=9))

def read():
    try:
        data = json.loads(FILE.read_text(encoding='utf-8'))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError): return {}

def checkpoint(profile, charged=False, expected=None, completed=()):
    data = read()
    data[profile.profile_id] = dict(charged=bool(charged), expected=expected,
                                  completed=sorted(completed), at=datetime.now(KST).isoformat())
    temp = FILE.with_suffix('.tmp')
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    temp.replace(FILE)

def note(profile):
    item = read().get(profile.profile_id, {})
    return item if isinstance(item, dict) else {}
