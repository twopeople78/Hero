"""Local per-Windows-user encrypted Telegram credentials; never packaged."""
import base64,ctypes as c,json,re
from ctypes import wintypes as w
from pathlib import Path
PATH=Path(__file__).resolve().parent/'telegram_alerts.json'
class Blob(c.Structure):_fields_=[('size',w.DWORD),('data',c.POINTER(c.c_ubyte))]
def crypt(data,decrypt=False):
    lib=c.WinDLL('crypt32',use_last_error=True);kernel=c.WinDLL('kernel32',use_last_error=True)
    kernel.LocalFree.argtypes=[c.c_void_p];kernel.LocalFree.restype=c.c_void_p
    buf=c.create_string_buffer(data);src=Blob(len(data),c.cast(buf,c.POINTER(c.c_ubyte)));out=Blob()
    if decrypt:
        fn=lib.CryptUnprotectData
        fn.argtypes=[c.POINTER(Blob),c.c_void_p,c.c_void_p,c.c_void_p,c.c_void_p,w.DWORD,c.POINTER(Blob)]
        ok=fn(c.byref(src),None,None,None,None,1,c.byref(out))
    else:
        fn=lib.CryptProtectData
        fn.argtypes=[c.POINTER(Blob),w.LPCWSTR,c.c_void_p,c.c_void_p,c.c_void_p,w.DWORD,c.POINTER(Blob)]
        ok=fn(c.byref(src),'Chosun Telegram',None,None,None,1,c.byref(out))
    if not ok:raise OSError('Telegram 설정 암호화/복호화 실패')
    try:return c.string_at(out.data,out.size)
    finally:kernel.LocalFree(c.cast(out.data,c.c_void_p))
def validate(token,chat):
    if not re.fullmatch(r'[0-9]+:[A-Za-z0-9_-]{20,}',token):raise ValueError('봇 토큰 형식을 확인하세요.')
    if not re.fullmatch(r'-?[0-9]+',chat):raise ValueError('채팅 ID는 숫자로 입력하세요. 그룹 ID는 음수일 수 있습니다.')
def load(path=PATH):
    try:
        raw=json.loads(path.read_text(encoding='utf-8'))
        token=crypt(base64.b64decode(raw['token_encrypted']),True).decode()
        chat=str(raw['chat_id']);validate(token,chat)
        return dict(token=token,chat=chat,enabled=bool(raw.get('enabled',False)))
    except (OSError,ValueError,KeyError,TypeError,UnicodeError):return dict(token='',chat='',enabled=False)
def save(config,path=PATH):
    token=config['token'].strip();chat=config['chat'].strip();validate(token,chat)
    raw=dict(version=1,token_encrypted=base64.b64encode(crypt(token.encode())).decode(),chat_id=chat,enabled=bool(config['enabled']))
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(raw,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(path)
