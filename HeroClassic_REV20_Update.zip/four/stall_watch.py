"""Read-only five-minute monitoring. No focus, click, or extra screenshots."""
import hashlib,time
from datetime import datetime
from window_link import u,title
from game_actions import check_game_view
from status_board import profile_status
from telegram_sender import Sender
from telegram_config import load

class IncidentEngine:
    def __init__(self,threshold=300):self.threshold=threshold;self.items={};self.sequence=0
    def reset(self,index=None):
        if index is None:self.items.clear()
        else:self.items.pop(index,None)
    def suspend(self,index):
        item=self.items.get(index)
        if item and item['sent']:
            item['suspended']=True;item['healthy']=None
        else:self.items.pop(index,None)
    def feed(self,index,issue,detail,now,since=None):
        events=[];item=self.items.get(index)
        if item and item.pop('suspended',False):item['since']=now;item['healthy']=None
        if issue:
            if item is None:
                self.sequence+=1;item=dict(since=min(now,since) if since is not None else now,key=(index,self.sequence),sent=False,healthy=None);self.items[index]=item
            item['healthy']=None;item['issue']=issue;item['detail']=detail
            if now-item['since']>=self.threshold and not item['sent']:
                item['sent']=True;events.append(('alert',item['key'],issue,detail,int(now-item['since'])))
        elif item:
            if item['healthy'] is None:item['healthy']=now
            if now-item['healthy']>=20:
                if item['sent']:events.append(('recovery',item['key'],'이전 경고 조건 해소',detail,int(now-item['since'])))
                self.items.pop(index,None)
        return events

CRITICAL=('death_runner','observation_menu_runner','entry_runner','recovery_runner','special_runner','supply_runner','general_runner','npc_runner','store_runner','jumo_runner','buy_runner','auto_runner')

def busy_problem(app,index):
    p=app.profiles[index];q=app.work_coordinator
    if getattr(p.daily_scheduler,'failed',False):return True
    if q.active and q.current and q.current['index']==index:return True
    if any(request['index']==index for request in q.pending):return True
    if any(getattr(getattr(p,name,None),'active',False) for name in CRITICAL):return True
    for name in ('cycle_runner','event_runner'):
        runner=getattr(p,name,None)
        if runner and runner.active and runner.phase!='observe':return True
        if runner and getattr(runner,'transition_pending',False):return True
    scheduler=getattr(p,'event_scheduler',None)
    return bool(scheduler and getattr(scheduler,'return_check',None))

def note_frame(owner,image,scope='field',hunting=False):
    """Use frames already captured by hunt logic; never request foreground."""
    watch=getattr(owner.winfo_toplevel(),'stall_watch',None)
    if watch is None or not watch.config['enabled']:return
    now=time.monotonic();owner.monitor_recognized_at=now
    if not hunting:return
    if scope=='hud':sample=image.crop((580,72,645,110)).resize((65,38))
    else:sample=image.crop((175,140,570,500)).resize((96,64))
    digest=hashlib.blake2b(sample.convert('RGB').tobytes(),digest_size=16).digest()
    frames=getattr(owner,'monitor_frames',{});old=frames.get(scope)
    changed=now if old is None or old[0]!=digest else old[1]
    frames[scope]=(digest,changed,now);owner.monitor_frames=frames

class StallWatch:
    def __init__(self,app):
        self.app=app;self.config=load();self.sender=Sender();self.engine=IncidentEngine()
        self.started={};self.work_since={};self.hidden_since={};self.job=None;self.closed=False
        self.status='Telegram 미설정' if not self.config['token'] else 'Telegram 알림 켜짐' if self.config['enabled'] else 'Telegram 알림 꺼짐'
        self.job=app.after(1000,self.tick)
    def configure(self,config):
        self.sender.cancel();self.config=dict(config);self.reset()
        self.status='Telegram 알림 켜짐 · 5분 지연 감시' if config['enabled'] else 'Telegram 알림 꺼짐'
    def reset(self):
        self.engine.reset();self.started.clear();self.work_since.clear();self.hidden_since.clear()
    def pause(self):self.sender.cancel();self.reset()
    def classify(self,index,now):
        p=self.app.profiles[index];base=self.started.setdefault(index,now)
        hwnd=p.window_link.hwnd
        if not hwnd or not u.IsWindow(hwnd) or title(hwnd).strip().lower()!='heroofchosunclassic':return '게임 연결 끊김','연결된 게임 창을 찾을 수 없음',now
        # Without a verified foreground, uncovered game, lack of progress
        # is not evidence of a fault. Do not alert merely for unavailable pixels.
        try:check_game_view(hwnd)
        except RuntimeError:return 'OBSERVATION_PAUSED','다른 창 가림·비활성화·최소화로 경고 판정 대기',now
        if busy_problem(self.app,index):
            start=self.work_since.setdefault(index,now)
            return '진행 지연',profile_status(self.app,index),start
        self.work_since.pop(index,None)
        recognized=max(getattr(p,'monitor_recognized_at',base),base)
        observing=any(getattr(getattr(p,name,None),'active',False) and getattr(getattr(p,name,None),'phase','')=='observe'
                      for name in ('cycle_runner','event_runner'))
        if observing and now-recognized>45:return '게임 상태 판독 불가','화면에서 사냥·복귀 상태 확인이 지연됨',recognized
        for digest,changed,seen in getattr(p,'monitor_frames',{}).values():
            if now-seen<=45 and now-max(changed,base)>=300:return '화면 정지 의심','관찰 가능한 사냥 화면이 5분 이상 동일함 · 실제 멈춤인지 확인 필요',max(changed,base)
        return None,profile_status(self.app,index),now
    def tick(self):
        self.job=None
        if self.closed:return
        try:
            while not self.sender.results.empty():
                ok,message=self.sender.results.get_nowait();self.status=message
            now=time.monotonic()
            for index,p in enumerate(self.app.profiles):
                if not self.config['enabled'] or not p.daily_scheduler.active:
                    self.engine.reset(index);self.started.pop(index,None);self.work_since.pop(index,None);self.hidden_since.pop(index,None);continue
                issue,detail,since=self.classify(index,now)
                if issue=='OBSERVATION_PAUSED':
                    item=self.engine.items.get(index)
                    if item and not self.sender.was_delivered(item['key']):self.engine.reset(index)
                    else:self.engine.suspend(index)
                    self.started[index]=now;self.work_since.pop(index,None)
                    self.hidden_since[index]=now
                    self.sender.pause_profile(index)
                    continue
                if index in self.hidden_since:
                    self.hidden_since.pop(index,None);self.started[index]=now
                    self.work_since.pop(index,None)
                    p.monitor_frames={}
                    # Fresh five-minute window after becoming observable again.
                    issue,detail,since=self.classify(index,now)
                self.sender.resume_profile(index)
                if issue is None and now-getattr(p,'monitor_recognized_at',-1e9)>30:
                    # Visibility alone is not a confirmed recovery.
                    continue
                # Work/visibility duration is measured by the engine from its first observation.
                events=self.engine.feed(index,issue,detail,now,since)
                for kind,key,reason,detail,elapsed in events:
                    label=p.display_name;stamp=datetime.now().strftime('%m/%d %H:%M:%S')
                    text=('【게임 자동화 경고】' if kind=='alert' else '【게임 자동화 경고 해소】')+'\n'+stamp+' · '+label+'\n'+reason+'\n'+detail+'\n지연 관찰: '+str(elapsed//60)+'분'
                    self.sender.enqueue(self.config['token'],self.config['chat'],text,kind,key)
        except Exception:
            self.status='Telegram 감시 검사 오류 · 게임 자동화는 계속 진행'
        finally:
            if not self.closed:self.job=self.app.after(10000,self.tick)
    def close(self):
        self.closed=True;self.sender.close()
        if self.job is not None:self.app.after_cancel(self.job);self.job=None
