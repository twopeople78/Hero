"""Serialized grave revival and verified free-only restoration for one profile."""
from PIL import Image
from pathlib import Path
from datetime import datetime
import time
from runner_timer import runner_after,invalidate
from focus_guard import lock,unlock
from runner_focus import ensure_view
from window_link import capture
from game_actions import check_game_view,click_client_point
from vision import from_capture,auto_control,town,general_location,special_hud_timer
import death_vision as vision


def intercept(owner,image):
    if not isinstance(image,Image.Image):return False
    runner=getattr(owner,'death_runner',None)
    return runner.observe(image) if runner is not None else False


def route_plan(owner,image):
    event=getattr(owner,'event_runner',None)
    if event is not None and event.active and getattr(event,'event',None) is not None:
        return ('event',event.event,event.end)
    if general_location(image,owner.general_key)>=.82:
        return ('general',None,None)
    cycle=getattr(owner,'cycle_runner',None)
    from session_state import note,KST
    saved=note(owner)
    kind=getattr(owner,'last_hunt_kind',None)
    if kind is None and str(saved.get('last_hunt_at','')).startswith(datetime.now(KST).date().isoformat()):kind=saved.get('last_hunt_kind')
    if kind=='event':
        from event_schedule import events_for,end_at
        now=owner.event_scheduler.now()
        current=next((e for e in events_for(owner,now.date()) if e.start<=now.time()<e.end),None)
        if current is not None:return ('event',current,end_at(current,now))
    if (cycle is not None and cycle.active) or special_hud_timer(image)>=.78 or kind=='special':
        return ('special',getattr(cycle,'current_expected',None),None)
    return ('general',None,None)


class DeathRunner:
    def __init__(self,owner):
        self.owner=owner;self.active=False;self.queued=False;self.job=None;self.phase='idle'
        self.hold=False
    def stop(self):
        unlock(self);invalidate(self);self.active=False;self.queued=False
        if self.job is not None:self.owner.after_cancel(self.job);self.job=None
    def log(self,text):
        self.owner.town_log('[사망·복구] '+text)
        try:
            folder=Path(__file__).resolve().parent/'diagnostics';folder.mkdir(exist_ok=True)
            with (folder/'death_recovery.log').open('a',encoding='utf-8') as stream:
                stream.write(f'{datetime.now():%Y-%m-%d %H:%M:%S} [{self.owner.profile_id}] 창{self.owner.window_link.hwnd} {self.phase} {text}\n')
        except OSError:pass
    def observe(self,image):
        if self.active or self.queued or self.hold:return True
        dead,_=vision.death_screen(image)
        if not dead:return False
        if not self.owner.daily_scheduler.active:
            self.owner.stop()
            self.log('사망 확인 · 자동화 꺼짐 · AUTO/이동 입력 취소, 자동 부활은 예약을 켠 뒤 진행')
            return True
        plan=route_plan(self.owner,image)
        app=self.owner.winfo_toplevel();index=app.profiles.index(self.owner)
        # Only this character is preempted. Other characters retain their hunts.
        self.owner.stop();app.work_coordinator.cancel_profile(index)
        self.queued=True
        self.log('사망 제목·무덤 부활 버튼 확인 → 기존 조작 취소 · 무덤 부활·무료 복구 대기')
        app.work_coordinator.submit(index,'사망 부활·무료 복구',lambda:self.start(plan),
            lambda text:self.fail(text),scheduled=True,priority=True)
        return True
    def start(self,plan):
        self.stop();self.hold=False;self.plan=plan;self.handle=self.owner.window_link.hwnd
        self.active=True;self.phase='revive';self.hits=0;self.tab=0;self.actions=0
        self.last_key=None;self.confirm_owned=False;self.confirm_sent=False
        self.restored=0;self.skipped=[];self.deadline=time.monotonic()+240
        self.limit=time.monotonic()+35;self.hidden_since=None;self.focus_retry_at=0
        self.revived=False;self.reopens=0
        try:lock(self)
        except RuntimeError as exc:self.fail(str(exc));return
        self.log('사망 화면 재검증 시작 · 무료복구만 사용 · 복구권·다이아 사용 없음')
        self.job=runner_after(self,800,self.tick)
    def stable(self,key,valid):
        self.hits=self.hits+1 if valid and key==self.last_key else 1 if valid else 0
        self.last_key=key
        return self.hits>=2
    def change(self,phase,seconds=25):
        self.phase=phase;self.hits=0;self.last_key=None;self.limit=time.monotonic()+seconds
    def later(self):
        self.job=runner_after(self,900,self.tick)
    def click(self,x,y,phase):
        if self.actions>=65:raise RuntimeError('복구 조작 횟수 제한 · 추가 입력 없음')
        click_client_point(self.handle,x/800,y/600);self.actions+=1;self.change(phase)
    def fail(self,text,image=None):
        self.stop();self.hold=True;self.last_error=text;self.log('복구 보류 · '+text+' · 해당 캐릭터 추가 입력 없음')
        if image is not None:
            try:
                folder=Path(__file__).resolve().parent/'diagnostics';folder.mkdir(exist_ok=True)
                image.save(folder/f'{datetime.now():%Y%m%d_%H%M%S}_{self.owner.window_link.hwnd}_death.png')
            except OSError:pass
    def next_tab(self):
        if self.tab==0:self.tab=1;self.change('switch_tab')
        else:self.change('close')
    def resume(self,image):
        plan=self.plan;owner=self.owner;app=owner.winfo_toplevel();index=app.profiles.index(owner)
        self.stop();self.log('무료 복구 화면 종료 확인 → '+('특수지역 남은 시간 재검사' if plan[0]=='special' else '이벤트 예약 재검사' if plan[0]=='event' else '설정 일반사냥터')+' 연결'+(' · 무료 복구 불가 항목 보류' if self.skipped else ''))
        app.work_coordinator.cancel_events(index)
        scheduler=owner.event_scheduler
        # An old return check cannot replace the restored hunt.
        scheduler.return_check=None;scheduler.return_check_queued=False;scheduler.return_check_at=None
        if plan[0]=='special':
            app.launch_remaining(index,scheduled=True)
        elif plan[0]=='event' and scheduler.active:
            scheduler.session=None
            scheduler.recheck_from_field('town')
            if not any(e.start<=scheduler.now().time()<e.end for e in __import__('event_schedule').events_for(owner,scheduler.now().date())):
                app.launch_general(index)
        else:app.launch_general(index)
    def tick(self):
        self.job=None
        if not self.active:return
        image=None
        try:
            if self.handle!=self.owner.window_link.hwnd:raise RuntimeError('연결 창 변경')
            if not ensure_view(self,check_game_view):self.later();return
            image=from_capture(capture(self.handle));now=time.monotonic()
            if now>self.deadline or now>self.limit:raise RuntimeError(self.phase+' 화면 확인 시간 초과')
            dead,grave=vision.death_screen(image)
            panel,exp,items,close=vision.panel(image)
            modal=vision.confirmation_visible(image)
            if modal and self.phase not in ('payment_wait','confirm','verify'):
                raise RuntimeError('직접 시작하지 않은 복구 확인창 · 자동 승인하지 않음')
            if self.phase=='revive':
                if dead:
                    if self.stable('grave',True):
                        self.click(grave[1],grave[2],'revive_wait');self.log('무덤에서 부활 위치 검증 → 1회 클릭')
                elif panel:
                    if self.stable('panel',True):self.change('switch_tab')
                else:
                    icon=vision.restoration_icon(image)
                    if self.stable('restoration_icon',icon[0]>=.90):self.click(icon[1],icon[2],'panel_wait')
            elif self.phase in ('revive_wait','open'):
                if not dead and panel:
                    if self.stable('panel',True):self.change('switch_tab')
                elif not dead:
                    icon=vision.restoration_icon(image)
                    if self.stable('restoration_icon',icon[0]>=.90):
                        self.click(icon[1],icon[2],'panel_wait');self.log('부활 후 복구 아이콘 검증 → 복구 패널 열기')
            elif self.phase=='panel_wait':
                if self.stable('panel',panel):self.change('switch_tab')
            elif self.phase in ('switch_tab','tab_wait'):
                key='exp' if self.tab==0 else 'items';button=exp if self.tab==0 else items
                if panel and vision.selected_tab(image,key):
                    if self.stable(key,True):self.change('scan')
                elif self.phase=='switch_tab' and panel and self.stable('tab_button',button[0]>=.88):
                    self.click(button[1],button[2],'tab_wait')
            elif self.phase=='scan':
                if not panel:raise RuntimeError('복구 패널을 찾을 수 없음')
                if self.restored>=20:raise RuntimeError('무료 복구 처리 횟수 제한')
                present=vision.row_present(image)
                if not present and self.stable('empty',True):
                    self.log(('경험치' if self.tab==0 else '아이템')+' 복구 목록 없음 → 다음 단계');self.next_tab()
                elif present:
                    quota=vision.restoration_count(image,'free')
                    if quota is None:
                        if self.tab==1 and vision.free_button(image)[0]<.88:
                            if self.stable('items_not_free',True):
                                self.skipped.append(self.tab);self.log('아이템 무료복구 수단 확인 안 됨 → 유료 복구 없이 보류');self.next_tab()
                            self.later();return
                        raise RuntimeError('무료복구 남은 횟수 판독 불가 · 횟수를 0이나 양수로 추정하지 않습니다.')
                    if quota==0:
                        if self.stable('no_free',True):
                            self.skipped.append(self.tab);self.log('무료 0회 확인 → 추가 복구 중단 · 복구권·재화 사용 없이 다음 탭 확인');self.next_tab()
                        self.later();return
                    self.last_quota=quota
                    free=vision.free_button(image)
                    if free[0]<.88:raise RuntimeError('무료 횟수 양수이나 무료복구 버튼 활성화 확인 미달')
                    elif vision.selection_ready(image):
                        if self.stable('free',True):
                            self.click(free[1],free[2],'payment_wait');self.confirm_owned=True;self.confirm_sent=False
                            self.log(f'무료복구 {quota}회 양수 확인 → 무료 버튼 1회 클릭 · 복구권 비용 0·무료 차감 1 검증 대기')
                    elif self.stable('select_row',True):self.click(110,55,'selection_wait')
            elif self.phase=='payment_wait':
                if modal:
                    self.change('confirm')
                elif panel:
                    quota=vision.restoration_count(image,'free')
                    batch=vision.batch_button(image)
                    if self.stable('free_payment_then_batch',quota is not None and quota>0 and batch[0]>=.90):
                        self.last_quota=quota
                        self.click(batch[1],batch[2],'confirm');self.confirm_owned=True;self.confirm_sent=False
                        self.log('무료복구 선택 후 일괄복구 활성화 확인 → 일괄복구 1회 클릭')
            elif self.phase=='selection_wait':
                if self.stable('selected',panel and vision.selection_ready(image)):self.change('scan')
            elif self.phase=='confirm':
                safe,button,scores=vision.free_confirmation(image)
                if modal and not safe:self.log('비용 0·무료 횟수 문구 검증 대기 '+str(scores))
                if self.confirm_owned and not self.confirm_sent and self.stable('free_zero_confirm',safe):
                    # Mark dispatch first. No confirmation retries after uncertainty.
                    self.confirm_sent=True
                    self.click(button[1],button[2],'verify')
                    self.log('무료복구 횟수 차감·비용 0·확인 버튼 연속 검증 → 확인 1회')
            elif self.phase=='verify':
                if self.stable('confirmed',not modal and panel and (not vision.row_present(image) or (vision.restoration_count(image,'free') is not None and vision.restoration_count(image,'free')<self.last_quota))):
                    self.restored+=1;self.confirm_owned=False;self.change('scan')
                    self.log('확인창 닫힘 연속 확인 · 복구 목록 재검사')
            elif self.phase=='close':
                if panel and self.stable('close_panel',close[0]>=.88):self.click(close[1],close[2],'closed')
            elif self.phase=='closed':
                field=auto_control(image)[0]>=.78 and not panel and not dead and not modal
                icon=vision.restoration_icon(image)[0]
                if field and icon>=.90 and not self.skipped:
                    if self.stable('remaining_icon',True):
                        if self.reopens>=2:raise RuntimeError('복구 후에도 복구 아이콘이 남음 · 추가 복구 재검사 한도')
                        self.reopens+=1;self.tab=0
                        point=vision.restoration_icon(image)
                        self.click(point[1],point[2],'panel_wait')
                        self.log('복구 아이콘 잔존 → 경험치·아이템 두 탭 재검사')
                elif self.stable('field',field and (icon<.85 or bool(self.skipped))):
                    self.log('복구 아이콘 소멸 확인' if icon<.85 else '무료복구 불가 항목으로 아이콘 잔존 · 복구권 사용 없이 사냥 복귀')
                    self.resume(image);return
            self.later()
        except Exception as exc:self.fail(str(exc),image)
