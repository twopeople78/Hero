from admin_launch import BUILD, is_admin, launch_as_admin
import sys
import time
from pathlib import Path

if __name__ == "__main__" and not launch_as_admin(__file__):
    raise SystemExit(0)

import ctypes
try:
    ctypes.WinDLL('user32',use_last_error=True).SetProcessDpiAwarenessContext(ctypes.c_void_p(-4))
except (AttributeError,OSError):
    try: ctypes.WinDLL('user32').SetProcessDPIAware()
    except (AttributeError,OSError): pass

import tkinter as tk
from tkinter import ttk
from datetime import datetime
from window_link import WindowLink, windows, bounds
from npc_runner import NpcRunner
from store_runner import StoreRunner
from buy_runner import BuyRunner
from special_runner import SpecialRunner
from entry_runner import EntryRunner
from auto_runner import AutoRunner
from cycle_runner import CycleRunner
from general_runner import GeneralRunner
from dual_runner import DualRunner
from focus_runner import FocusRunner
from supply_runner import SupplyRunner
from daily_scheduler import DailyScheduler,KST
from work_coordinator import WorkCoordinator
from event_runner import EventRunner
from event_schedule import EventScheduler
from recovery_runner import RecoveryRunner
from observation_menu import ObservationMenuRunner
from reconnect_watch import ReconnectWatch
from startup_resume import resume_route as resume_startup_route
from status_board import profile_status
from button_feedback import refresh_buttons
from profile_settings import load_routes,save_routes,PROFILE_SPECS,DESTINATIONS
import profile_settings
import session_state
from tkinter import messagebox
from stall_watch import StallWatch
from desktop_tray import DesktopTray
from telegram_settings import open_settings as open_telegram_settings

ROUTES = [('영혼의 동굴', '2층'), ('부패한 도성', '4층'), ('행주산성', '3층'), ('전리품 매립지', '3층'), ('조선왕릉', '1층')]

class Profile(ttk.Frame):
    def __init__(self, parent, name, profile_id):
        super().__init__(parent)
        self.profile_id=profile_id
        self.display_name=name
        saved=profile_settings.get(profile_id)
        self.configured=bool(saved.get('configured',False))
        self.selected_events=set(saved.get('events',[])) & {'abandoned','gadeok','nijo'}
        self.routes = load_routes(ROUTES,profile_id)
        self.floor_vars=[tk.StringVar(value=floor) for name,floor in self.routes]
        self.floor_note=tk.StringVar(value='층 변경은 자동 저장되며 다음 입장부터 적용됩니다. 현재 사냥 중인 층은 유지합니다.')
        self.floor_summary=tk.StringVar(value='입장 층 설정 · '+' / '.join(name+' '+floor for name,floor in self.routes[:3])+'\n'+' / '.join(name+' '+floor for name,floor in self.routes[3:]))
        self.general_key = saved.get('general','wol')
        if self.general_key not in DESTINATIONS:self.general_key='wol'
        self.destination,self.travel=DESTINATIONS[self.general_key]
        self.resume_mode=tk.StringVar(value='기본 순회')
        self.resume_region=tk.StringVar(value=self.routes[0][0])
        self.resume_applied=False
        self.startup_unresolved=False
        self.confirmed_field=None
        self.pending = None
        self.index = 0
        self.running = False
        self.return_mode = False
        self.map_trial = False
        self.map_method = 'key'
        self.town_target = None
        self.town_selected_at = 0
        self.town_job = None
        self.npc_runner = NpcRunner(self)
        self.jumo_runner = NpcRunner(self, kind="jumo")
        self.auto_jumo = tk.BooleanVar(value=True)
        self.store_runner = StoreRunner(self)
        self.buy_runner = BuyRunner(self)
        self.special_runner = SpecialRunner(self)
        self.entry_runner = EntryRunner(self)
        self.auto_runner = AutoRunner(self)
        self.recovery_runner = RecoveryRunner(self)
        self.observation_menu_runner = ObservationMenuRunner(self)
        self.reconnect_watch = ReconnectWatch(self)
        self.cycle_runner = CycleRunner(self)
        self.general_runner = GeneralRunner(self)
        self.supply_runner = SupplyRunner(self)
        self.event_runner=EventRunner(self)
        self.event_scheduler=EventScheduler(self)
        self.event_enabled=tk.BooleanVar(value=bool(self.selected_events))
        self.event_status=tk.StringVar(value='이벤트 예약 꺼짐')
        self.daily_scheduler = DailyScheduler(self)
        self.reservation_status = tk.StringVar(value="매일 예약 꺼짐")
        self.auto_enter = tk.BooleanVar(value=True)
        self.auto_buy = tk.BooleanVar(value=True)
        self.auto_store = tk.BooleanVar(value=True)
        style = ttk.Style(self)
        style.theme_use('clam')
        style.configure('.', font=('맑은 고딕', 10))
        style.configure('TFrame', background='#171d28')
        style.configure('TLabel', background='#171d28', foreground='#e5eaf2')
        style.configure('Title.TLabel', font=('맑은 고딕', 18, 'bold'))
        style.configure('Sub.TLabel', foreground='#a9b5c9')
        style.configure('TButton', padding=9)
        style.configure('Treeview', rowheight=31, background='#222c3b', fieldbackground='#222c3b', foreground='#edf2fa')
        self.status = tk.StringVar(value='대기 중 · 위에서 실행 모드를 선택하세요.')
        self.supply = tk.StringVar(value='04:50')
        self.start = tk.StringVar(value='05:01')
        self.auto_npc = tk.BooleanVar(value=True)
        self.scroll_canvases = []
        pages = ttk.Notebook(self)
        self.pages = pages
        pages.pack(fill='both', expand=True)
        dashboard_page = ttk.Frame(pages)
        settings_page = ttk.Frame(pages)
        diagnostics_page = ttk.Frame(pages)
        pages.add(dashboard_page, text='진행 현황')
        pages.add(settings_page, text='설정')
        pages.add(diagnostics_page, text='실행 기록')
        main, self.canvas = self.scrolled_body(dashboard_page)
        settings,self.settings_canvas=self.scrolled_body(settings_page)
        diagnostics, self.diagnostic_canvas = self.scrolled_body(diagnostics_page)
        self.bind_all('<MouseWheel>', self.scroll_wheel, add='+')

        ttk.Label(settings,text='게임 창 연결',font=('맑은 고딕',12,'bold')).pack(anchor='w')
        self.window_link = WindowLink(settings, profile=self)
        self.window_link.pack(fill='x',pady=(4,6))
        ttk.Button(settings,text='이 캐릭터 예약 켜기',command=lambda:self.winfo_toplevel().arm_daily(self.winfo_toplevel().profiles.index(self))).pack(anchor='w',pady=3)
        ttk.Button(settings,text='이 캐릭터만 정지',command=self.stop_profile).pack(anchor='w',pady=(0,12))
        summary=ttk.LabelFrame(main,text='선택 캐릭터의 입장 설정',padding=12,style='Panel.TLabelframe')
        self.destination_text=tk.StringVar(value='일반사냥 목적지 · '+self.destination)
        ttk.Label(summary,textvariable=self.destination_text,style='Sub.TLabel',wraplength=900).pack(anchor='w')
        ttk.Label(summary,textvariable=self.floor_summary,style='Sub.TLabel',wraplength=900).pack(anchor='w',pady=(6,0))
        ttk.Label(main,text='수동 실행 · 선택한 캐릭터에 적용',font=('맑은 고딕',12,'bold')).pack(anchor='w',pady=(0,8))
        self.shared_status_labels=self.winfo_toplevel().shared_status_labels
        self.quick_status=self.shared_status_labels[int(profile_id[-1])-1]
        self.tree = ttk.Treeview(diagnostics, columns=('time','place','action','state'), displaycolumns=('place','state'), show='headings', height=8, selectmode='browse')
        for key,title,width in [('time','시간',100),('place','설정 지역 / 대상',430),('action','동작',300),('state','이번 실행 기록',190)]:
            self.tree.heading(key,text=title)
            self.tree.column(key,width=width,stretch=key=='place')
        self.rows = [self.tree.insert('', 'end', values=('04:50','한밭마을 · 복자할매','창고 → 자동 보관 → 확인 → 닫기','미확인')),
                     self.tree.insert('', 'end', values=('보관 후','한밭마을 · 주모','자동 구매 → 확인 → 닫기','미확인'))]
        for i,(place,floor) in enumerate(self.routes):
            self.rows.append(self.tree.insert('', 'end', values=('05:01' if i==0 else '복귀 확인 후',f'{i+1}. {place} {floor}','입장 → AUTO → 시간 소진 → 복귀','미확인')))
        self.rows.append(self.tree.insert('', 'end', values=('전체 완료 후',self.destination,self.travel,'미확인')))
        self.action_buttons={}
        general_controls = ttk.Frame(main)
        general_controls.pack(fill='x', pady=(0,8))
        for key,method in [('START','launch_full_route'),('상점창고','launch_supply_only'),('특수지역','launch_remaining'),('일반사냥','launch_general')]:
            button=ttk.Button(general_controls,text=key,width=13,command=lambda method=method:getattr(self.winfo_toplevel(),method)(self.winfo_toplevel().profiles.index(self)))
            button.pack(side='left',padx=(0,8))
            self.action_buttons[key]=button
        ttk.Label(main,text='START: 보급부터 전체 흐름  ·  상점창고: 보급만  ·  특수지역: 남은 지역 진행  ·  일반사냥: 목적지 복귀',style='Sub.TLabel',wraplength=900).pack(anchor='w',pady=(0,16))
        summary.pack(fill='x',pady=(0,14))
        reservation_card=ttk.LabelFrame(main,text='예약 상태',padding=12,style='Panel.TLabelframe')
        reservation_card.pack(fill='x',pady=(0,14))
        ttk.Label(reservation_card,textvariable=self.reservation_status,style='Sub.TLabel',wraplength=900).pack(anchor='w')
        ttk.Label(reservation_card,textvariable=self.event_status,style='Sub.TLabel',wraplength=900).pack(anchor='w',pady=(8,0))
        ttk.Label(main,text='게임 창 연결 상태 · 연결 변경은 설정 탭에서 할 수 있습니다.',style='Sub.TLabel').pack(anchor='w')
        ttk.Label(main,textvariable=self.window_link.state,style='Sub.TLabel',wraplength=900).pack(anchor='w',pady=(3,0))
        ttk.Label(main,text=BUILD+' · 관리자 권한: '+('확인됨' if is_admin() else '없음'),style='Sub.TLabel').pack(anchor='w',pady=(8,0))

        ttk.Label(settings,text='캐릭터별 사냥 설정',style='Title.TLabel').pack(anchor='w',pady=(0,12))
        self.floor_selectors=[]
        for index,(place,floor) in enumerate(self.routes):
            row=ttk.Frame(settings);row.pack(anchor='w',pady=3)
            ttk.Label(row,text=place,width=20).pack(side='left')
            selector=ttk.Combobox(row,values=('1층','2층','3층','4층'),textvariable=self.floor_vars[index],state='readonly',width=7)
            selector.pack(side='left')
            selector.bind('<<ComboboxSelected>>',lambda event,index=index:self.change_floor(index))
            self.floor_selectors.append(selector)
        ttk.Label(settings,textvariable=self.floor_note,style='Sub.TLabel',wraplength=900).pack(anchor='w',pady=(4,8))
        ttk.Label(settings,text='일반사냥 목적지 · 현재 인식 자산이 있는 두 곳 중 선택').pack(anchor='w',pady=(8,4))
        self.destination_choice=tk.StringVar(value=self.destination)
        destination=ttk.Combobox(settings,values=[v[0] for v in DESTINATIONS.values()],textvariable=self.destination_choice,state='readonly',width=42)
        destination.pack(anchor='w')
        self.event_vars={}
        for key,text in [('abandoned','버려진 동굴 · 매일 16:00~17:00'),('gadeok','가덕도왜성 · 수요일 제외 20:00~22:00'),('nijo','저주받은 니조성 · 수요일 19:00~23:00')]:
            var=tk.BooleanVar(value=key in self.selected_events);self.event_vars[key]=var
            ttk.Checkbutton(settings,text=text,variable=var).pack(anchor='w',pady=2)
        ttk.Label(settings,text='프로그램 재시작 후 현재 추가 충전 사냥 중이면 아래에서 지역을 지정하세요.').pack(anchor='w',pady=(8,2))
        ttk.Combobox(settings,values=('기본 순회','추가 충전 중 · 종료 후 일반사냥'),textvariable=self.resume_mode,state='readonly',width=36).pack(anchor='w')
        ttk.Combobox(settings,values=[r[0] for r in self.routes],textvariable=self.resume_region,state='readonly',width=26).pack(anchor='w',pady=3)
        old=session_state.note(self)
        if old.get('charged'):
            ttk.Label(settings,text='이전 충전 사냥 기록이 있습니다. 현재 게임과 비교해 이어받기 모드를 직접 선택하세요.',wraplength=800).pack(anchor='w')
        ttk.Button(settings,text='이 캐릭터 설정 저장·확인',command=self.save_profile_settings).pack(anchor='w',pady=8)
        self.config_note=tk.StringVar(value='저장된 설정 있음 · 게임 창은 매 실행마다 직접 연결하세요.' if self.configured else '설정 미확인 · 층/일반 목적지/이벤트를 확인 후 저장하세요.')
        ttk.Label(settings,textvariable=self.config_note,wraplength=800).pack(anchor='w')
        ttk.Label(settings,text='매일 예약 시각 · 한국 시간',font=('맑은 고딕',12,'bold')).pack(anchor='w',pady=(18,8))
        times=ttk.Frame(settings)
        times.pack(fill='x')
        for label,var in [('보관·구매',self.supply),('특수지역',self.start)]:
            ttk.Label(times,text=label).pack(side='left',padx=(0,8))
            ttk.Entry(times,textvariable=var,width=8).pack(side='left',padx=(0,20))
        ttk.Label(settings,textvariable=self.reservation_status).pack(anchor='w')
        ttk.Label(settings,text='네 캐릭터 예약 가능 · 각 창의 지역·완료 상태를 따로 관리하며 실제 조작은 한 창씩 진행합니다.',style='Sub.TLabel',wraplength=900).pack(anchor='w',pady=4)
        ttk.Label(settings,text='특수지역 종료 후 다음 남은 지역 → 다섯 곳 완료 후 일반 사냥·AUTO',style='Sub.TLabel').pack(anchor='w',pady=4)
        ttk.Label(settings,text='이벤트 특수지역 · 일반 사냥에서 참여 후 일반 사냥 복귀',font=('맑은 고딕',12,'bold')).pack(anchor='w',pady=(12,4))
        def event_toggle():
            if self.event_enabled.get() and self.daily_scheduler.active:self.event_scheduler.arm()
            else:self.event_scheduler.stop()
        ttk.Checkbutton(settings,text='이벤트 예약 사용 · 현재 열려 있는 이벤트도 참여',variable=self.event_enabled,command=event_toggle).pack(anchor='w')
        ttk.Label(settings,text='위에서 저장한 캐릭터별 참여 이벤트만 예약합니다.').pack(anchor='w')

        ttk.Label(diagnostics,text='상세 기록',font=('맑은 고딕',12,'bold')).pack(anchor='w',pady=(14,4))
        self.log=tk.Text(diagnostics,height=12,bg='#101620',fg='#bcd0e9',relief='flat',font=('맑은 고딕',10),state='disabled')
        self.log.pack(fill='both',expand=True)
        self.log.configure(state='normal')
        self.log.insert('end',f'[실행 정보] {BUILD} · 관리자={is_admin()} · 파일={Path(__file__).resolve()} · Python={sys.executable}\n')
        self.log.configure(state='disabled')

    def stop_profile(self):
        app=self.winfo_toplevel()
        app.work_coordinator.cancel_profile(app.profiles.index(self))
        if app.focus_runner.active and getattr(app.focus_runner,'handle',None)==self.window_link.hwnd:app.focus_runner.stop()
        self.daily_scheduler.stop();self.stop()
        self.window_link.state.set('이 캐릭터 정지 · 다른 캐릭터 예약은 유지')

    def save_profile_settings(self):
        app=self.winfo_toplevel()
        if any(p.daily_scheduler.active for p in app.profiles) or app.work_coordinator.active or app.work_coordinator.pending or app.focus_runner.active or any(app.work_coordinator.busy(p) for p in app.profiles):
            self.config_note.set('자동화를 정지하고 진행 중인 조작이 끝난 뒤 설정을 저장하세요.');return
        key=next(k for k,v in DESTINATIONS.items() if v[0]==self.destination_choice.get())
        selected={k for k,v in self.event_vars.items() if v.get()}
        try:
            save_routes(self.routes,self.profile_id)
            profile_settings.update(self.profile_id,general=key,events=sorted(selected),configured=True)
        except OSError as exc:
            self.config_note.set('설정 저장 실패: '+str(exc));return
        self.general_key=key;self.destination,self.travel=DESTINATIONS[key]
        self.selected_events=selected;self.event_enabled.set(bool(selected));self.configured=True
        self.resume_applied=False
        self.destination_text.set('일반사냥 목적지 · '+self.destination)
        self.tree.set(self.rows[-1],'place',self.destination)
        self.tree.set(self.rows[-1],'action',self.travel)
        self.config_note.set('저장 완료 · '+self.display_name+' · '+self.destination)

    def change_floor(self,index):
        value=self.floor_vars[index].get()
        if value not in ('1층','2층','3층','4층'):
            self.floor_vars[index].set(self.routes[index][1]);return
        name,old=self.routes[index]
        self.routes[index]=(name,value)
        self.tree.set(self.rows[index+2],'place',f'{index+1}. {name} {value} · 입장 설정')
        expected=getattr(self.entry_runner,'expected',None) if self.entry_runner.active else getattr(self.cycle_runner,'current_expected',None) if self.cycle_runner.active else None
        if expected is not None and expected[0]==index and expected[2]!=value:
            self.tree.set(self.rows[index+2],'state',f'진행 {expected[2]} · 다음 {value}')
        self.floor_summary.set('입장 층 설정 · '+' / '.join(name+' '+floor for name,floor in self.routes[:3])+'\n'+' / '.join(name+' '+floor for name,floor in self.routes[3:]))
        try:
            save_routes(self.routes,self.profile_id)
            self.floor_note.set(name+' '+value+' 저장 완료 · 다음 입장부터 적용')
        except OSError:
            self.floor_note.set('설정 파일 저장 실패 · 현재 실행 중에는 적용되며 재실행 시 다시 설정하세요.')
        self.town_log('[층 설정] '+name+' '+old+' → '+value+' · 다음 입장부터 적용')

    def scrolled_body(self,parent):
        scroll=ttk.Scrollbar(parent,orient='vertical');scroll.pack(side='right',fill='y')
        canvas=tk.Canvas(parent,bg='#171d28',highlightthickness=0,yscrollcommand=scroll.set)
        canvas.pack(side='left',fill='both',expand=True);scroll.configure(command=canvas.yview)
        body=ttk.Frame(canvas,padding=16)
        content=canvas.create_window((0,0),window=body,anchor='nw')
        body.bind('<Configure>',lambda event:canvas.configure(scrollregion=canvas.bbox('all')))
        body.bind('<Configure>',lambda event:self.fit_wrapped_labels(body),add='+')
        canvas.bind('<Configure>',lambda event:canvas.itemconfigure(content,width=event.width))
        self.scroll_canvases.append(canvas)
        return body,canvas

    def fit_wrapped_labels(self,body):
        for child in body.winfo_children():
            if isinstance(child,ttk.Label) and int(child.cget('wraplength') or 0)>0:
                width=max(180,child.master.winfo_width()-28)
                if int(child.cget('wraplength') or 0)!=width:child.configure(wraplength=width)
            elif isinstance(child,(ttk.Frame,ttk.LabelFrame)):
                self.fit_wrapped_labels(child)

    def scroll_wheel(self,event):
        if not self.winfo_ismapped() or isinstance(event.widget,(tk.Text,ttk.Treeview,ttk.Combobox)):
            return
        current=event.widget
        while current is not None and current is not self:
            if current in self.scroll_canvases:
                current.yview_scroll(-int(event.delta/120),'units')
                return 'break'
            current=getattr(current,'master',None)

    def town_log(self, message, update_status=True):
        if update_status:self.status.set(message)
        self.log.configure(state='normal')
        self.log.insert('end', f'{datetime.now():%H:%M:%S}  [{self.profile_id}] {message}\n')
        self.log.see('end')
        self.log.configure(state='disabled')

    def stop(self, cancel_schedule=False):
        self.observation_menu_runner.stop()
        self.recovery_runner.stop()
        self.event_runner.stop()
        if hasattr(self, "supply_runner"):
            self.supply_runner.stop()
        if cancel_schedule and hasattr(self, "daily_scheduler"):
            self.daily_scheduler.stop()
        if hasattr(self, "general_runner"):
            self.general_runner.stop()
        if hasattr(self, "cycle_runner"):
            self.cycle_runner.stop()
            self.cycle_runner.general_pending=False
        if hasattr(self, "auto_runner"):
            self.auto_runner.stop()
        if hasattr(self, "entry_runner"):
            self.entry_runner.stop()
        if hasattr(self, "special_runner"):
            self.special_runner.stop()
        if hasattr(self, "buy_runner"):
            self.buy_runner.stop()
        if hasattr(self, "jumo_runner"):
            self.jumo_runner.stop()
        if hasattr(self, "store_runner"):
            self.store_runner.stop()
        if hasattr(self, "npc_runner"):
            self.npc_runner.stop()
        self.town_target = None
        if self.town_job:
            self.after_cancel(self.town_job)
            self.town_job = None
        if self.pending:
            self.after_cancel(self.pending)
            self.pending = None
        if self.running and self.index and not self.map_trial:
            self.index -= 1
            self.tree.set(self.rows[self.index], 'state', '정지')
        self.running = False
        self.map_trial = False
        self.status.set('관리 동작 정지 · 게임 AUTO는 그대로 유지됩니다.')

    def close(self):
        self.stop()
        self.destroy()

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f'HeroOfChosunClassic · 네 캐릭터 일정 관리 · {BUILD}')
        self.geometry('1040x800')
        self.minsize(960, 650)
        self.configure(bg='#171d28')
        self.focus_runner = FocusRunner(self)
        self.mode = tk.StringVar(value='대기 · 자동화 시작 전')
        self.automation_state='waiting'
        self.shared_status=[tk.StringVar(value='대기 중') for _ in range(len(PROFILE_SPECS))]
        self.window_switch_paused=tk.BooleanVar(value=False)
        saved_interval=profile_settings.get('_app').get('observation_switch_seconds',120)
        self.observation_interval_var=tk.StringVar(value=str(saved_interval if saved_interval in (30,60,120,180,300) else 120))
        ttk.Label(self,text='조선 사냥 관리',font=('맑은 고딕',16,'bold')).pack(anchor='w',padx=16,pady=(12,8))
        header=ttk.Frame(self,padding=(16,0,16,8));header.pack(fill='x')
        header.columnconfigure(0,weight=0,minsize=230)
        header.columnconfigure(1,weight=1)
        header.columnconfigure(2,weight=1)
        control=ttk.LabelFrame(header,text='자동화',padding=12,style='Dashboard.TLabelframe')
        control.grid(row=0,column=0,rowspan=2,sticky='nsew',padx=(0,10))
        self.automation_button=ttk.Button(control,text='4계정 자동화 · 대기',command=self.toggle_automation)
        self.automation_button.pack(fill='x')
        ttk.Button(control,text='화면 위치대로 4개 연결',command=self.connect_by_layout).pack(fill='x',pady=(8,0))
        ttk.Button(control,text='Telegram 알림 설정',command=lambda:open_telegram_settings(self)).pack(fill='x',pady=(10,0))
        ttk.Checkbutton(control,text='창 전환 일시정지',variable=self.window_switch_paused).pack(anchor='w',pady=5)
        ttk.Label(control,text='평소 창 전환 없음 · 실제 작업 때만 활성화',wraplength=205).pack(anchor='w',pady=(2,5))
        ttk.Button(control,text='전체 정지',command=self.stop_all).pack(fill='x')
        self.telegram_status=tk.StringVar(value='Telegram 미설정')
        self.shared_status_labels=[]
        for index,title in enumerate(name for _,name in PROFILE_SPECS):
            card=ttk.LabelFrame(header,text=title,padding=12,style='Dashboard.TLabelframe')
            card.grid(row=index//2,column=index%2+1,sticky='nsew',padx=(0,8),pady=(0,6))
            label=ttk.Label(card,textvariable=self.shared_status[index],style='Dashboard.TLabel',wraplength=310,justify='left')
            label.pack(fill='both',expand=True)
            card.bind('<Configure>',lambda event,label=label:label.configure(wraplength=max(180,event.width-28)))
            self.shared_status_labels.append(label)
        ttk.Label(self,textvariable=self.mode,style='Sub.TLabel',wraplength=960).pack(anchor='w',padx=16,pady=(0,8))
        notebook = ttk.Notebook(self)
        self.notebook = notebook
        notebook.pack(fill='both', expand=True)
        self.profiles = []
        for profile_id,name in PROFILE_SPECS:
            profile = Profile(notebook, name, profile_id)
            self.profiles.append(profile)
            notebook.add(profile, text=name)
        self.dual_runner = DualRunner(self)
        self.work_coordinator = WorkCoordinator(self)
        self.stall_watch=StallWatch(self)
        style=ttk.Style(self)
        style.configure('Dashboard.TLabelframe',background='#222c3b',bordercolor='#3b4b61',relief='solid')
        style.configure('Dashboard.TLabelframe.Label',background='#171d28',foreground='#bcd0e9',font=('맑은 고딕',10,'bold'))
        style.configure('Dashboard.TLabel',background='#222c3b',foreground='#edf2fa')
        style.configure('Panel.TLabelframe',background='#171d28',bordercolor='#354356',relief='solid')
        style.configure('Panel.TLabelframe.Label',background='#171d28',foreground='#a9b5c9')
        for name,color in [('Running.TButton','#237545'),('Waiting.TButton','#8a631d'),('Stopped.TButton','#9d3333')]:
            style.configure(name,background=color,foreground='white')
            style.map(name,background=[('pressed',color),('active',color)],foreground=[('active','white')])
        self.refresh_shared_status()
        notebook.bind('<<NotebookTabChanged>>', self.auto_connect)
        self.after_idle(self.auto_connect)
        self.bind('<Escape>', lambda event: self.stop_all())
        self.protocol('WM_DELETE_WINDOW', self.close)
        self.tray=DesktopTray(self)
        self.tray.update()
        if not self.tray.available:self.mode.set('트레이 사용 불가 · 일반 최소화로 사용하세요. 자동화 기능은 유지됩니다.')

    def report_callback_exception(self,exc_type,value,tb):
        import traceback
        traceback.print_exception(exc_type,value,tb)
        self.stop_all()
        messagebox.showerror('자동화 중지','예상하지 못한 오류로 자동화를 정지했습니다. four/startup.log를 첨부해 주세요.')

    def refresh_shared_status(self):
        self.refresh_shared_status_values()
        self.after(500,self.refresh_shared_status)

    def refresh_shared_status_values(self):
        for index,label in enumerate(name for _,name in PROFILE_SPECS):
            self.shared_status[index].set(profile_status(self,index))
        refresh_buttons(self)
        if hasattr(self,'stall_watch'):self.telegram_status.set(self.stall_watch.status)
        if hasattr(self,'tray'):self.tray.update()

    def run_single(self, index):
        if self.work_coordinator.active or self.work_coordinator.pending or any(self.work_coordinator.busy(p) for p in self.profiles):
            self.profiles[index].town_log('진행 중인 조작이 끝난 뒤 예약 모드를 변경하세요.')
            return
        self.auto_connect()
        if not self.profiles[index].window_link.hwnd:
            self.profiles[index].town_log('선택한 게임 창을 먼저 연결하세요. 기존 예약은 유지합니다.')
            return
        for i,profile in enumerate(self.profiles):
            if i != index:
                profile.daily_scheduler.stop()
                profile.stop()
        self.dual_runner.stop()
        self.arm_daily(index)
        if self.profiles[index].daily_scheduler.active:
            self.mode.set(self.profiles[index].display_name+'만 매일 예약')

    def launch_action(self, index, action, label, failed=None, scheduled=False):
        self.auto_connect()
        if not self.profile_ready(self.profiles[index]):return
        self.work_coordinator.submit(index,label,action,failed,scheduled=scheduled)

    def arm_both_daily(self):
        self.auto_connect()
        handles=[p.window_link.hwnd for p in self.profiles]
        if not all(handles) or len(set(handles)) != len(self.profiles):
            self.profiles[0].town_log('[네 계정 예약] 서로 다른 네 게임 창을 각 설정 탭에서 직접 연결하세요.')
            return
        if self.work_coordinator.active or self.work_coordinator.pending or any(self.work_coordinator.busy(p) for p in self.profiles):
            self.profiles[0].town_log('[네 계정 예약] 진행 중인 조작이 끝난 뒤 예약을 켜세요.')
            return
        if not all(self.profile_ready(p) for p in self.profiles):return
        self.arming_all=True
        try:
            for index in range(len(self.profiles)):
                self.arm_daily(index)
        finally:self.arming_all=False
        if all(p.daily_scheduler.active for p in self.profiles) and not self.dual_runner.active:
            self.dual_runner.start()

    def observation_seconds(self,now=None):
        try:value=int(self.observation_interval_var.get())
        except (ValueError,TypeError):value=120
        return value if value in (30,60,120,180,300) else 120

    def change_observation_interval(self,event=None):
        seconds=self.observation_seconds()
        try:profile_settings.update('_app',observation_switch_seconds=seconds)
        except OSError:self.mode.set('관찰 간격 저장 실패 · 현재 실행에는 적용됩니다.')
        if hasattr(self,'dual_runner'):
            self.dual_runner.due=max(self.dual_runner.due,time.monotonic()+seconds)
            self.dual_runner.next_attempt=max(self.dual_runner.next_attempt,time.monotonic()+seconds)
        self.mode.set(f'관찰용 창 전환 간격 {seconds}초 · 네 계정 한 바퀴 약 {seconds*4//60}분 · 실제 작업은 별도')

    def toggle_automation(self):
        if any(profile.daily_scheduler.active for profile in self.profiles):
            self.stop_all()
        elif self.automation_state=='off':
            self.automation_state='waiting'
            self.mode.set('대기 · 자동화 시작 전')
        else:
            self.arm_both_daily()
            if any(profile.daily_scheduler.active for profile in self.profiles):self.automation_state='on'
        self.refresh_shared_status_values()

    def arm_daily(self, index):
        self.auto_connect()
        profile=self.profiles[index]
        if not self.profile_ready(profile):return
        if profile.daily_scheduler.active or self.work_coordinator.active or (self.work_coordinator.pending and not getattr(self,'arming_all',False)) or self.focus_runner.active or any(self.work_coordinator.busy(p) for p in self.profiles):
            profile.town_log('이미 예약 중이거나 다른 조작 진행 중입니다. 작업이 끝난 뒤 예약을 켜세요.');return
        profile.supply.set('04:50')
        profile.start.set('05:01')
        profile.daily_scheduler.arm()

    def launch_supply_only(self,index):
        profile=self.profiles[index]
        self.launch_action(index,lambda:profile.supply_runner.start(supply_only=True),'복자할매·주모 보급만')

    def launch_recovery(self,index,scheduled=False,resume_route=False):
        profile=self.profiles[index]
        cycle=profile.cycle_runner
        observing=cycle.active and cycle.phase=='observe'
        required=getattr(cycle,'required_expired',None)
        event=getattr(profile,'event_runner',None)
        event_observing=event is not None and event.active and event.phase=='observe'
        handle=profile.window_link.hwnd
        def done(success):
            if profile.window_link.hwnd!=handle:return
            if resume_route:
                resume_startup_route(self,index,getattr(profile.recovery_runner,'last_field','unknown'))
                return
            if observing:
                cycle.active=True
                cycle.required_expired=required
                cycle.observe_current()
            if event_observing:
                event.active=True
                event.phase='observe'
                event.job=profile.after(1200,event.tick)
        self.launch_action(index,lambda:profile.recovery_runner.start(done=done),
                           '자동화 시작 상태 확인' if resume_route else '재접속 AUTO 확인',scheduled=scheduled)

    def launch_full_route(self,index):
        self.launch_supply(index)

    def launch_supply(self, index, scheduled=False):
        profile=self.profiles[index]
        if scheduled:
            profile.resume_mode.set('기본 순회');profile.resume_applied=False
        self.launch_action(index, lambda:profile.supply_runner.start(scheduled=scheduled),
                           ('예약 보급' if scheduled else '지금 전체 순회'),
                           profile.daily_scheduler.supply_failed if scheduled else None,
                           scheduled=scheduled)

    def launch_remaining(self, index, scheduled=False):
        profile=self.profiles[index]
        self.launch_action(index, lambda:profile.cycle_runner.start_remaining(chained=True),'특수지역 재개',scheduled=scheduled)

    def launch_general(self, index):
        profile=self.profiles[index]
        self.launch_action(index, lambda:profile.general_runner.start(chained=True),'일반사냥')

    def connect_by_layout(self):
        if (any(p.daily_scheduler.active for p in self.profiles) or self.focus_runner.active
                or self.work_coordinator.active or self.work_coordinator.pending
                or any(self.work_coordinator.busy(p) or self.dual_runner.observing(p) for p in self.profiles)):
            messagebox.showinfo('창 연결','전체 정지를 누른 뒤 화면 위치 연결을 사용하세요.');return
        from layout_binding import ordered_handles
        from window_identity import identity,authorized
        try:
            entries=[(handle,*bounds(handle)) for handle,_ in windows()]
            handles=ordered_handles(entries)
            signatures=[identity(handle) for handle in handles]
            if any(signature is None for signature in signatures):
                raise RuntimeError('게임 프로세스 정보를 확인할 수 없습니다. 게임과 관리자 실행 상태를 확인하세요.')
            # Commit all four only if every window is still the same process/position.
            if any(identity(handle)!=signature for handle,signature in zip(handles,signatures)):
                raise RuntimeError('연결 중 게임이 재실행되었습니다. 다시 눌러주세요.')
            if {(h,*bounds(h)) for h in handles}!=set(entries):
                raise RuntimeError('연결 중 창 위치가 바뀌었습니다. 창 배치를 마친 뒤 다시 눌러주세요.')
        except (ValueError,RuntimeError) as exc:
            messagebox.showinfo('창 연결',str(exc));return
        for profile,handle,signature in zip(self.profiles,handles,signatures):
            profile.window_link.hwnd=handle;profile.window_link.signature=signature
            authorized[handle]=signature
            profile.window_link.refresh()
            profile.town_log('화면 위치 연결 완료 · '+profile.display_name+' · ID '+str(handle))
        self.mode.set('연결 완료 · 1=왼쪽 위 / 2=오른쪽 위 / 3=왼쪽 아래 / 4=오른쪽 아래')

    def profile_ready(self,profile):
        if not profile.configured:
            profile.town_log('설정 탭에서 층·목적지·이벤트를 확인하고 설정 저장·확인을 누르세요.');return False
        if not profile.window_link.valid():
            profile.town_log('설정 탭에서 이 캐릭터 게임 창을 직접 연결하세요.');return False
        handles=[p.window_link.hwnd for p in self.profiles if p.window_link.hwnd]
        if len(handles)!=len(set(handles)):
            profile.town_log('같은 창이 중복 연결되어 있습니다. 다시 연결하세요.');return False
        return True

    def auto_connect(self, event=None):
        # Refresh only. Screen position and notebook selection never change identity.
        for profile in self.profiles:
            link=profile.window_link
            if link.hwnd and not link.valid():
                self.work_coordinator.cancel_profile(self.profiles.index(profile))
                profile.daily_scheduler.stop();profile.stop();link.hwnd=None;link.signature=None
                profile.town_log('기존 게임 창 종료·변경 → 이 캐릭터만 연결 해제. 새 창은 수동 연결하세요.')
            link.refresh()

    def stop_all(self, cancel_schedules=True):
        if cancel_schedules:self.automation_state='off'
        if hasattr(self,'stall_watch'):self.stall_watch.pause()
        if hasattr(self,'work_coordinator'):
            self.work_coordinator.stop()
        if cancel_schedules:
            for profile in self.profiles:
                profile.daily_scheduler.stop()
        if hasattr(self, "focus_runner"):
            self.focus_runner.stop()
        if hasattr(self, "mode"):
            self.mode.set("정지")
        if hasattr(self, "dual_runner"):
            self.dual_runner.stop()
        for profile in self.profiles:
            profile.stop()
        if hasattr(self,'automation_button'):self.refresh_shared_status_values()

    def close(self):
        if hasattr(self,'tray'):self.tray.close()
        if hasattr(self,'stall_watch'):self.stall_watch.close()
        self.stop_all()
        self.destroy()

if __name__ == '__main__':
    from single_instance import claim_controller
    if claim_controller():App().mainloop()
