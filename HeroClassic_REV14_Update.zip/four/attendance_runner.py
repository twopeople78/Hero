"""A short scheduled 05:00 attendance check through the foreground queue."""
import time
from attendance import dismiss_attendance, reset_attendance
from runner_timer import runner_after, invalidate
from runner_focus import ensure_view
from window_link import capture
from vision import from_capture
from game_actions import check_game_view


class AttendanceRunner:
    def __init__(self, owner):
        self.owner=owner;self.active=False;self.job=None

    def stop(self):
        invalidate(self);self.active=False
        if self.job is not None:self.owner.after_cancel(self.job);self.job=None

    def log(self,text):self.owner.town_log('[05시 출석 확인] '+text)

    def start(self):
        self.stop();self.handle=self.owner.window_link.hwnd
        self.active=True;self.hidden_since=None;self.focus_retry_at=0
        self.deadline=time.monotonic()+20;self.limit=self.deadline
        self.clear_hits=0;reset_attendance(self)
        self.job=runner_after(self,50,self.tick)

    def finish(self,text):
        self.stop();self.log(text)
        self.owner.winfo_toplevel().work_coordinator.handoff(self.owner)

    def tick(self):
        self.job=None
        if not self.active:return
        try:
            if self.handle!=self.owner.window_link.hwnd:raise RuntimeError('연결 창 변경')
            if not ensure_view(self,check_game_view):
                self.job=runner_after(self,300,self.tick);return
            if time.monotonic()>self.limit:raise RuntimeError('출석 확인 시간 초과 · 추가 입력 없이 다음 창 진행')
            image=from_capture(capture(self.handle))
            if dismiss_attendance(self,image):self.clear_hits=0
            else:
                self.clear_hits+=1
                if self.clear_hits>=2:
                    self.finish('출석창 없음·닫힘 확인 → 다음 창 진행 · 05:01 특수지역 예약 유지');return
            self.job=runner_after(self,300,self.tick)
        except Exception as exc:self.finish(str(exc))
