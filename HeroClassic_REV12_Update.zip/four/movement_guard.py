"""Cancel stale travel when the current hunt cannot leave; do not retry travel."""
from game_actions import click_client_point
from vision import (map_movement_blocked,world_map,locate,special_hud_timer,
                    general_location,town,auto_control)


def ordinary_departure(image,key):
    return (town(image)>=.85 or general_location(image,key)>=.82) and auto_control(image)[0]>=.90


def protect_hunt(runner,image):
    """Return True after consuming a proven blocked-map or timed-hunt state."""
    blocked=map_movement_blocked(image)
    timed=(world_map(image)<.70 and special_hud_timer(image)>=.60 and
           not ordinary_departure(image,runner.owner.general_key))
    if not (blocked or timed):return False
    owner=runner.owner
    cycle=getattr(owner,'cycle_runner',None)
    if cycle is not None:
        cycle.general_pending=False;cycle.general_force_leave=False
    # Prevent old completion callbacks from starting another travel leg.
    done=getattr(runner,'done',None)
    if hasattr(runner,'done'):runner.done=None
    runner.stop()
    ready=not blocked
    if blocked:
        score,x,y=locate(image,'attendance_modal_x',(745,0,800,50))
        if score>=.88:
            try:
                click_client_point(runner.handle,x/800,y/600)
                ready=True
            except RuntimeError:
                ready=False
    runner.log('특수지역 이동 보호 · '+('월드맵 이동 불가' if blocked else '현재 시간제 사냥')+
               ' 확인 → 기존 이동·복귀 취소 · '+('현재 사냥 재확인' if ready else '월드맵을 직접 닫으면 사냥 화면 확인 가능'))
    scheduler=getattr(owner,'event_scheduler',None)
    if scheduler is not None and getattr(scheduler,'return_check',None) is not None:
        scheduler.return_check=None;scheduler.return_check_queued=False;scheduler.return_check_at=None
        scheduler.log('현재 사냥 이동 제한 확인 → 이전 이벤트 복귀 이동 요청 해제')
    if done is not None:done(False)
    if ready and cycle is not None:
        cycle.start_remaining(chained=True)
    return True
