"""Expose the minimap by closing a recognized blocking menu, never by blind input."""
import time
from PIL import Image
from game_actions import click_client_point
from vision import (special_screen,world_map,special_icon,bag_panel,shop,warehouse,
                    main_menu_button,locate,special_entry_dialog,purchase_dialog,deposit_dialog,notice)


def blocking_menu(image):
    if not isinstance(image,Image.Image):return None,0.
    for kind,score in [('special',special_screen(image)),('map',world_map(image)),
                       ('main',special_icon(image)[0]),('bag',bag_panel(image)),
                       ('shop',shop(image)),('warehouse',warehouse(image))]:
        if score>=.88:return kind,score
    return None,0.


def expose_minimap(runner,image):
    if not isinstance(image,Image.Image):return False
    kind,score=blocking_menu(image)
    now=time.monotonic()
    if kind is None:
        runner.menu_clear_hits=getattr(runner,'menu_clear_hits',0)+1
        runner.menu_kind=None;runner.menu_hits=0
        if getattr(runner,'menu_since',None) is not None:
            if runner.menu_clear_hits<2:return True
            runner.log('열린 메뉴 닫힘 연속 확인 → 미니맵 지역·AUTO 다시 판독')
            runner.menu_since=None
        return False
    entry,cost=special_entry_dialog(image);buy,fee=purchase_dialog(image);deposit,deposit_fee=deposit_dialog(image)
    if (max(entry,cost,buy,fee,deposit,deposit_fee,notice(image))>=.86):
        raise RuntimeError('확인·구매·보관 대화 확인 → 메뉴 닫기·이동 입력 없이 보류')
    if getattr(runner,'menu_since',None) is None:runner.menu_since=now
    if now-runner.menu_since>12:raise RuntimeError('열린 메뉴 닫기 판독 시간 초과 · 임의 클릭 없이 다음 창 진행')
    runner.menu_clear_hits=0
    runner.menu_hits=getattr(runner,'menu_hits',0)+1 if getattr(runner,'menu_kind',None)==kind else 1
    runner.menu_kind=kind
    if runner.menu_hits<2:return True
    if getattr(runner,'menu_attempts',0)>=3 or now-getattr(runner,'menu_clicked_at',-100)<3:return True
    if kind=='main':close,x,y=main_menu_button(image)
    else:close,x,y=locate(image,'attendance_modal_x',(745,0,800,50))
    if close>=.90:
        click_client_point(runner.handle,x/800,y/600)
        runner.menu_clicked_at=now;runner.menu_attempts=getattr(runner,'menu_attempts',0)+1
        runner.menu_hits=0
        runner.log(f'열린 {kind} 메뉴 {score:.3f}·닫기 {close:.3f} 연속 확인 → 닫기 {runner.menu_attempts}/3 · 미니맵 노출 대기')
    return True


def reset_menu(runner):
    runner.menu_since=None;runner.menu_kind=None;runner.menu_hits=0
    runner.menu_clear_hits=0;runner.menu_attempts=0;runner.menu_clicked_at=-100


def close_verified_menu(runner,image,kind):
    """Caller has already verified the panel on consecutive frames."""
    entry,cost=special_entry_dialog(image);buy,fee=purchase_dialog(image);deposit,question=deposit_dialog(image)
    if max(entry,cost,buy,fee,deposit,question,notice(image))>=.86:
        raise RuntimeError('확인 대화가 있어 메뉴 닫기 보류 · 추가 입력 없음')
    if kind=='main':score,x,y=main_menu_button(image)
    else:score,x,y=locate(image,'attendance_modal_x',(745,0,800,50))
    if score<.90:raise RuntimeError('메뉴 닫기 버튼 영상 확인 미달 · 임의 좌표 클릭 없음')
    click_client_point(runner.handle,x/800,y/600)
