"""Explicit one-shot assignment by the user's two-column, two-row layout."""

def ordered_handles(entries):
    """Entries: (handle, client_x, client_y, client_width, client_height)."""
    if len(entries)!=4 or len({entry[0] for entry in entries})!=4:
        raise ValueError('서로 다른 게임 창 네 개를 실행한 뒤 다시 눌러주세요.')
    if any((entry[3],entry[4])!=(800,600) for entry in entries):
        raise ValueError('게임 네 개의 내부 크기를 모두 800×600으로 맞춰주세요.')
    positions=sorted(entries,key=lambda entry:(entry[1],entry[2]))
    left,right=positions[:2],positions[2:]
    if (max(e[1] for e in left)-min(e[1] for e in left)>160
            or max(e[1] for e in right)-min(e[1] for e in right)>160
            or min(e[1] for e in right)-max(e[1] for e in left)<200):
        raise ValueError('게임을 왼쪽 두 개·오른쪽 두 개로 배치해 주세요. 위치를 구분할 수 없습니다.')
    left.sort(key=lambda entry:entry[2]);right.sort(key=lambda entry:entry[2])
    if left[1][2]-left[0][2]<100 or right[1][2]-right[0][2]<100:
        raise ValueError('각 열의 게임을 위·아래로 구분되게 배치해 주세요.')
    return [left[0][0],right[0][0],left[1][0],right[1][0]]
