"""Close only the supplied attendance page, using its title and Event/X header."""
import time
from vision import locate
from game_actions import click_client_point


def attendance_point(image):
    visible=0
    title,tx,ty=locate(image,'attendance_modal_title',(180,60,600,320))
    if title>=.90:
        visible=title
        period,px,py=locate(image,'attendance_period',(150,90,650,350))
        # Font antialiasing can lower the old period prefix score. Use
        # independent attendance-only text, still paired with title and X.
        native,px2,py2=locate(image,'attendance_period_native',(max(0,round(tx-160)),round(ty+10),min(800,round(tx+60)),round(ty+80)))
        hint,hx2,hy2=locate(image,'attendance_reward_hint',(max(0,round(tx+65)),max(0,round(ty-25)),min(800,round(tx+240)),min(600,round(ty+40))))
        period_ok=period>=.88 and tx-180<px<tx+60 and ty+10<py<ty+80
        native_ok=native>=.90 and tx-180<px2<tx+60 and ty+10<py2<ty+80
        hint_ok=hint>=.92 and tx+70<hx2<tx+230 and abs(hy2-ty)<25
        roi=(max(0,round(tx+240)),max(0,round(ty-30)),min(800,round(tx+380)),min(600,round(ty+35)))
        close,x,y=locate(image,'attendance_modal_x',roi)
        if close>=.90 and (period_ok or native_ok or hint_ok):
            support=max(period if period_ok else 0,native if native_ok else 0,hint if hint_ok else 0)
            return min(title,support,close),x,y
    for tag,scale in (('100',1.),('80',.8),('120',1.2)):
        title,tx,ty=locate(image,'attendance_title_'+tag,(40,0,650,340))
        if title<.88:continue
        visible=max(visible,title)
        header,hx,hy=locate(image,'attendance_header_'+tag,(350,0,800,260))
        if header>=.88 and hx>tx+120*scale and hy<ty+15*scale:
            # X center is (671,12) in the supplied crop. Header center (649,13).
            return min(title,header),hx+22*scale,hy-scale
    return -visible,0,0


def dismiss_attendance(runner,image):
    now=time.monotonic()
    score,x,y=attendance_point(image)
    if score<0:
        if getattr(runner,'attendance_since',None) is None:runner.attendance_since=now
        runner.attendance_hits=0
        if now-runner.attendance_since>10:raise RuntimeError('출석 제목 확인·닫기 위치 확인 대기')
        return True
    if score>=.88:
        if getattr(runner,'attendance_since',None) is None:
            runner.attendance_since=now;runner.attendance_hits=0
            runner.attendance_clicked=False;runner.attendance_gone=0
        if getattr(runner,'attendance_clicked',False):
            if now-runner.attendance_clicked_at>8:
                raise RuntimeError('출석창 닫힘 확인 지연 · 다음 복구 검사에서 재확인')
            return True
        point=(round(x),round(y))
        runner.attendance_hits=(runner.attendance_hits+1 if getattr(runner,'attendance_point',None)==point else 1)
        runner.attendance_point=point
        if runner.attendance_hits>=2:
            if hasattr(runner,'save'):runner.save(image,'attendance_before_close')
            click_client_point(runner.handle,x/800,y/600)
            runner.attendance_clicked=True;runner.attendance_clicked_at=now
            runner.log('출석 제목·기간/이벤트·X 연속 확인 → 출석창 닫기 1회 · 콘텐츠 알림은 유지')
        return True
    started=getattr(runner,'attendance_since',None)
    if started is not None:
        runner.attendance_gone=getattr(runner,'attendance_gone',0)+1
        if runner.attendance_gone<2:return True
        for key in ('deadline','limit','phase_deadline'):
            if hasattr(runner,key):setattr(runner,key,getattr(runner,key)+now-started)
        runner.attendance_since=None;runner.attendance_hits=0;runner.attendance_clicked=False
        runner.log('출석창 사라짐 연속 확인 → 원래 작업 재개')
    return False


def reset_attendance(runner):
    runner.attendance_since=None;runner.attendance_hits=0
    runner.attendance_clicked=False;runner.attendance_gone=0
