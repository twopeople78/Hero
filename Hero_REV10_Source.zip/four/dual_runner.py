"""Four-window read turns. Foreground actions always take precedence."""
import time
from runner_timer import runner_after, invalidate
from focus_guard import focus_allowed, switching_paused
from work_coordinator import WorkCoordinator

class DualRunner:
    def __init__(self, app):
        self.app=app;self.active=False;self.job=None
        self.current=None;self.due=0;self.last={};self.next_attempt=0

    def stop(self):
        invalidate(self);self.active=False
        if self.job is not None:self.app.after_cancel(self.job);self.job=None

    def start(self):
        if self.active:return
        self.active=True;self.last={};self.due=time.monotonic()+2
        # Scheduled work owns focus; idle observation never schedules a rotation.
        self.job=None

    @staticmethod
    def observing(profile):
        return any(getattr(r,'active',False) and getattr(r,'phase',None) in ('observe','identify_existing')
                   for r in (profile.cycle_runner,profile.event_runner))

    busy=staticmethod(WorkCoordinator.busy)

    def tick(self):
        self.job=None
        if not self.active:return
        try:self.tick_once()
        finally:
            if self.active:self.job=runner_after(self,1000,self.tick)

    def tick_once(self):
        # Compatibility entry point. Observation-only foreground switching is disabled.
        return
