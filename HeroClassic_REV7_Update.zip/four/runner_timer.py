"""Single pending callback per runner, with generation and app reentry guards."""


def invalidate(runner):
    runner.timer_generation=getattr(runner,'timer_generation',0)+1


def context(runner):
    owner=getattr(runner,'owner',None)
    if owner is not None:
        app=owner.winfo_toplevel() if hasattr(owner,'winfo_toplevel') else None
        return owner,app
    return runner.app,runner.app


def runner_after(runner,delay,callback):
    if not runner.active and not getattr(runner,'general_pending',False):return None
    scheduler,app=context(runner)
    old=getattr(runner,'job',None)
    if old is not None:scheduler.after_cancel(old)
    generation=getattr(runner,'timer_generation',0)
    executed=False
    def fire():
        nonlocal executed
        if (executed or (not runner.active and not getattr(runner,'general_pending',False))
                or generation!=getattr(runner,'timer_generation',0)):return
        if app is not None and getattr(app,'automation_callback',None) is not None:
            runner.job=scheduler.after(50,fire)
            return
        runner.job=None
        executed=True
        if app is not None:app.automation_callback=runner
        try:callback()
        finally:
            if app is not None and getattr(app,'automation_callback',None) is runner:
                app.automation_callback=None
    return scheduler.after(delay,fire)
