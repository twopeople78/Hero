"""Keep an entry/AUTO owner foreground until its verified handoff ends."""
import time


def observation_interval(app):
    configured=getattr(app,'observation_seconds',None)
    return configured() if callable(configured) else 180


def switching_paused(app):
    flag=getattr(app,'window_switch_paused',False)
    return bool(flag.get()) if hasattr(flag,'get') else bool(flag)


def app_of(runner):
    owner=getattr(runner,'owner',None)
    return owner.winfo_toplevel() if owner is not None and hasattr(owner,'winfo_toplevel') else None


def lock(runner):
    app=app_of(runner)
    if app is None:return
    held=getattr(app,'focus_transaction',None)
    if held is not None and held[0].active and held[1]!=runner.handle:
        raise RuntimeError('다른 캐릭터의 입장/AUTO 확인 완료 대기')
    app.focus_transaction=(runner,runner.handle)


def unlock(runner):
    app=app_of(runner)
    if app is None:return
    held=getattr(app,'focus_transaction',None)
    if held is not None and held[0] is runner:
        app.focus_transaction=None
        dual=getattr(app,'dual_runner',None)
        if dual is not None and dual.active:dual.due=time.monotonic()+observation_interval(app)


def focus_allowed(app,handle,ignore_pause=False):
    if not ignore_pause and switching_paused(app):return False
    held=getattr(app,'focus_transaction',None)
    if held is not None:
        if held[0].active and held[1]!=handle:return False
        if not held[0].active:app.focus_transaction=None
    for p in getattr(app,'profiles',()):
        if p.window_link.hwnd==handle:continue
        for name in ('observation_menu_runner','entry_runner','recovery_runner','special_runner','general_runner',
                     'supply_runner','npc_runner','store_runner','jumo_runner','buy_runner','auto_runner'):
            if getattr(getattr(p,name,None),'active',False):return False
        event=getattr(p,'event_runner',None)
        if event is not None and event.active and event.phase not in ('observe','identify_existing'):return False
        cycle=getattr(p,'cycle_runner',None)
        if cycle is not None and cycle.active and cycle.phase not in ('observe','retry_wait'):return False
    return True
