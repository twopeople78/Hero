from death_runner import intercept as death_intercept
"""Close recognized menus only for idle hunt observation, through the shared queue."""
import time
from runner_timer import runner_after,invalidate
from runner_focus import ensure_view
from focus_guard import lock,unlock
from window_link import capture
from game_actions import check_game_view,click_client_point
from vision import (from_capture,special_icon,special_screen,world_map,main_menu_button,
                    locate,notice,shop,warehouse,bag_panel,quest_travel,purchase_dialog,special_entry_dialog)


def menu_kind(image):
    if special_screen(image)>=.88:return 'special'
    if world_map(image)>=.88:return 'map'
    if special_icon(image)[0]>=.88:return 'main'
    return None


def observe_menu(observer,image):
    """Called with a separately verified, exposed top-right HUD crop."""
    if not observer.active or observer.phase!='observe':return False
    if getattr(observer,'menu_repair_pending',False):return True
    kind=menu_kind(image)
    if kind is None:
        observer.observed_menu_hits=0;observer.observed_menu_kind=None
        return False
    observer.observed_menu_hits=(getattr(observer,'observed_menu_hits',0)+1
        if getattr(observer,'observed_menu_kind',None)==kind else 1)
    observer.observed_menu_kind=kind
    app=observer.owner.winfo_toplevel();q=app.work_coordinator
    if observer.observed_menu_hits<2:return True
    if time.monotonic()<getattr(observer,'menu_repair_retry_at',0):return True
    if q.active or q.pending or app.focus_runner.active:return True
    cleanup=getattr(observer.owner,'observation_menu_runner',None)
    if cleanup is None:return False
    observer.menu_repair_pending=True
    def failed(text):
        observer.menu_repair_pending=False
        observer.menu_repair_retry_at=time.monotonic()+30
        observer.log('관찰 메뉴 정리 대기 · '+text)
    q.submit(app.profiles.index(observer.owner),'사냥 관찰 메뉴 정리',
        lambda:cleanup.start(observer),failed,scheduled=True,priority=True)
    observer.log('사냥 관찰 중 열린 메뉴 연속 확인 → 메뉴 정리 작업 대기')
    return True


class ObservationMenuRunner:
    def __init__(self,owner):self.owner=owner;self.active=False;self.job=None;self.observer=None
    def stop(self):
        unlock(self);invalidate(self);self.active=False
        if self.job is not None:self.owner.after_cancel(self.job);self.job=None
        if self.observer is not None:self.observer.menu_repair_pending=False
        self.observer=None
    def log(self,text):self.owner.town_log('[관찰 메뉴 정리] '+text)
    def start(self,observer):
        self.stop();self.observer=observer;self.handle=self.owner.window_link.hwnd
        self.active=True;self.phase='check';self.hidden_since=None;self.focus_retry_at=0
        self.hits=0;self.last_kind=None;self.gone_hits=0;self.attempts=0;self.last_click=-100
        self.started=time.monotonic();self.deadline=self.started+30;self.limit=self.deadline
        observer.menu_repair_pending=True
        try:lock(self)
        except RuntimeError as exc:self.finish(False,str(exc));return
        self.job=runner_after(self,700,self.tick)
    def finish(self,success,text):
        observer=self.observer;elapsed=time.monotonic()-self.started
        self.stop();self.log(text)
        if observer is None or observer.handle!=self.owner.window_link.hwnd:return
        observer.menu_repair_pending=False;observer.observed_menu_hits=0
        observer.menu_repair_retry_at=time.monotonic()+(0 if success else 30)
        observer.active=True;observer.phase='observe';observer.hidden_since=None
        observer.hits=0
        if hasattr(observer,'passive_return_hits'):observer.passive_return_hits=0
        if hasattr(observer,'deadline'):observer.deadline+=elapsed
        observer.job=runner_after(observer,900,observer.tick)
    def tick(self):
        self.job=None
        if not self.active:return
        try:
            if self.handle!=self.owner.window_link.hwnd:raise RuntimeError('연결 창 변경')
            if not ensure_view(self,check_game_view):self.job=runner_after(self,900,self.tick);return
            image=from_capture(capture(self.handle));now=time.monotonic()
            if death_intercept(self.owner,image):return
            if now>self.limit:raise RuntimeError('메뉴 닫힘 확인 시간 초과')
            buy,fee=purchase_dialog(image);entry,cost=special_entry_dialog(image)
            blocked=max(notice(image),shop(image),warehouse(image),bag_panel(image),quest_travel(image))>=.85
            if blocked or (buy>=.86 and fee>=.80) or (entry>=.86 and cost>=.80):
                self.finish(False,'다른 대화·구매·상점 화면 확인 · 메뉴 입력 없이 관찰 재개');return
            kind=menu_kind(image)
            if kind is None:
                self.gone_hits+=1
                if self.gone_hits>=2:self.finish(True,'메뉴 닫힘 연속 확인 → 미니맵·남은시간 관찰 재개');return
            else:
                self.gone_hits=0
                self.hits=self.hits+1 if kind==self.last_kind else 1;self.last_kind=kind
                if self.hits>=2 and self.attempts<3 and now-self.last_click>=3:
                    if kind=='main':score,x,y=main_menu_button(image)
                    else:score,x,y=locate(image,'attendance_modal_x',(745,0,800,50))
                    if score>=.88:
                        click_client_point(self.handle,x/800,y/600)
                        self.attempts+=1;self.last_click=now;self.hits=0
                        self.log('열린 '+kind+' 메뉴와 닫기 위치 확인 → 닫기 '+str(self.attempts)+'/3')
            self.job=runner_after(self,900,self.tick)
        except Exception as exc:self.finish(False,'입력 중지 · '+str(exc))
