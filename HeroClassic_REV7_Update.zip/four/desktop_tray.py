"""Windows tray on a dedicated native thread; Tk calls stay on the GUI thread."""
import ctypes as c
from ctypes import wintypes as w
from pathlib import Path
import os,queue,threading

u=c.WinDLL('user32',use_last_error=True);shell=c.WinDLL('shell32',use_last_error=True);kernel=c.WinDLL('kernel32',use_last_error=True)
LRESULT=c.c_ssize_t;WPARAM=c.c_size_t;LPARAM=c.c_ssize_t
WNDPROC=c.WINFUNCTYPE(LRESULT,w.HWND,w.UINT,WPARAM,LPARAM)
class Guid(c.Structure):_fields_=[('a',w.DWORD),('b',w.WORD),('d',w.WORD),('e',c.c_ubyte*8)]
class NotifyData(c.Structure):
    _fields_=[('cbSize',w.DWORD),('hWnd',w.HWND),('uID',w.UINT),('uFlags',w.UINT),
              ('uCallbackMessage',w.UINT),('hIcon',w.HICON),('szTip',w.WCHAR*128),
              ('dwState',w.DWORD),('dwStateMask',w.DWORD),('szInfo',w.WCHAR*256),
              ('uVersion',w.UINT),('szInfoTitle',w.WCHAR*64),('dwInfoFlags',w.DWORD),
              ('guidItem',Guid),('hBalloonIcon',w.HICON)]
class WindowClass(c.Structure):
    _fields_=[('style',w.UINT),('proc',WNDPROC),('class_extra',c.c_int),('window_extra',c.c_int),
              ('instance',w.HINSTANCE),('icon',w.HICON),('cursor',w.HANDLE),('brush',w.HBRUSH),
              ('menu',w.LPCWSTR),('name',w.LPCWSTR)]
u.RegisterClassW.argtypes=[c.POINTER(WindowClass)];u.RegisterClassW.restype=w.WORD
u.UnregisterClassW.argtypes=[w.LPCWSTR,w.HINSTANCE];u.UnregisterClassW.restype=w.BOOL
u.CreateWindowExW.argtypes=[w.DWORD,w.LPCWSTR,w.LPCWSTR,w.DWORD,c.c_int,c.c_int,c.c_int,c.c_int,w.HWND,w.HMENU,w.HINSTANCE,c.c_void_p];u.CreateWindowExW.restype=w.HWND
u.DestroyWindow.argtypes=[w.HWND];u.DestroyWindow.restype=w.BOOL
u.GetMessageW.argtypes=[c.POINTER(w.MSG),w.HWND,w.UINT,w.UINT];u.GetMessageW.restype=c.c_int
u.TranslateMessage.argtypes=[c.POINTER(w.MSG)];u.DispatchMessageW.argtypes=[c.POINTER(w.MSG)];u.DispatchMessageW.restype=LRESULT
u.PostQuitMessage.argtypes=[c.c_int]
kernel.GetModuleHandleW.argtypes=[w.LPCWSTR];kernel.GetModuleHandleW.restype=w.HINSTANCE
u.LoadImageW.argtypes=[w.HINSTANCE,w.LPCWSTR,w.UINT,c.c_int,c.c_int,w.UINT];u.LoadImageW.restype=w.HANDLE
u.DestroyIcon.argtypes=[w.HICON];u.DestroyIcon.restype=w.BOOL
u.RegisterWindowMessageW.argtypes=[w.LPCWSTR];u.RegisterWindowMessageW.restype=w.UINT
u.DefWindowProcW.argtypes=[w.HWND,w.UINT,WPARAM,LPARAM];u.DefWindowProcW.restype=LRESULT
shell.Shell_NotifyIconW.argtypes=[w.DWORD,c.POINTER(NotifyData)];shell.Shell_NotifyIconW.restype=w.BOOL
u.CreatePopupMenu.argtypes=[];u.CreatePopupMenu.restype=w.HMENU
u.AppendMenuW.argtypes=[w.HMENU,w.UINT,c.c_size_t,w.LPCWSTR];u.AppendMenuW.restype=w.BOOL
u.TrackPopupMenu.argtypes=[w.HMENU,w.UINT,c.c_int,c.c_int,c.c_int,w.HWND,c.c_void_p];u.TrackPopupMenu.restype=w.UINT
u.DestroyMenu.argtypes=[w.HMENU];u.DestroyMenu.restype=w.BOOL
u.GetCursorPos.argtypes=[c.POINTER(w.POINT)];u.GetCursorPos.restype=w.BOOL
u.SetForegroundWindow.argtypes=[w.HWND];u.SetForegroundWindow.restype=w.BOOL
u.PostMessageW.argtypes=[w.HWND,w.UINT,WPARAM,LPARAM];u.PostMessageW.restype=w.BOOL


def automation_status(app):
    count=sum(p.daily_scheduler.active for p in app.profiles)
    if count==len(app.profiles):return 'on','자동화 켜짐'
    if count:return 'partial',f'{count}개 자동화 켜짐'
    if app.automation_state=='off':return 'off','자동화 꺼짐'
    return 'waiting','자동화 대기'

class DesktopTray:
    CALLBACK=0x8000+82;UPDATE=0x8000+83
    def __init__(self,app):
        self.app=app;self.hwnd=None;self.icons={};self.added=False;self.closed=False
        self.hidden=False;self.available=False;self.popup_open=False;self.pending_minimize=None
        self.state='waiting';self.tip='조선 사냥 관리 · 자동화 대기';self.lines=();self.last_state=None
        self.commands=queue.Queue();self.ready=threading.Event();self.error=''
        self.thread=threading.Thread(target=self.run,daemon=True);self.thread.start()
        self.ready.wait(3)
        app.bind('<Unmap>',self.on_unmap,add='+')
        self.poll_job=app.after(100,self.poll)
    def data(self):
        data=NotifyData();data.cbSize=c.sizeof(NotifyData);data.hWnd=self.hwnd;data.uID=1
        data.uFlags=1|2|4|0x80;data.uCallbackMessage=self.CALLBACK
        data.hIcon=self.icons.get(self.state);data.szTip=self.tip[:127]
        return data
    def register(self):
        data=self.data()
        if not shell.Shell_NotifyIconW(0,c.byref(data)):return False
        self.added=True;data.uVersion=4;shell.Shell_NotifyIconW(4,c.byref(data))
        return True
    def run(self):
        instance=kernel.GetModuleHandleW(None);name='ChosunTray_'+str(os.getpid())+'_'+str(id(self));registered=False
        try:
            for key in ('waiting','on','off','partial'):
                path=Path(__file__).resolve().parent/'assets'/('tray_'+key+'.ico')
                icon=u.LoadImageW(None,str(path),1,32,32,0x10)
                if not icon:raise OSError('트레이 아이콘 읽기 실패')
                self.icons[key]=icon
            self.callback=WNDPROC(self.window_proc);wc=WindowClass();wc.proc=self.callback;wc.instance=instance;wc.name=name
            if not u.RegisterClassW(c.byref(wc)):raise OSError('트레이 메시지 창 등록 실패')
            registered=True
            self.taskbar_created=u.RegisterWindowMessageW('TaskbarCreated')
            self.hwnd=u.CreateWindowExW(0,name,'Chosun tray messages',0,0,0,0,0,None,None,instance,None)
            if not self.hwnd:raise OSError('트레이 메시지 창 생성 실패')
            if hasattr(u,'ChangeWindowMessageFilterEx'):
                u.ChangeWindowMessageFilterEx.argtypes=[w.HWND,w.UINT,w.DWORD,c.c_void_p]
                u.ChangeWindowMessageFilterEx(self.hwnd,self.taskbar_created,1,None)
            self.available=self.register()
            if not self.available:raise OSError('트레이 등록 실패')
            self.ready.set();message=w.MSG()
            while not self.closed:
                result=u.GetMessageW(c.byref(message),None,0,0)
                if result<=0:break
                u.TranslateMessage(c.byref(message));u.DispatchMessageW(c.byref(message))
        except Exception as exc:self.error=str(exc)+' / WinError '+str(c.get_last_error())
        finally:
            self.available=False
            if self.added:
                data=self.data();shell.Shell_NotifyIconW(2,c.byref(data));self.added=False
            if self.hwnd:u.DestroyWindow(self.hwnd);self.hwnd=None
            if registered:u.UnregisterClassW(name,instance)
            for icon in self.icons.values():u.DestroyIcon(icon)
            self.icons.clear();self.ready.set()
            if self.hidden and not self.closed:self.commands.put('restore')
    def window_proc(self,hwnd,message,wp,lp):
        try:
            if message==self.CALLBACK:
                event=lp&0xffff
                if event in (0x203,0x401):self.commands.put('restore')
                elif event in (0x205,0x7b):self.show_menu()
                return 0
            if message==self.UPDATE:
                data=self.data();shell.Shell_NotifyIconW(1,c.byref(data));return 0
            if message==getattr(self,'taskbar_created',-1):
                self.added=False;self.available=self.register()
                if not self.available:self.commands.put('restore')
                return 0
            if message==0x10:
                u.PostQuitMessage(0);return 0
        except Exception:
            self.commands.put('restore')
        return u.DefWindowProcW(hwnd,message,wp,lp)
    def update(self):
        if self.closed:return
        state,label=automation_status(self.app);tip='조선 사냥 관리 · '+label+' · 더블클릭: GUI 열기'
        self.lines=tuple(value.get() for value in self.app.shared_status)
        if (state,tip)==self.last_state:return
        self.state=state;self.tip=tip;self.last_state=(state,tip)
        if self.available and self.hwnd:u.PostMessageW(self.hwnd,self.UPDATE,0,0)
    def poll(self):
        self.poll_job=None
        if self.closed:return
        while not self.commands.empty():
            command=self.commands.get_nowait()
            if command=='close':self.app.close();return
            if command=='restore':self.restore()
        self.poll_job=self.app.after(100,self.poll)
    def on_unmap(self,event):
        if event.widget is not self.app or self.closed or self.hidden:return
        if self.app.state()=='iconic' and self.pending_minimize is None:
            self.pending_minimize=self.app.after(60,self.minimize)
    def minimize(self):
        self.pending_minimize=None
        if self.closed or not self.available or not self.added:return
        self.update();self.hidden=True;self.app.withdraw()
    def restore(self):
        if self.closed:return
        if self.pending_minimize is not None:
            self.app.after_cancel(self.pending_minimize);self.pending_minimize=None
        self.hidden=False;self.app.deiconify();self.app.state('normal');self.app.lift()
    def show_menu(self):
        # This method executes on the native thread, never inside Tk's WNDPROC.
        if self.closed or self.popup_open:return
        self.popup_open=True;menu=u.CreatePopupMenu()
        try:
            if not menu:return
            label=self.tip.split(' · ')[1]
            u.AppendMenuW(menu,0,1,'GUI 열기');u.AppendMenuW(menu,2,0,label)
            for name,text in zip((p.display_name for p in self.app.profiles),self.lines):u.AppendMenuW(menu,2,0,(name+': '+text)[:110])
            u.AppendMenuW(menu,0x800,0,None);u.AppendMenuW(menu,0,2,'프로그램 종료 (자동화 중지)')
            point=w.POINT();u.GetCursorPos(c.byref(point));u.SetForegroundWindow(self.hwnd)
            command=u.TrackPopupMenu(menu,0x100|0x80|0x2,point.x,point.y,0,self.hwnd,None)
            u.PostMessageW(self.hwnd,0,0,0)
            if command==1:self.commands.put('restore')
            elif command==2:self.commands.put('close')
        finally:
            if menu:u.DestroyMenu(menu)
            self.popup_open=False
    def close(self):
        if self.closed:return
        self.closed=True
        for name in ('poll_job','pending_minimize'):
            job=getattr(self,name,None)
            if job is not None:
                try:self.app.after_cancel(job)
                except Exception:pass
                setattr(self,name,None)
        if self.hwnd:u.PostMessageW(self.hwnd,0x10,0,0)
        if self.thread is not threading.current_thread():self.thread.join(2)
