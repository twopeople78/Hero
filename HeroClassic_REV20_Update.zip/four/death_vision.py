"""Read-only death/free-restoration UI recognition; never infer a paid action."""
import numpy as np
from vision import locate,locate_text,white_text


def death_screen(image):
    title=locate(image,'death_title',(300,40,500,125))[0]
    grave=locate(image,'death_grave',(380,515,595,585))
    return title>=.90 and grave[0]>=.90,grave


def restoration_icon(image):
    return max((locate(image,n,(560,0,655,65)) for n in ('restore_icon','restore_icon_current')),key=lambda m:m[0])


def panel(image):
    exp=locate(image,'restore_exp_tab',(5,0,100,38))
    items=locate(image,'restore_item_tab',(100,0,195,38))
    close=locate(image,'restore_panel_x',(185,0,230,40))
    return max(exp[0],items[0])>=.88 and close[0]>=.88,exp,items,close


def selected_tab(image,key):
    a=np.asarray(image.convert('RGB'),dtype=float)
    x0,x1=(15,85) if key=='exp' else (110,180)
    r,g,b=(a[3:27,x0:x1,i] for i in range(3))
    return bool(((r>80)&(g>60)&(r>b*1.3)&(g>b*1.2)).mean()>.035)


def blue_enabled(image,box):
    a=np.asarray(image.convert('RGB'),dtype=float)
    x0,y0,x1,y1=box;r,g,b=(a[y0:y1,x0:x1,i] for i in range(3))
    return bool(((b>r+8)&(b>g+3)).mean()>.30)


def row_present(image):
    # The panel is opaque here. Require real row content, never the empty footer.
    return bool(white_text(image)[35:84,12:215].sum()>=35)


def selection_ready(image):
    return blue_enabled(image,(10,565,215,590))


def free_button(image):
    score,x,y=locate(image,'restore_free',(145,515,223,565))
    return (score,x,y) if score>=.88 and blue_enabled(image,(155,534,215,553)) else (0.,x,y)


def free_confirmation(image,available=None):
    # The zero template must match the COST cell, not the current-wallet cell.
    title=locate(image,'restore_confirm_title',(330,175,465,235))[0]
    free=locate(image,'restore_free_charge',(260,278,390,313))[0]
    label=locate(image,'restore_cost_label',(300,305,390,340))[0]
    zero=locate_text(image,'restore_zero',(414,310,448,336))[0]
    currency=locate(image,'restore_currency_label',(290,332,390,368))[0]
    currency_zero=locate_text(image,'restore_currency_zero',(414,336,448,362))[0]
    one=locate_text(image,'restore_one',(420,286,444,310))[0]
    button=locate(image,'restore_confirm',(460,357,530,407))
    charge=free_charge_count(image)
    within_quota=charge is not None and charge>0 and (available is None or charge<=available)
    safe=title>=.90 and free>=.90 and label>=.90 and zero>=.97 and currency>=.90 and currency_zero>=.97 and within_quota and button[0]>=.90
    return safe,button,dict(title=title,free=free,free_charge_one_score=one,free_charge=charge,within_quota=within_quota,cost=label,zero=zero,currency=currency,currency_zero=currency_zero)


def confirmation_visible(image):
    return locate(image,'restore_confirm_title',(330,175,465,235))[0]>=.85


def _digit_mask(image):
    from PIL import Image
    a=np.asarray(image.convert('L'),dtype=float)
    # Local background is dark blue/gray; normalize contrast before shape matching.
    low=float(np.percentile(a,15));high=float(a.max())
    if high-low<35:return None
    a=np.clip((a-low)/(high-low),0,1)
    ys,xs=np.where(a>=.35)
    if len(xs)<4:return None
    a=a[ys.min():ys.max()+1,xs.min():xs.max()+1]
    canvas=Image.new('L',(16,24))
    tile=Image.fromarray(np.uint8(a*255))
    tile.thumbnail((12,20),Image.Resampling.BILINEAR)
    canvas.paste(tile,((16-tile.width)//2,(24-tile.height)//2))
    return np.asarray(canvas,dtype=float)/255


def restoration_count(image,kind):
    """Return only a confident native quota glyph; ambiguity is not zero."""
    from PIL import Image
    from vision import ASSETS
    if kind=='free':
        point=locate(image,'restore_free',(145,515,223,565))
        if point[0]<.88:return None
        x,y=point[1:];box=(round(x+16),round(y-6),round(x+22),round(y+5))
    else:box=(126,536,132,546)
    source=_digit_mask(image.crop(box))
    if source is None:return None
    scores=[]
    for digit in range(10):
        with Image.open(ASSETS/f'restore_digit_{digit}.png') as reference:template=_digit_mask(reference)
        denom=np.linalg.norm(source)*np.linalg.norm(template)
        score=float((source*template).sum()/denom) if denom else 0.
        scores.append((score,digit))
    scores.sort(reverse=True)
    return scores[0][1] if scores[0][0]>=.93 and scores[0][0]-scores[1][0]>=.07 else None


def batch_button(image):
    score,x,y=locate(image,'restore_batch',(0,555,222,600))
    return (score,110.,y) if score>=.90 and selection_ready(image) else (0.,110.,y)


def free_charge_count(image):
    """Recognize a single native charge digit; multi-digit/ambiguous costs hold."""
    from PIL import Image
    from vision import ASSETS
    region=image.crop((419,288,446,309))
    a=np.asarray(region.convert('L'),dtype=float)
    low=float(np.percentile(a,15));high=float(a.max())
    if high-low<35:return None
    ys,xs=np.where(a>=low+(high-low)*.35)
    if len(xs)<4 or xs.max()-xs.min()+1>9:return None
    source=_digit_mask(region)
    if source is None:return None
    choices=[]
    for digit in range(10):
        ref='restore_one' if digit==1 else f'restore_digit_{digit}'
        with Image.open(ASSETS/(ref+'.png')) as tile:template=_digit_mask(tile)
        denom=np.linalg.norm(source)*np.linalg.norm(template)
        score=float((source*template).sum()/denom) if denom else 0.
        choices.append((score,digit))
    choices.sort(reverse=True)
    if choices[0][0]>=.93 and choices[0][0]-choices[1][0]>=.07:return choices[0][1]
    return None
