from death_runner import intercept as death_intercept
"""A short scheduled 05:00 attendance check through the foreground queue."""
import time
from attendance import dismiss_attendance, reset_attendance
from runner_timer import runner_after, invalidate
from runner_focus import ensure_view
from window_link import capture
from vision import from_capture
from game_actions import check_game_view


class AttendanceRunner:
    def __init__(self, owner):
        self.owner=owner;self.active=False;self.job=None

    def stop(self):
        invalidate(self);self.active=False
        if self.job is not None:self.owner.after_cancel(self.job);self.job=None

    def log(self,text):
        self.owner.town_log('[출석 확인] '+text)
        from pathlib import Path
        from datetime import datetime
        try:
            folder=Path(__file__).resolve().parent/'diagnostics';folder.mkdir(exist_ok=True)
            with (folder/'attendance.log').open('a',encoding='utf-8') as stream:
                stream.write(f'{datetime.now():%Y-%m-%d %H:%M:%S} [{self.owner.profile_id}] {text}\n')
        except OSError:pass

    def start(self):
        self.stop();self.handle=self.owner.window_link.hwnd
        self.active=True;self.hidden_since=None;self.focus_retry_at=0
        self.deadline=time.monotonic()+20;self.limit=self.deadline
        self.clear_hits=0;self.seen=False;reset_attendance(self)
        self.job=runner_after(self,50,self.tick)

    def finish(self,text):
        self.stop();self.log(text)
        self.owner.winfo_toplevel().work_coordinator.handoff(self.owner)

    def tick(self):
        self.job=None
        if not self.active:return
        try:
            if self.handle!=self.owner.window_link.hwnd:raise RuntimeError('연결 창 변경')
            if not ensure_view(self,check_game_view):
                self.job=runner_after(self,300,self.tick);return
            if time.monotonic()>self.limit:raise RuntimeError('출석 확인 시간 초과 · 추가 입력 없이 다음 창 진행')
            image=from_capture(capture(self.handle))
            if death_intercept(self.owner,image):return
            if dismiss_attendance(self,image):
                self.seen=True;self.clear_hits=0
            else:
                self.clear_hits+=1
                if self.clear_hits>=2:
                    if self.seen:
                        daily=self.owner.daily_scheduler
                        daily.attendance_closed_day=daily.now().date()
                        self.log('출석창 닫힘 확인 · 기존 사냥/예약 작업 이어가기')
                        app=self.owner.winfo_toplevel()
                        from datetime import time as clock_time
                        now=daily.now()
                        if (daily.active and daily.supply_ok and daily.special_time<=now.time()<clock_time(10)
                                and not app.dual_runner.observing(self.owner)):
                            app.launch_remaining(app.profiles.index(self.owner),scheduled=True,morning_only=True)
                    self.finish('출석창 없음·닫힘 확인 → 다음 창 진행 · 늦게 표시되면 재검사');return
            self.job=runner_after(self,300,self.tick)
        except Exception as exc:self.finish(str(exc))
