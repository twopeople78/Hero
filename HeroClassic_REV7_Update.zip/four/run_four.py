"""Always start from the installed 32-bit venv; retain elevated startup errors."""
import ctypes
import struct
import sys
import traceback
from contextlib import redirect_stdout,redirect_stderr
from pathlib import Path
from admin_launch import launch_as_admin

def main():
    if not launch_as_admin(__file__): return
    folder=Path(__file__).resolve().parent
    with (folder/'startup.log').open('a',encoding='utf-8',buffering=1) as log, redirect_stdout(log), redirect_stderr(log):
        try:
            if struct.calcsize('P')*8!=32:
                raise RuntimeError('Python 3.11 32비트 가상환경으로 실행하세요.')
            if sys.version_info[:2]!=(3,11):
                raise RuntimeError('Python 3.11 가상환경이 필요합니다.')
            import numpy
            import PIL
            import tkinter
            from single_instance import claim_controller
            from chosun_gui import App
            if claim_controller():App().mainloop()
        except Exception:
            traceback.print_exc()
            ctypes.windll.user32.MessageBoxW(None,
                '실행 오류가 발생했습니다. four\\startup.log 파일을 첨부해 주세요.',
                '4계정 관리 · 실행 오류',0x10)
            return 1
    return 0

if __name__=='__main__':
    raise SystemExit(main())
