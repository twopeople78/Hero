from movement_guard import protect_hunt,ordinary_departure
from runner_timer import runner_after, invalidate
from attendance import dismiss_attendance, reset_attendance
"""Named world-map destination, arrival and one AUTO action per profile."""
import time
from pathlib import Path
from datetime import datetime
from window_link import capture
from game_actions import check_game_view, click_client_point
from runner_focus import ensure_view
from event_vision import event_location,event_return_location
from event_schedule import events_for,end_at
from buy_runner import wallet, wallet_similarity
from vision import (from_capture, world_map, world_destination, general_row,
                    general_row_selected, general_location, auto_control,
                    combat_active, special_screen, special_hud_timer, notice,
                    shop, warehouse, quest_travel, special_icon,bag_panel,town,purchase_dialog,deposit_dialog,auto_mode)


class GeneralRunner:
    def __init__(self, owner):
        self.owner = owner
        self.active = False
        self.job = None

    def stop(self):
        invalidate(self)
        self.active = False
        if self.job is not None:
            self.owner.after_cancel(self.job)
            self.job = None

    def log(self, message):
        self.owner.town_log('[일반 사냥 이동] '+message)
        try:
            folder = Path(__file__).resolve().parent/'diagnostics'
            folder.mkdir(exist_ok=True)
            with (folder/'general_hunt.log').open('a', encoding='utf-8') as stream:
                stream.write(f'{datetime.now():%Y-%m-%d %H:%M:%S} [{self.owner.profile_id}] 창{self.handle} {self.owner.destination} {message}\n')
        except OSError:
            pass

    def save(self, image, label):
        try:
            folder = Path(__file__).resolve().parent/'diagnostics'
            folder.mkdir(exist_ok=True)
            image.save(folder/f'{datetime.now():%Y%m%d_%H%M%S}_{self.handle}_general_{label}.png')
        except OSError:
            pass

    def start(self, chained=False,force_leave=False,done=None):
        self.stop()
        if not chained:
            self.owner.winfo_toplevel().stop_all()
        self.handle = self.owner.window_link.hwnd
        if not self.handle:
            self.log('게임 창을 먼저 연결하세요.')
            return
        self.key = self.owner.general_key
        self.phase = 'inspect'
        self.force_leave=force_leave
        self.done=done
        reset_attendance(self)
        self.active = True
        self.hits = 0
        self.menu_hits = 0
        self.closed_start_menu = False
        self.closed_start_panel = False
        self.panel_close_until = 0
        self.clicked_auto = False
        self.seen_combat = False
        self.auto_point = None
        self.deadline = time.monotonic()+180
        self.limit = time.monotonic()+20
        self.hidden_since=None;self.focus_retry_at=0
        self.log(('연결된 창에서 ' if chained else '3초 후 ')+self.owner.travel+' · 화면 확인 후 진행')
        self.job = runner_after(self,50 if chained else 3000, self.tick)

    def change(self, phase, seconds=20):
        self.phase = phase
        self.hits = 0
        self.limit = time.monotonic()+seconds

    def stable(self, valid):
        self.hits = self.hits+1 if valid else 0
        return self.hits >= 2

    def finish(self, message, image=None,success=False):
        done=getattr(self,'done',None);self.done=None
        self.stop()
        if image is not None:
            self.save(image, self.phase)
        self.log(message)
        cycle=getattr(self.owner,'cycle_runner',None)
        if success and cycle is not None:
            cycle.general_pending=False
            cycle.general_force_leave=False
        elif (done is None and cycle is not None and getattr(cycle,'general_pending',False) and '연결 창' not in message
              and hasattr(cycle,'retry_general')):cycle.retry_general(message)
        if done is not None:done(success)

    def complete(self, image):
        self.owner.tree.set(self.owner.rows[-1], 'state', '자동 전투 확인')
        self.finish(self.owner.destination+' 도착·자동 전투 중 표시 확인 완료.', image,success=True)
        self.owner.winfo_toplevel().work_coordinator.handoff(self.owner)

    def tick(self):
        self.job = None
        if not self.active:
            return
        image = None
        try:
            if self.handle != self.owner.window_link.hwnd:
                raise RuntimeError('연결 창이 달라져 이동을 중지합니다.')
            if not ensure_view(self,check_game_view):
                self.job=runner_after(self,300,self.tick);return
            image = from_capture(capture(self.handle))
            if dismiss_attendance(self,image):
                self.job=runner_after(self,300,self.tick)
                return
            if self.phase in ('inspect','map_wait','overall','region','selected') and protect_hunt(self,image):return
            now = time.monotonic()
            # Even a stale force-leave/retry job must not evict a verified
            # running event. Hand it back to the event observer instead.
            scheduler=getattr(self.owner,'event_scheduler',None)
            if scheduler is not None and special_hud_timer(image)>=.78:
                current=scheduler.now()
                running=next((e for e in events_for(self.owner,current.date())
                              if event_location(image,e.key)>=.90),None)
                if running is not None:
                    cycle=getattr(self.owner,'cycle_runner',None)
                    if cycle is not None:
                        cycle.general_pending=False;cycle.general_force_leave=False
                    self.finish('현재 '+running.name+' 사냥 확인 · 일반사냥 전환 취소, 이벤트 사냥 유지')
                    if scheduler.active and running.start<=current.time()<running.end:
                        self.owner.event_runner.resume_after_entry(running,end_at(running,current))
                    return
            if now > self.deadline or now > self.limit:
                raise RuntimeError(self.phase+' 확인 시간 초과 · 이동·AUTO를 반복하지 않습니다.')
            if self.phase=='inspect' and now<self.panel_close_until:
                self.job=runner_after(self,300,self.tick)
                return
            if self.phase=='inspect' and not self.closed_start_panel and notice(image)<.70:
                panel=max(shop(image),warehouse(image),bag_panel(image))>=.88
                buying=purchase_dialog(image)
                depositing=deposit_dialog(image)
                if panel and not (buying[0]>=.88 and buying[1]>=.80) and not (depositing[0]>=.88 and depositing[1]>=.80):
                    if self.stable(True):
                        if bag_panel(image)>=.88:click_client_point(self.handle,785/800,16/600)
                        else:click_client_point(self.handle,.974,.035)
                        self.closed_start_panel=True
                        self.panel_close_until=now+3
                        self.change('inspect')
                        self.log('상점·창고·가방 화면 확인 → 닫기 → 일반 사냥 이동')
                    self.job=runner_after(self,300,self.tick)
                    return
            if max(notice(image), shop(image), warehouse(image), quest_travel(image)) >= .82:
                raise RuntimeError('알림·상점·창고 화면이 있어 이동을 중지합니다.')
            screen = world_map(image)
            if self.phase == 'inspect':
                if special_screen(image) >= .85:
                    self.menu_hits = 0
                    if self.stable(True):
                        click_client_point(self.handle, 774/800, 20/600)
                        self.log('특수지역 화면 닫기 → 필드 확인')
                        self.change('inspect')
                elif screen >= .85:
                    self.menu_hits = 0
                    if self.stable(True):
                        click_client_point(self.handle, 45/800, 64/600)
                        self.log('월드맵 확인 → 전체 탭 1회 클릭')
                        self.change('overall')
                elif special_icon(image)[0] >= .82:
                    # Closing the special-region panel can reveal the expanded
                    # right menu; its icons cover the minimap and field badges.
                    self.hits = 0
                    self.menu_hits += 1
                    if self.menu_hits >= 2 and not self.closed_start_menu:
                        self.save(image, 'expanded_menu')
                        click_client_point(self.handle, .976, .963)
                        self.closed_start_menu = True
                        self.menu_hits = 0
                        self.log('열린 전체 메뉴 연속 확인 → 메뉴 닫기 1회 → 미니맵·필드 재확인')
                        self.change('inspect')
                else:
                    self.menu_hits = 0
                    if special_hud_timer(image) >= .60 and not ordinary_departure(image,self.key):
                        raise RuntimeError('특수지역 시간이 남아 있어 일반 사냥터로 이동하지 않습니다.')
                    if general_location(image,self.key)>=.78 and (auto_control(image)[0]>=.78 or auto_mode(image)=='on') and hasattr(self.owner,'recovery_runner'):
                        self.phase='auto_recovery'
                        def recovered(success):
                            if success:self.complete(image)
                            else:self.finish('현재 일반 사냥터 AUTO 확인 실패 · 이동 반복 없음')
                        self.owner.recovery_runner.start(require='general',done=recovered)
                        return
                    return_place=(special_hud_timer(image)<.60 and max(town(image),event_return_location(image))>=.90)
                    if self.stable(ordinary_departure(image,self.key) or return_place):
                        click_client_point(self.handle, 715/800, 55/600)
                        self.log('필드 확인 → 미니맵 1회 클릭 → 월드맵 대기')
                        self.change('map_wait')
            elif self.phase == 'map_wait':
                if self.stable(screen >= .85):
                    click_client_point(self.handle, 45/800, 64/600)
                    self.log('월드맵 열림 확인 → 전체 탭 1회 클릭')
                    self.change('overall')
            elif self.phase == 'overall':
                score, x, y = world_destination(image, self.key)
                if self.stable(screen >= .85 and score >= .85):
                    self.save(image, 'world')
                    click_client_point(self.handle, x/800, y/600)
                    self.log('전체 지도 목적지 확인 → '+self.owner.destination.split(' · ')[0]+' 클릭')
                    self.change('region')
            elif self.phase == 'region':
                score, x, y = general_row(image, self.key)
                if self.stable(screen >= .85 and score >= .82):
                    click_client_point(self.handle, 100/800, y/600)
                    self.log('목록 목적지 이름 확인 → '+self.owner.destination+' 선택')
                    self.change('selected')
            elif self.phase == 'selected':
                score, x, y = general_row(image, self.key)
                valid = screen >= .85 and score >= .82 and general_row_selected(image, y)
                if self.stable(valid):
                    self.before_wallet = wallet(image)
                    self.save(image, 'before_move')
                    click_client_point(self.handle, 90/800, 573/600)
                    self.log('목적지 선택 테두리 확인 → 이동하기 1회 클릭')
                    self.change('arrival', 35)
            elif self.phase == 'arrival':
                location = general_location(image, self.key)
                score, x, y = auto_control(image)
                changed = wallet_similarity(self.before_wallet, wallet(image)) < .98
                valid = screen < .60 and (score >= .78 or auto_mode(image)=='on') and (location >= .78 or changed) and special_hud_timer(image) < .60
                self.seen_combat = self.seen_combat or (valid and combat_active(image) >= .80)
                if self.stable(valid):
                    self.save(image, 'arrival')
                    if hasattr(self.owner,'recovery_runner'):
                        self.phase='auto_recovery'
                        def recovered(success):
                            if success:self.complete(image)
                            else:self.finish('도착 후 AUTO 확인 실패 · 추가 클릭 없음')
                        self.owner.recovery_runner.start(require='general',done=recovered)
                        return
                    if self.seen_combat:
                        self.change('combat', 15)
                    else:
                        click_client_point(self.handle, x/800, y/600)
                        self.clicked_auto = True
                        self.log('선택한 목적지 이동 후 필드·재화 변화 또는 지역명 확인 → AUTO 1회 클릭')
                        self.change('combat', 15)
            elif self.phase == 'combat':
                if self.stable(screen < .60 and auto_control(image)[0] >= .78 and combat_active(image) >= .80):
                    self.complete(image)
                    return
            self.job = runner_after(self,300, self.tick)
        except Exception as exc:
            self.finish(str(exc), image)
