"""Prevent two controllers from competing for the same foreground games."""
import ctypes as c
from ctypes import wintypes as w
import atexit

k=c.WinDLL('kernel32',use_last_error=True)
u=c.WinDLL('user32',use_last_error=True)
k.CreateMutexW.argtypes=[c.c_void_p,w.BOOL,w.LPCWSTR];k.CreateMutexW.restype=w.HANDLE
k.CloseHandle.argtypes=[w.HANDLE];k.CloseHandle.restype=w.BOOL
callback_type=c.WINFUNCTYPE(w.BOOL,w.HWND,w.LPARAM)
u.EnumWindows.argtypes=[callback_type,w.LPARAM];u.EnumWindows.restype=w.BOOL
u.GetWindowTextLengthW.argtypes=[w.HWND];u.GetWindowTextLengthW.restype=c.c_int
u.GetWindowTextW.argtypes=[w.HWND,w.LPWSTR,c.c_int];u.GetWindowTextW.restype=c.c_int
u.MessageBoxW.argtypes=[w.HWND,w.LPCWSTR,w.LPCWSTR,w.UINT]
_mutex=None


def controller_exists():
    found=[]
    def visit(hwnd,_):
        size=u.GetWindowTextLengthW(hwnd)
        if size:
            text=c.create_unicode_buffer(size+1)
            u.GetWindowTextW(hwnd,text,size+1)
            if text.value.startswith(('HeroOfChosunClassic · 두 캐릭터 일정 관리 ·', 'HeroOfChosunClassic · 네 캐릭터 일정 관리 ·')):
                found.append(hwnd);return False
        return True
    u.EnumWindows(callback_type(visit),0)
    return bool(found)


def notify():
    u.MessageBoxW(None,'이미 실행 중인 관리 GUI가 있습니다. 시계 옆 트레이를 포함해 기존 GUI를 모두 종료한 뒤 한 개만 실행하세요.',
                  '중복 실행 방지',0x40)


def claim_controller():
    global _mutex
    c.set_last_error(0)
    handle=k.CreateMutexW(None,False,'Local\\HeroOfChosunClassicScheduleController')
    if not handle:return False
    if c.get_last_error()==183 or controller_exists():
        k.CloseHandle(handle);notify();return False
    _mutex=handle
    atexit.register(lambda:k.CloseHandle(handle))
    return True
