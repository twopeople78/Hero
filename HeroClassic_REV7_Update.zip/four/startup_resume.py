"""Attach the normal route after the automation-start AUTO check."""
from event_schedule import events_for


def resume_route(app,index,field):
    profile=app.profiles[index]
    if not profile.daily_scheduler.active:return
    if profile.resume_mode.get().startswith('추가 충전') and not profile.resume_applied:
        profile.startup_unresolved=False
        app.launch_remaining(index,scheduled=True);return
    profile.startup_unresolved=field=='unknown'
    scheduler=getattr(profile,'event_scheduler',None)
    if field!='unknown' and scheduler is not None and scheduler.active:
        now=scheduler.now()
        if any(e.start<=now.time()<e.end for e in events_for(profile,now.date())):
            if field in ('town','general'):scheduler.recheck_from_field(field)
            profile.town_log('[자동화 시작] 현재 이벤트 시간 · 현재 위치에 맞춰 이벤트 예약의 확인·진입 흐름 연결')
            return
    if field=='event_return':
        profile.town_log('[자동화 시작] 이벤트 복귀 위치 확인 → 설정 일반사냥터 이동·AUTO 확인')
        app.launch_general(index)
        return
    if field not in ('special','town','general'):
        profile.town_log('[자동화 시작] 현재 위치 판독 대기 · 화면 순회 시 다시 확인 · 임의 이동 없음')
        return
    daily=profile.daily_scheduler
    if field in ('town','general') and daily.now().time()<daily.special_time:
        profile.town_log('[자동화 시작] 특수지역 예약 시각 전 · 현재 위치 유지, 예약 일정 대기')
        return
    if (field in ('town','general') and getattr(daily,'failed',False)
            and getattr(daily,'supply_day',None)==daily.now().date()):
        profile.town_log('[자동화 시작] 오늘 보급 실패 기록 있음 · 추가 특수지역 입장 보류');return
    profile.town_log('[자동화 시작] '+('현재 특수지역 AUTO 확인 후 종료 관찰 연결' if field=='special' else
                                   '일반사냥 위치 확인 → 남은 기본 특수지역 자동 검사 · 모두 만료면 일반사냥 복귀' if field=='general' else
                                   '한밭마을 확인 → 남은 특수지역 검사, 모두 만료면 일반사냥 연결'))
    app.launch_remaining(index,scheduled=True)
