@echo off
setlocal
cd /d "%~dp0"
set "HERO4_PY=%~dp0.venv\Scripts\python.exe"
if not exist "%HERO4_PY%" (
  echo Python venv not found. Expected: %HERO4_PY%
  echo Extract this package into C:\HeroClassic next to the existing .venv folder.
  pause
  exit /b 1
)
"%HERO4_PY%" -c "import struct,sys; assert sys.version_info[:2]==(3,11) and struct.calcsize('P')==4; import tkinter,numpy,PIL"
if errorlevel 1 (
  echo Python 3.11 32-bit with tkinter, numpy and Pillow is required.
  echo Run: .venv\Scripts\python.exe -m pip install numpy Pillow
  pause
  exit /b 1
)
"%HERO4_PY%" "%~dp0four\run_four.py"
if errorlevel 1 pause
endlocal
