"""Independent daily clocks dispatch through the shared foreground queue."""
from datetime import datetime, timezone, timedelta
from pathlib import Path

KST = timezone(timedelta(hours=9))


class DailyScheduler:
    def __init__(self, owner):
        self.owner = owner
        self.active = False
        self.job = None

    def stop(self):
        was_active = self.active
        self.active = False
        if hasattr(self.owner,'reconnect_watch'):self.owner.reconnect_watch.stop()
        if hasattr(self.owner,'event_scheduler'):self.owner.event_scheduler.stop()
        app=self.owner.winfo_toplevel()
        if hasattr(app,'work_coordinator') and self.owner in app.profiles:
            app.work_coordinator.cancel_scheduled(app.profiles.index(self.owner))
        if self.job is not None:
            self.owner.after_cancel(self.job)
            self.job = None
        if hasattr(self.owner, 'reservation_status'):
            self.owner.reservation_status.set('매일 예약 꺼짐')
        if was_active:
            self.log('예약 꺼짐 · 현재 게임의 AUTO는 토글하지 않습니다.')

    def log(self, text):
        self.owner.town_log('[매일 예약] '+text)
        try:
            folder=Path(__file__).resolve().parent/'diagnostics'
            folder.mkdir(exist_ok=True)
            with (folder/'daily_schedule.log').open('a',encoding='utf-8') as stream:
                stream.write(f'{self.now():%Y-%m-%d %H:%M:%S %z} 창{getattr(self,"handle",0)} {text}\n')
        except OSError:
            pass

    def update_status(self, now):
        if self.failed and self.supply_day == now.date():
            state='오늘 보급 확인 실패 · 추가 특수지역 입장 중지'
        elif self.supply_started and self.supply_day == now.date() and not self.supply_ok:
            state='보급 진행·확인 대기'
        elif self.supply_ok and self.special_day != now.date():
            state='보급 완료 · 특수지역 '+self.special_time.strftime('%H:%M')+' 대기'
        else:
            state='사냥 유지'
        next_day=now.date() if now.time() < self.supply_time else now.date()+timedelta(days=1)
        self.owner.reservation_status.set(
            f'매일 예약 켜짐 · {state} · 다음 보급 {next_day:%m/%d} {self.supply_time:%H:%M} / 특수지역 {self.special_time:%H:%M} (한국 시간)')

    @staticmethod
    def now():
        return datetime.now(KST)

    def arm(self):
        if not self.owner.window_link.hwnd:
            self.owner.town_log('[매일 예약] 게임 창을 먼저 연결하세요. 예약을 켜지 않았습니다.')
            return
        try:
            self.supply_time = datetime.strptime(self.owner.supply.get(), '%H:%M').time()
            self.special_time = datetime.strptime(self.owner.start.get(), '%H:%M').time()
            if self.special_time <= self.supply_time:
                raise ValueError('특수지역 시작 시각은 보급 시각보다 뒤여야 합니다.')
        except ValueError as exc:
            self.owner.town_log('[매일 예약] 시간 설정 오류 · '+str(exc))
            return
        self.stop()
        self.handle=self.owner.window_link.hwnd
        # Two profiles may be armed, but never against the same game window.
        for profile in self.owner.winfo_toplevel().profiles:
            if (profile is not self.owner and profile.daily_scheduler.active and
                    profile.window_link.hwnd == self.handle):
                self.log('같은 게임 창이 다른 캐릭터 예약에 연결되어 예약을 켜지 않았습니다.')
                return
        now = self.now()
        self.supply_day = now.date() if now.time() >= self.supply_time else None
        self.special_day = now.date() if now.time() >= self.special_time else None
        self.attendance_day=now.date() if now.time()>=datetime.strptime('05:00','%H:%M').time() else None
        self.supply_ok = False
        self.supply_started = False
        self.failed = False
        self.active = True
        if hasattr(self.owner,'reconnect_watch'):self.owner.reconnect_watch.start()
        self.update_status(now)
        self.log('켜짐 · 현재 사냥 유지 · 이미 지난 당일 시각은 소급 실행하지 않습니다. 프로그램을 켜두세요.')
        self.job = self.owner.after(1000, self.tick)
        if hasattr(self.owner,'event_scheduler') and self.owner.event_enabled.get():
            self.owner.event_scheduler.arm()
        app=self.owner.winfo_toplevel()
        self.owner.startup_unresolved=True
        if hasattr(app,'launch_recovery'):app.launch_recovery(app.profiles.index(self.owner),scheduled=True,resume_route=True)
        if any(p.daily_scheduler.active for p in app.profiles):
            app.dual_runner.start()

    def supply_complete(self):
        if self.active:
            self.supply_ok = True
            self.log('보급 완료 · '+self.special_time.strftime('%H:%M')+' 특수지역 시작 대기')
            self.update_status(self.now())

    def supply_failed(self, reason):
        if self.active:
            self.failed = True
            self.log('오늘 보급 확인 실패 · 추가 입장을 시작하지 않습니다. '+reason)
            self.update_status(self.now())

    def tick(self):
        self.job = None
        if not self.active:
            return
        now = self.now()
        day = now.date()
        app = self.owner.winfo_toplevel()
        index = app.profiles.index(self.owner)
        if self.owner.window_link.hwnd != self.handle:
            self.stop()
            self.log('연결된 게임 창이 바뀌어 예약 해제 · 연결 확인 후 다시 예약을 켜세요.')
            return
        if now.time() >= self.supply_time and self.supply_day != day:
            self.supply_day = day
            self.supply_ok = False
            self.supply_started = True
            self.failed = False
            self.log('보급 시각 도달 → 게임 활성화·한밭마을 복귀')
            app.launch_supply(index, scheduled=True)
        if (now.hour>=5 and getattr(self,'attendance_day',None)!=day):
            self.attendance_day=day
            self.log('05:00 출석창 확인 예약 → 제목·닫기 위치 확인 후 닫기')
            app.work_coordinator.submit(index,'05시 출석창 확인',
                self.owner.attendance_runner.start,scheduled=True)
        if (self.active and now.time() >= self.special_time and self.special_day != day
                and self.supply_day == day):
            if self.supply_ok:
                self.special_day = day
                self.log('특수지역 시작 시각 도달 → 현재 이용시간 재검사')
                app.launch_remaining(index, scheduled=True)
            elif self.failed:
                self.special_day = day
        if self.active:
            self.update_status(now)
            self.job = self.owner.after(1000, self.tick)
