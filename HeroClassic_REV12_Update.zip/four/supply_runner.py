from movement_guard import protect_hunt,ordinary_departure
from runner_timer import runner_after, invalidate
from attendance import dismiss_attendance, reset_attendance
"""Town return and the existing observed supply legs, followed by daily regions."""
import time
from pathlib import Path
from datetime import datetime
import numpy as np
from window_link import capture
from game_actions import check_game_view, click_client_point
from buy_runner import wallet_similarity
from vision import (from_capture, town, auto_control, world_map, locate,
                    special_screen, special_icon, special_hud_timer, notice, shop, warehouse,
                    no_buy_items, purchase_dialog, bag_panel, general_location)


class SupplyRunner:
    def __init__(self, owner):
        self.owner = owner
        self.active = False
        self.job = None

    def stop(self):
        invalidate(self)
        self.active = False
        if self.job is not None:
            self.owner.after_cancel(self.job)
            self.job = None

    def log(self, message):
        self.owner.town_log('[보급·전체 흐름] '+message)
        try:
            folder = Path(__file__).resolve().parent/'diagnostics'
            folder.mkdir(exist_ok=True)
            with (folder/'supply_cycle.log').open('a', encoding='utf-8') as stream:
                stream.write(f'{datetime.now():%Y-%m-%d %H:%M:%S} [{self.owner.profile_id}] 창{self.handle} {message}\n')
        except OSError:
            pass

    def save(self, image, label):
        try:
            folder = Path(__file__).resolve().parent/'diagnostics'
            folder.mkdir(exist_ok=True)
            image.save(folder/f'{datetime.now():%Y%m%d_%H%M%S}_{self.handle}_supply_{label}.png')
        except OSError:
            pass

    def start(self, scheduled=False, supply_only=False):
        self.stop()
        self.handle = self.owner.window_link.hwnd
        if not self.handle:
            self.log('게임 창을 먼저 연결하세요.')
            return
        reset_attendance(self)
        self.active = True
        self.scheduled = scheduled
        self.supply_only = supply_only
        self.bag_hits = 0
        self.departure_hits = 0
        self.closed_start_bag = False
        self.phase = 'inspect'
        self.hits = 0
        self.menu_hits = 0
        self.closed_start_menu = False
        self.last_trace = 0
        self.deadline = time.monotonic()+100
        self.limit = time.monotonic()+25
        self.log(('복자할매·주모 보급만 시작' if supply_only else '예약 보급 시작' if scheduled else '지금 전체 순회 시작')+' → 한밭마을 복귀·복자할매·주모 순서')
        self.owner.tree.set(self.owner.rows[0], 'state', '마을 복귀 확인')
        self.job = runner_after(self,1000, self.tick)

    @staticmethod
    def scene(image):
        return np.asarray(image.convert('L'), dtype=np.float64)[110:520, 220:760].copy()

    def stable(self, valid):
        self.hits = self.hits+1 if valid else 0
        return self.hits >= 2

    def change(self, phase, seconds=20):
        self.phase = phase
        self.hits = 0
        self.limit = time.monotonic()+seconds

    def fail(self, message, image=None):
        was_active = self.active
        self.stop()
        if image is not None:
            self.save(image, 'failed')
        self.log('중지 · '+message)
        if was_active and getattr(self, 'scheduled', False):
            self.owner.daily_scheduler.supply_failed(message)

    def grandma(self):
        self.phase = 'grandma'
        self.job = None
        self.owner.tree.set(self.owner.rows[0], 'state', '복자할매 탐색')
        self.log('한밭마을 도착 확인 → 복자할매 → 보관 → 주모 → 구매')
        self.owner.npc_runner.start(chained=True)

    def purchased(self):
        scheduled = self.scheduled
        self.stop()
        self.owner.tree.set(self.owner.rows[0], 'state', '보관 완료')
        self.owner.tree.set(self.owner.rows[1], 'state', '구매·닫기 완료')
        if self.supply_only:
            self.log('복자할매·주모 보급만 완료 · 특수지역 입장으로 연결하지 않습니다.')
        elif scheduled:
            self.log('보급 완료 → 예약된 특수지역 시작 시각 대기')
            self.owner.daily_scheduler.supply_complete()
        else:
            self.log('보급 완료 → 예약 시각 대기 없이 남은 특수지역 순회 시작')
            self.owner.cycle_runner.start_remaining(chained=True)

    def tick(self):
        self.job = None
        if not self.active:
            return
        image = None
        try:
            if self.handle != self.owner.window_link.hwnd:
                raise RuntimeError('연결 창이 달라졌습니다.')
            check_game_view(self.handle)
            image = from_capture(capture(self.handle))
            if dismiss_attendance(self,image):
                self.job=runner_after(self,900,self.tick)
                return
            if self.phase in ('inspect','map_wait','selected') and protect_hunt(self,image):return
            now = time.monotonic()
            if now > self.deadline or now > self.limit:
                raise RuntimeError(self.phase+' 확인 시간 초과 · 이동·구매를 반복하지 않습니다.')
            screen = world_map(image)
            field = auto_control(image)[0]
            town_score = town(image)
            if (self.phase == 'inspect' and notice(image) >= .82 and
                    shop(image) >= .88 and no_buy_items(image) >= .90):
                title, cost = purchase_dialog(image)
                if title >= .88 and cost >= .80:
                    raise RuntimeError('구매창과 알림 판독이 겹쳐 중지했습니다.')
                if self.stable(True):
                    self.save(image, 'resume_no_buy_items')
                    self.phase = 'buy'
                    self.log('이미 열린 주모 구매 불필요 알림 확인 → 확인·상점 닫기부터 이어가기')
                    self.owner.buy_runner.start(chained=True)
                    return
                self.job = runner_after(self,900, self.tick)
                return
            if max(notice(image), shop(image), warehouse(image)) >= .85:
                raise RuntimeError('열린 알림·상점·창고를 닫고 시작하세요.')
            if self.phase == 'inspect':
                if bag_panel(image) >= .88:
                    self.hits = 0
                    self.menu_hits = 0
                    self.bag_hits += 1
                    if self.bag_hits >= 2 and not self.closed_start_bag:
                        self.save(image,'start_bag')
                        click_client_point(self.handle,785/800,16/600)
                        self.closed_start_bag = True
                        self.change('inspect')
                        self.log('열린 가방 연속 확인 → 닫기 1회 → 출발 화면 재확인')
                elif screen >= .85 or special_screen(image) >= .85:
                    self.bag_hits = 0
                    self.menu_hits = 0
                    if self.stable(True):
                        click_client_point(self.handle, 774/800, 20/600)
                        self.change('inspect')
                elif special_icon(image)[0] >= .82:
                    self.bag_hits = 0
                    # The expanded right menu covers both town name and AUTO
                    # badges. Identify its special-region icon independently
                    # before requiring the field HUD hidden underneath it.
                    self.hits = 0
                    self.menu_hits += 1
                    if self.menu_hits >= 2 and not self.closed_start_menu:
                        self.save(image, 'start_menu')
                        click_client_point(self.handle, .976, .963)
                        self.closed_start_menu = True
                        self.menu_hits = 0
                        self.change('inspect')
                        self.log('열린 전체 메뉴 연속 확인 → 메뉴 닫기 1회 → 한밭마을·사냥 화면 재확인')
                elif field >= .78 or general_location(image,self.owner.general_key)>=.85 or town_score>=.90:
                    self.bag_hits = 0
                    self.menu_hits = 0
                    if self.stable(town_score >= .78):
                        self.save(image, 'town')
                        self.grandma()
                        return
                    self.departure_hits=self.departure_hits+1 if town_score<.78 and ordinary_departure(image,self.owner.general_key) else 0
                    if self.departure_hits>=2:
                        click_client_point(self.handle, 715/800, 55/600)
                        self.log('일반 사냥 화면 → 미니맵 클릭 → 월드맵 대기')
                        self.change('map_wait')
                else:
                    self.bag_hits = 0
                    self.hits = 0
                    self.menu_hits = 0
                if self.phase == 'inspect' and now-self.last_trace >= 5:
                    self.last_trace = now
                    self.save(image, 'inspect_wait')
                    self.log(f'시작 화면 확인 중 · 지도 {screen:.2f} / 필드 {field:.2f} / 한밭 {town_score:.2f} · 다른 창에 가리지 않게 두세요.')
            elif self.phase == 'map_wait':
                shortcut, x, y = locate(image, 'town_shortcut', (600, 35, 695, 95))
                if self.stable(screen >= .85 and shortcut >= .85):
                    self.before_scene = self.scene(image)
                    self.save(image, 'before_town_select')
                    click_client_point(self.handle, x/800, y/600)
                    self.log('한밭마을 바로가기 이름·아이콘 확인 → 선택 1회')
                    self.change('selected')
            elif self.phase == 'selected':
                changed = wallet_similarity(self.before_scene, self.scene(image)) < .92
                move, x, y = locate(image, 'map_move_label', (20, 550, 115, 599))
                if self.stable(screen >= .85 and changed and move >= .80):
                    self.save(image, 'town_selected')
                    click_client_point(self.handle, 90/800, 573/600)
                    self.log('한밭마을 선택 후 지도 변화·이동하기 확인 → 이동 1회')
                    self.change('arrival', 35)
            elif self.phase == 'arrival':
                if self.stable(screen < .60 and field >= .78 and town_score >= .78):
                    self.save(image, 'arrival')
                    self.grandma()
                    return
            self.job = runner_after(self,900, self.tick)
        except Exception as exc:
            self.fail(str(exc), image)
