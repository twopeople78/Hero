"""No Windows input is sent. Pure logic + Win32/Tk stand-in integration tests."""
import ctypes
import importlib
import sys
import tempfile
import unittest
from collections import defaultdict
from datetime import date
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import Mock, patch

ROOT=Path(__file__).resolve().parents[1]/'four'
sys.path.insert(0,str(ROOT))
# This suite deliberately substitutes every Win32 DLL, including on Windows.
class DLL:
    def __init__(self):self.functions={}
    def __getattr__(self,name):return self.functions.setdefault(name,Mock(return_value=0))
ctypes.WinDLL=lambda *a,**k:DLL()
ctypes.WINFUNCTYPE=ctypes.CFUNCTYPE
ctypes.set_last_error=lambda code:None
ctypes.get_last_error=lambda:0

import tkinter as tk
from tkinter import ttk
class Var:
    def __init__(self,*a,value=None,**k):self.value=value
    def get(self):return self.value
    def set(self,value):self.value=value
class Widget:
    def __init__(self,master=None,**kwargs):
        self.master=master;self.config=dict(kwargs);self.items={};self.selection=-1
        if master is None:self.jobs={};self.seq=0
    def winfo_toplevel(self):return self.master.winfo_toplevel() if self.master else self
    def after(self,delay,func,*args):
        root=self.winfo_toplevel();root.seq+=1;root.jobs[root.seq]=(func,args);return root.seq
    def after_cancel(self,job):self.winfo_toplevel().jobs.pop(job,None)
    def after_idle(self,callback):return self.after(0,callback)
    def configure(self,*a,**kw):self.config.update(kw)
    def cget(self,key):return self.config.get(key,0)
    def __setitem__(self,key,val):self.config[key]=val
    def __getitem__(self,key):return self.config[key]
    def current(self,index=None):
        if index is not None:self.selection=index
        return self.selection
    def set(self,*a):
        if len(a)==3:self.items.setdefault(a[0],{})[a[1]]=a[2]
    def insert(self,*a,**kw):key=str(len(self.items));self.items[key]=kw;return key
    def winfo_children(self):return []
    def winfo_ismapped(self):return True
    def winfo_exists(self):return True
    def __getattr__(self,name):
        if name in {'title','geometry','minsize','bind','bind_all','pack','grid','columnconfigure','protocol','theme_use','map','heading','column','add','create_window','yview','yview_scroll','itemconfigure','see','destroy'}:return lambda *a,**k:None
        raise AttributeError(name)
for name in ('Tk','Toplevel','Text','Canvas'):
    setattr(tk,name,type(name,(Widget,),{}))
for name in ('Frame','LabelFrame','Label','Notebook','Scrollbar','Treeview','Button','Checkbutton','Combobox','Entry','Style'):
    setattr(ttk,name,type(name,(Widget,),{}))
tk.StringVar=tk.BooleanVar=Var

import chosun_gui as gui
import profile_settings as settings
import session_state
from event_schedule import events_for
from dual_runner import DualRunner
from work_coordinator import WorkCoordinator
from focus_guard import focus_allowed
import game_actions
import window_link

class QuietTray:
    available=False
    def __init__(self,app):pass
    def update(self):pass
    def close(self):pass
class QuietWatch:
    status='disabled'
    def __init__(self,app):pass
    def pause(self):pass
    def close(self):pass

class FourTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.patches=[patch.object(settings,'SETTINGS',Path(self.tmp.name)/'profiles.json'),
                      patch.object(session_state,'FILE',Path(self.tmp.name)/'session.json'),
                      patch.object(gui,'DesktopTray',QuietTray),patch.object(gui,'StallWatch',QuietWatch),
                      patch.object(window_link,'windows',return_value=[])]
        for p in self.patches:p.start();self.addCleanup(p.stop)
        self.app=gui.App()
    def bind_all(self):
        for i,p in enumerate(self.app.profiles):
            p.configured=True;p.window_link.hwnd=100+i;p.window_link.valid=Mock(return_value=True)
    def test_four_tabs_and_initial_no_assignment(self):
        self.assertEqual([p.profile_id for p in self.app.profiles],['char1','char2','char3','char4'])
        self.assertEqual(len(self.app.shared_status),4)
        self.assertEqual([p.window_link.hwnd for p in self.app.profiles],[None]*4)
        self.assertTrue(all(not p.configured for p in self.app.profiles))
        self.assertFalse(self.app.profile_ready(self.app.profiles[0]))
    def test_settings_are_independent(self):
        routes=[('영혼의 동굴','2층')]
        settings.save_routes(routes,'char1');settings.save_routes([('영혼의 동굴','4층')],'char4')
        self.assertEqual(settings.load_routes(routes,'char1'),routes)
        self.assertEqual(settings.load_routes(routes,'char4'),[('영혼의 동굴','4층')])
        self.assertEqual(settings.load_routes(routes,'char2'),routes)
        settings.update('char3',general='ship',events=['nijo'])
        self.assertNotIn('general',settings.get('char1'))
    def test_event_choices_not_side_dependent(self):
        p=self.app.profiles[3];p.selected_events={'abandoned','gadeok','nijo'}
        self.assertEqual([e.key for e in events_for(p,date(2026,10,28))],['abandoned','nijo'])
        self.assertEqual([e.key for e in events_for(p,date(2026,10,27))],['abandoned','gadeok'])
        self.assertEqual(events_for(self.app.profiles[0],date(2026,10,27)),())
    def test_refresh_preserves_manual_mapping(self):
        self.bind_all();before=[p.window_link.hwnd for p in self.app.profiles]
        self.app.auto_connect();self.assertEqual(before,[p.window_link.hwnd for p in self.app.profiles])
    def test_lost_window_only_stops_its_profile(self):
        self.bind_all();p=self.app.profiles[2]
        for item in self.app.profiles:item.daily_scheduler.stop=Mock();item.stop=Mock()
        p.window_link.valid.return_value=False
        self.app.auto_connect()
        self.assertIsNone(p.window_link.hwnd);p.stop.assert_called_once()
        for index in (0,1,3):
            self.assertEqual(self.app.profiles[index].window_link.hwnd,100+index)
            self.app.profiles[index].stop.assert_not_called()
    def test_duplicate_mapping_rejected(self):
        self.bind_all();self.app.profiles[3].window_link.hwnd=100
        self.assertFalse(self.app.profile_ready(self.app.profiles[3]))
    def test_four_armed_through_coordinator(self):
        self.bind_all()
        for p in self.app.profiles:p.selected_events=set()
        self.app.arm_both_daily()
        self.assertTrue(all(p.daily_scheduler.active for p in self.app.profiles))
        self.assertEqual({r['index'] for r in self.app.work_coordinator.pending},{0,1,2,3})
        self.assertTrue(self.app.dual_runner.active)
    def test_observation_rotates_without_stopping_hunts(self):
        self.bind_all();dual=self.app.dual_runner;dual.active=True
        for p in self.app.profiles:
            p.daily_scheduler.active=True;p.stop=Mock()
        targets=[]
        def focus(handle,ready,failed,say):targets.append(handle);ready()
        with patch.object(self.app.focus_runner,'start',side_effect=focus),patch('dual_runner.time.monotonic',return_value=100):
            for _ in range(4):
                dual.due=0;dual.next_attempt=0;dual.tick_once()
        self.assertEqual(targets,[100,101,102,103])
        for p in self.app.profiles:p.stop.assert_not_called()
    def test_pending_work_prevents_observation_switch(self):
        self.bind_all();dual=self.app.dual_runner
        for p in self.app.profiles:p.daily_scheduler.active=True
        self.app.work_coordinator.pending.append({'index':0})
        with patch.object(self.app.focus_runner,'start') as start:
            dual.tick_once();start.assert_not_called()
    def test_entry_lock_prevents_other_character_focus(self):
        self.bind_all();p=self.app.profiles[1];p.entry_runner.active=True
        self.assertFalse(focus_allowed(self.app,100));self.assertTrue(focus_allowed(self.app,101))
    def test_coordinator_only_stops_target_not_other_observers(self):
        self.bind_all();calls=[]
        for p in self.app.profiles:p.stop=Mock()
        self.app.work_coordinator.submit(2,'test',lambda:calls.append('action'))
        def focus(handle,ready,failed,say):self.assertEqual(handle,102);ready()
        with patch.object(self.app.focus_runner,'start',side_effect=focus):self.app.work_coordinator.tick_once()
        self.assertEqual(calls,['action']);self.app.profiles[2].stop.assert_called_once()
        for i in (0,1,3):self.app.profiles[i].stop.assert_not_called()
    def test_cancel_one_profile_preserves_others_queued(self):
        self.bind_all();q=self.app.work_coordinator
        for i in range(4):q.submit(i,'request',lambda:None)
        q.cancel_profile(1)
        self.assertEqual([r['index'] for r in q.pending],[0,2,3])
    def test_manual_charged_resume_does_not_enter(self):
        self.bind_all();p=self.app.profiles[0];c=p.cycle_runner
        p.resume_mode.set('추가 충전 중 · 종료 후 일반사냥');p.resume_region.set(p.routes[3][0])
        with patch.object(c,'log'),patch.object(p.special_runner,'start') as entry:
            c.start_remaining(chained=True)
            self.assertTrue(c.charged_hunt);self.assertEqual(c.required_expired,3)
            self.assertTrue(p.resume_applied);entry.assert_not_called()
    def test_charged_return_queues_general_without_scan(self):
        self.bind_all();p=self.app.profiles[0];c=p.cycle_runner
        c.active=True;c.phase='observe';c.required_expired=2;c.charged_hunt=True;c.completed_indices=set()
        with patch.object(c,'log'),patch.object(p.general_runner,'start') as general,patch.object(p.special_runner,'start') as scan:
            c.inspect();request=self.app.work_coordinator.pending.popleft();request['action']()
            general.assert_called_once_with(chained=True);scan.assert_not_called()
        self.assertEqual(p.resume_mode.get(),'기본 순회')
        self.assertFalse(session_state.note(p)['charged'])
    def test_covered_game_never_captured(self):
        with patch.object(game_actions,'check_game_view',side_effect=RuntimeError('가려져')),patch.object(window_link.g,'BitBlt') as blt:
            with self.assertRaises(RuntimeError):window_link.capture(100)
            blt.assert_not_called()
    def test_wrong_size_blocks_game_input(self):
        with patch('window_identity.validate'),patch.object(game_actions,'require_admin'),patch.object(game_actions,'title',return_value='HeroOfChosunClassic'),patch.object(game_actions.u,'GetForegroundWindow',return_value=100),patch.object(game_actions,'bounds',return_value=(0,0,1024,768)),patch.object(game_actions.u,'SendInput') as send:
            with self.assertRaises(RuntimeError):game_actions.check_game_view(100)
            send.assert_not_called()
    def test_build_has_no_original_settings_or_secrets(self):
        self.assertFalse((ROOT/'hunting_floors.json').exists())
        self.assertFalse((ROOT/'telegram_alerts.json').exists())
    def test_unlinked_or_reused_handle_rejected_before_input(self):
        import window_identity
        with patch.object(game_actions,'require_admin'),patch.object(game_actions.u,'SendInput') as send:
            window_identity.authorized[100]=(100,12,34)
            with patch.object(window_identity,'identity',return_value=(100,99,100)):
                with self.assertRaises(RuntimeError):game_actions.check_game_view(100)
            send.assert_not_called()
        window_identity.authorized.clear()
    def test_individual_stop_keeps_other_schedules(self):
        self.bind_all()
        for p in self.app.profiles:p.daily_scheduler.active=True
        self.app.profiles[1].stop_profile()
        self.assertFalse(self.app.profiles[1].daily_scheduler.active)
        self.assertTrue(all(self.app.profiles[i].daily_scheduler.active for i in (0,2,3)))
    def test_partial_daily_schedule_starts_read_rotation(self):
        self.bind_all();self.app.arm_daily(3)
        self.assertTrue(self.app.profiles[3].daily_scheduler.active)
        self.assertFalse(self.app.profiles[0].daily_scheduler.active)
        self.assertTrue(self.app.dual_runner.active)
    def test_requested_display_order(self):
        self.assertEqual([p.display_name for p in self.app.profiles],['좌상 · 캐릭터1','우상 · 캐릭터2','좌하 · 캐릭터3','우하 · 캐릭터4'])
    def test_layout_order_is_independent_of_enum_order(self):
        from layout_binding import ordered_handles
        entries=[(104,1120,450,800,600),(102,1121,31,800,600),(103,12,466,800,600),(101,14,36,800,600)]
        self.assertEqual(ordered_handles(entries),[101,102,103,104])
    def test_layout_rejects_ambiguous_or_missing_windows(self):
        from layout_binding import ordered_handles
        with self.assertRaises(ValueError):ordered_handles([(1,0,0,800,600)]*4)
        with self.assertRaises(ValueError):ordered_handles([(i,0,0,800,600) for i in range(4)])
    def test_one_click_layout_commits_correct_profiles(self):
        import window_identity
        positions={104:(1120,450,800,600),102:(1121,31,800,600),103:(12,466,800,600),101:(14,36,800,600)}
        with patch.object(gui,'windows',return_value=[(h,'game') for h in positions]),patch.object(gui,'bounds',side_effect=lambda h:positions[h]),patch.object(window_identity,'identity',side_effect=lambda h:(h,h,1)):
            self.app.connect_by_layout()
        self.assertEqual([p.window_link.hwnd for p in self.app.profiles],[101,102,103,104])
        window_identity.authorized.clear()
    def test_default_switch_gap_is_thirty_seconds(self):
        self.assertEqual(self.app.observation_seconds(),30)
        self.bind_all();dual=self.app.dual_runner;dual.active=True
        for p in self.app.profiles:p.daily_scheduler.active=True
        def focus(handle,ready,failed,say):ready()
        with patch.object(self.app.focus_runner,'start',side_effect=focus) as start:
            with patch('dual_runner.time.monotonic',return_value=100):dual.tick_once()
            self.assertEqual(start.call_count,1)
            with patch('dual_runner.time.monotonic',return_value=129):dual.tick_once()
            self.assertEqual(start.call_count,1)
            with patch('dual_runner.time.monotonic',return_value=130):dual.tick_once()
            self.assertEqual(start.call_count,2)
    def test_switch_interval_is_saved_and_applied(self):
        self.app.observation_interval_var.set('180')
        self.app.change_observation_interval()
        self.assertEqual(self.app.observation_seconds(),180)
        self.assertEqual(settings.get('_app')['observation_switch_seconds'],180)
    def test_focus_failure_retry_is_throttled(self):
        self.bind_all();q=self.app.work_coordinator;q.submit(2,'startup',lambda:None)
        def focus(handle,ready,failed,say):failed('창 전환 확인 시간 초과 · test')
        with patch.object(self.app.focus_runner,'start',side_effect=focus),patch('work_coordinator.time.monotonic',return_value=100):
            q.tick_once()
        self.assertFalse(q.active)
        self.assertEqual(q.pending[0]['not_before'],220)
    def test_offscreen_position_fits_without_resize(self):
        from window_layout import fitted_position
        self.assertEqual(fitted_position((0,430,800,1066),(0,0,1920,1040)),(0,404))
        self.assertEqual(fitted_position((1100,400,1900,1036),(0,0,1920,1040)),(1100,400))
        self.assertEqual(fitted_position((-1930,400,-1130,1036),(-1920,0,0,1040)),(-1920,400))
        with self.assertRaises(RuntimeError):fitted_position((0,0,800,636),(0,0,700,600))
    def test_fit_uses_move_only_no_input_or_resize(self):
        import window_layout
        def get_rect(handle,pointer):
            pointer._obj.left=0;pointer._obj.top=430;pointer._obj.right=800;pointer._obj.bottom=1066;return True
        def get_monitor(handle,pointer):
            pointer._obj.work.left=0;pointer._obj.work.top=0;pointer._obj.work.right=1920;pointer._obj.work.bottom=1040;return True
        with patch('window_identity.validate'),patch.object(window_layout.u,'MonitorFromWindow',return_value=1),patch.object(window_layout.u,'GetMonitorInfoW',side_effect=get_monitor),patch.object(window_layout.u,'GetWindowRect',side_effect=get_rect),patch.object(window_layout.u,'SetWindowPos',return_value=1) as move,patch.object(game_actions.u,'SendInput') as send:
            self.assertIn('보정',window_layout.ensure_on_screen(100))
            move.assert_called_once_with(100,None,0,404,0,0,0x0001|0x0004|0x0010)
            send.assert_not_called()
    def test_only_one_foreground_request_per_failed_attempt(self):
        self.bind_all();focus=self.app.focus_runner;clock=[100]
        with patch('focus_runner.time.monotonic',side_effect=lambda:clock[0]),patch('focus_runner.ensure_on_screen',return_value=None),patch('focus_runner.request_game_foreground',return_value=True) as request,patch('focus_runner.check_game_view',side_effect=RuntimeError('게임 화면이 다른 창에 가려져 중지했습니다.')),patch.object(focus,'log'):
            failure=Mock();focus.start(100,Mock(),failure,Mock())
            for t in (100,103,106,109,112):clock[0]=t;focus.tick()
            request.assert_called_once_with(100);failure.assert_called_once()
    def test_retry_cooldown_covers_all_requests_for_same_profile(self):
        self.bind_all();q=self.app.work_coordinator;q.retry_at[2]=220
        q.submit(2,'startup',lambda:None);q.submit(2,'manual special',lambda:None)
        self.assertFalse(q.ready_pending(101))
        with patch('work_coordinator.time.monotonic',return_value=101),patch.object(self.app.focus_runner,'start') as start:
            q.tick_once();start.assert_not_called()
        q.submit(1,'other profile',lambda:None)
        self.assertTrue(q.ready_pending(101))
    def test_occlusion_diagnostic_records_position(self):
        with patch('window_identity.validate'),patch.object(game_actions,'require_admin'),patch.object(game_actions,'title',return_value='HeroOfChosunClassic'),patch.object(game_actions.u,'GetForegroundWindow',return_value=100),patch.object(game_actions,'bounds',return_value=(12,466,800,600)),patch.object(game_actions.u,'GetAncestor',return_value=0):
            with self.assertRaisesRegex(RuntimeError,'내부\\(0,0\\).*화면\\(12,466\\)'):
                game_actions.check_game_view(100)
    def test_unknown_startup_waits_for_multiple_frames_without_input(self):
        import recovery_runner as module
        self.bind_all();p=self.app.profiles[0];runner=p.recovery_runner;done=Mock()
        constants={'notice':0,'shop':0,'warehouse':0,'special_screen':0,'world_map':0,'quest_travel':0,'bag_panel':0,'special_icon':(0,0,0),'auto_control':(0,0,0),'auto_mode':'unknown','combat_active':0,'special_hud_timer':0,'general_location':0,'town':0,'town_minimap_score':0,'event_return_location':0}
        from contextlib import ExitStack
        with ExitStack() as stack:
            for name,value in constants.items():stack.enter_context(patch.object(module,name,return_value=value))
            stack.enter_context(patch.object(module,'ensure_view',return_value=True))
            stack.enter_context(patch.object(module,'capture',return_value=b'fake'))
            stack.enter_context(patch.object(module,'from_capture',return_value=Mock()))
            stack.enter_context(patch.object(module,'dismiss_attendance',return_value=False))
            stack.enter_context(patch.object(runner,'log'))
            click=stack.enter_context(patch.object(module,'click_client_point'))
            runner.start(done=done)
            for _ in range(7):runner.tick()
            done.assert_not_called();self.assertTrue(runner.active)
            runner.tick();done.assert_called_once_with(False);click.assert_not_called()
    def test_auto_already_on_can_recover_unresolved_startup(self):
        import reconnect_watch as module
        from contextlib import ExitStack
        self.bind_all();p=self.app.profiles[0];p.daily_scheduler.active=True;p.startup_unresolved=True
        watcher=p.reconnect_watch
        constants={'auto_control':(.95,770,120),'auto_mode':'on','special_hud_timer':.95,'general_location':0,'notice':0,'shop':0,'warehouse':0,'special_screen':0,'world_map':0,'bag_panel':0,'special_icon':(0,0,0)}
        with ExitStack() as stack:
            for name,value in constants.items():stack.enter_context(patch.object(module,name,return_value=value))
            stack.enter_context(patch.object(module,'check_game_view'))
            stack.enter_context(patch.object(module,'capture',return_value=b'fake'))
            stack.enter_context(patch.object(module,'from_capture',return_value=Mock()))
            stack.enter_context(patch.object(module,'note_frame'))
            launch=stack.enter_context(patch.object(self.app,'launch_recovery'))
            watcher.start();watcher.tick();launch.assert_not_called();watcher.tick()
            launch.assert_called_once_with(0,scheduled=True,resume_route=True)
    def test_visible_town_rechecks_only_unresolved_startup(self):
        import reconnect_watch as module
        from contextlib import ExitStack
        self.bind_all();p=self.app.profiles[0];p.daily_scheduler.active=True
        constants={'auto_control':(.95,770,120),'auto_mode':'off','special_hud_timer':0,
                   'general_location':0,'town':.98,'notice':0,'shop':0,'warehouse':0,
                   'special_screen':0,'world_map':0,'bag_panel':0,'special_icon':(0,0,0)}
        with ExitStack() as stack:
            for name,value in constants.items():stack.enter_context(patch.object(module,name,return_value=value))
            stack.enter_context(patch.object(module,'check_game_view'))
            stack.enter_context(patch.object(module,'capture',return_value=b'fake'))
            stack.enter_context(patch.object(module,'from_capture',return_value=Mock()))
            stack.enter_context(patch.object(module,'note_frame'))
            launch=stack.enter_context(patch.object(self.app,'launch_recovery'))
            p.startup_unresolved=False;p.reconnect_watch.start()
            p.reconnect_watch.tick();p.reconnect_watch.tick();launch.assert_not_called()
            p.startup_unresolved=True;p.reconnect_watch.tick();launch.assert_not_called()
            p.reconnect_watch.tick();launch.assert_called_once_with(0,scheduled=True,resume_route=True)
    def test_town_startup_hands_off_without_auto_click(self):
        import recovery_runner as module
        from contextlib import ExitStack
        self.bind_all();runner=self.app.profiles[0].recovery_runner;done=Mock()
        constants={'notice':0,'shop':0,'warehouse':0,'special_screen':0,'world_map':0,
                   'quest_travel':0,'bag_panel':0,'special_icon':(0,0,0),'auto_control':(.95,770,120),
                   'auto_mode':'off','combat_active':0,'special_hud_timer':0,'general_location':0,
                   'town':.98,'town_minimap_score':.98,'event_return_location':0}
        with ExitStack() as stack:
            for name,value in constants.items():stack.enter_context(patch.object(module,name,return_value=value))
            stack.enter_context(patch.object(module,'ensure_view',return_value=True))
            stack.enter_context(patch.object(module,'capture',return_value=b'fake'))
            stack.enter_context(patch.object(module,'from_capture',return_value=Mock()))
            stack.enter_context(patch.object(module,'dismiss_attendance',return_value=False))
            stack.enter_context(patch.object(runner,'log'))
            click=stack.enter_context(patch.object(module,'click_client_point'))
            runner.start(done=done);runner.tick();done.assert_not_called();runner.tick()
            self.assertEqual(runner.last_field,'town');done.assert_called_once_with(False)
            click.assert_not_called()
    def test_minimap_town_glyphs_survive_dark_background_and_require_location(self):
        import vision
        import numpy as np
        from PIL import Image
        with Image.open(vision.ASSETS/'town_minimap_glyph.png') as ref:
            glyph=np.asarray(ref.convert('L'))>150
        for background in ((18,28,15),(90,55,30),(20,70,90)):
            im=Image.new('RGB',(800,600),background)
            tile=np.empty((glyph.shape[0],glyph.shape[1],3),dtype=np.uint8)
            tile[:]=background;tile[glyph]=(220,220,220)
            im.paste(Image.fromarray(tile),(735,87))
            self.assertGreaterEqual(vision.town_minimap_score(im),.99)
        blank=Image.new('RGB',(800,600),(30,40,20))
        self.assertLess(vision.town_minimap_score(blank),.90)
        blank.paste(Image.fromarray(tile),(300,200))
        self.assertLess(vision.town_minimap_score(blank),.90)
    def test_unknown_startup_remains_pending_without_forced_travel(self):
        from startup_resume import resume_route
        self.bind_all();p=self.app.profiles[0];p.daily_scheduler.active=True
        with patch.object(self.app,'launch_general') as general,patch.object(self.app,'launch_remaining') as special:
            resume_route(self.app,0,'unknown')
            self.assertTrue(p.startup_unresolved);general.assert_not_called();special.assert_not_called()
    def test_observation_notice_does_not_overwrite_real_status(self):
        p=self.app.profiles[0];p.status.set('현재 위치 판독 대기')
        p.town_log('[화면 순회] 화면 확인',update_status=False)
        self.assertEqual(p.status.get(),'현재 위치 판독 대기')
    def startup_case(self,hour=14):
        from datetime import datetime,time,timezone,timedelta
        self.bind_all();p=self.app.profiles[0];p.daily_scheduler.active=True
        p.daily_scheduler.special_time=time(5,1)
        p.daily_scheduler.now=Mock(return_value=datetime(2026,10,27,hour,0,tzinfo=timezone(timedelta(hours=9))))
        p.event_scheduler.active=False
        return p
    def test_general_startup_queues_same_remaining_scan_as_manual(self):
        from startup_resume import resume_route
        self.startup_case(hour=8)
        with patch.object(self.app,'launch_remaining') as remaining,patch.object(self.app,'launch_general') as general:
            resume_route(self.app,0,'general')
            remaining.assert_called_once_with(0,scheduled=True);general.assert_not_called()
    def test_general_startup_before_daily_time_keeps_current_hunt(self):
        from startup_resume import resume_route
        self.startup_case(hour=4)
        with patch.object(self.app,'launch_remaining') as remaining:
            resume_route(self.app,0,'general');remaining.assert_not_called()
    def test_today_supply_failure_blocks_general_startup_entry(self):
        from startup_resume import resume_route
        p=self.startup_case();p.daily_scheduler.failed=True;p.daily_scheduler.supply_day=p.daily_scheduler.now().date()
        with patch.object(self.app,'launch_remaining') as remaining:
            resume_route(self.app,0,'general');remaining.assert_not_called()
    def test_open_event_takes_precedence_over_basic_scan(self):
        from startup_resume import resume_route
        from datetime import datetime,timezone,timedelta
        p=self.startup_case();p.selected_events={'abandoned'};p.event_scheduler.active=True
        p.event_scheduler.now=Mock(return_value=datetime(2026,10,27,16,5,tzinfo=timezone(timedelta(hours=9))))
        with patch.object(p.event_scheduler,'recheck_from_field') as event,patch.object(self.app,'launch_remaining') as remaining:
            resume_route(self.app,0,'general');remaining.assert_not_called();event.assert_called_once_with('general')
    def test_known_general_with_low_hud_score_still_scans_remaining(self):
        import cycle_runner as module
        from contextlib import ExitStack
        self.bind_all();p=self.app.profiles[0];c=p.cycle_runner
        values={'special_screen':0,'special_hud_timer':0,'auto_control':(0,0,0),'special_icon':(0,0,0),'special_entry_dialog':(0,0),'purchase_dialog':(0,0),'general_location':.95,'auto_mode':'on','town':0,'notice':0,'shop':0,'warehouse':0,'quest_travel':0}
        with ExitStack() as stack:
            for name,value in values.items():stack.enter_context(patch.object(module,name,return_value=value))
            stack.enter_context(patch.object(module,'ensure_view',return_value=True))
            stack.enter_context(patch.object(module,'capture',return_value=b'fake'))
            stack.enter_context(patch.object(module,'from_capture',return_value=Mock()))
            stack.enter_context(patch.object(module,'dismiss_attendance',return_value=False))
            stack.enter_context(patch.object(c,'save'));stack.enter_context(patch.object(c,'log'))
            scan=stack.enter_context(patch.object(p.special_runner,'start'))
            c.start_remaining(chained=True);c.resume_check()
            scan.assert_called_once_with(chained=True);self.assertEqual(c.phase,'scan')
    def test_last_basic_region_return_goes_to_general(self):
        self.bind_all();p=self.app.profiles[0];c=p.cycle_runner
        c.active=True;c.phase='observe';c.required_expired=4;c.current_expected=(4,'조선왕릉','2층');c.charged_hunt=False;c.completed_indices={0,1,2,3}
        with patch.object(c,'log'),patch.object(p.general_runner,'start') as general,patch.object(p.special_runner,'start') as scan:
            c.inspect();self.app.work_coordinator.pending.popleft()['action']()
            general.assert_called_once_with(chained=True);scan.assert_not_called();self.assertFalse(c.active)
    def test_1600_event_queues_all_four_even_if_observation_not_due(self):
        from datetime import datetime,timezone,timedelta
        self.bind_all();self.app.dual_runner.due=10**12
        now=datetime(2026,10,27,16,0,tzinfo=timezone(timedelta(hours=9)))
        for p in self.app.profiles:
            p.daily_scheduler.active=True;p.selected_events={'abandoned','gadeok','nijo'}
            p.event_scheduler.active=True;p.event_scheduler.now=Mock(return_value=now)
            p.event_scheduler.tick()
        requests=list(self.app.work_coordinator.pending)
        self.assertEqual([r['index'] for r in requests],[0,1,2,3])
        self.assertTrue(all(r['kind']=='이벤트 입장 버려진 동굴' for r in requests))
    def event_field_case(self):
        from datetime import datetime,timezone,timedelta
        from event_schedule import EVENTS,end_at
        self.bind_all();p=self.app.profiles[2];p.daily_scheduler.active=True
        e=EVENTS[2];p.selected_events={'nijo'};scheduler=p.event_scheduler;scheduler.active=True
        now=datetime(2026,10,28,19,30,tzinfo=timezone(timedelta(hours=9)))
        scheduler.now=Mock(return_value=now)
        return p,e,end_at(e,now)
    def event_field_patches(self,module,ordinary=.88):
        from contextlib import ExitStack
        stack=ExitStack()
        constants={'special_screen':0,'world_map':0,'event_location':0,'special_hud_timer':.95,
                   'notice':0,'shop':0,'warehouse':0,'quest_travel':0,'special_icon':(0,0,0),
                   'town':0,'general_location':ordinary,'auto_control':(.95,770,120),
                   'auto_mode':'on','combat_active':.9,'main_menu_button':(0,0,0)}
        for name,value in constants.items():stack.enter_context(patch.object(module,name,return_value=value))
        stack.enter_context(patch.object(module,'ensure_view',return_value=True))
        stack.enter_context(patch.object(module,'capture',return_value=b'fake'))
        stack.enter_context(patch.object(module,'from_capture',return_value=Mock()))
        stack.enter_context(patch.object(module,'dismiss_attendance',return_value=False))
        stack.enter_context(patch.object(module,'check_observation_area',return_value=1))
        return stack
    def test_ordinary_minimap_overrides_timer_only_event_hold(self):
        import event_runner as module
        p,e,end=self.event_field_case();r=p.event_runner
        with self.event_field_patches(module),patch.object(r,'log'),patch.object(module,'click_client_point') as click:
            r.start(e,end);r.tick();r.tick()
            self.assertEqual(r.phase,'open');click.assert_not_called()
    def test_unknown_timed_field_is_still_protected(self):
        import event_runner as module
        p,e,end=self.event_field_case();r=p.event_runner
        with self.event_field_patches(module,ordinary=.3),patch.object(r,'log'),patch.object(module,'click_client_point') as click:
            r.start(e,end);r.tick()
            self.assertEqual(r.phase,'identify_existing');click.assert_not_called()
    def test_hold_rechecks_general_only_before_any_entry_click(self):
        import event_runner as module
        p,e,end=self.event_field_case();r=p.event_runner
        with self.event_field_patches(module),patch.object(r,'log'),patch.object(p.event_scheduler,'recheck_from_field') as recheck:
            r.start(e,end);r.phase='identify_existing'
            r.entry_clicked=True
            for _ in range(4):r.tick()
            recheck.assert_not_called()
            r.entry_clicked=False;r.ordinary_hits=0
            r.tick();r.tick();recheck.assert_not_called();r.tick()
            recheck.assert_called_once_with('general')
    def test_new_event_invalidates_old_return_request_and_callback(self):
        from event_schedule import EVENTS
        p,e,end=self.event_field_case();scheduler=p.event_scheduler
        scheduler.return_check=(EVENTS[0],end);scheduler.return_check_at=scheduler.now()
        with patch.object(scheduler,'log'):
            scheduler.check_return()
            request=self.app.work_coordinator.pending[-1]
            scheduler.entering(e,end)
            self.assertIsNone(scheduler.return_check)
            self.assertFalse(any(r['kind']=='이벤트 종료 후 AUTO 확인' for r in self.app.work_coordinator.pending))
            with patch.object(p.recovery_runner,'start') as recovery:
                request['action']();recovery.assert_not_called()
    def test_blocked_worldmap_only_closes_verified_x_and_cancels_retry(self):
        import movement_guard as module
        self.bind_all();p=self.app.profiles[1];r=p.general_runner
        r.start(chained=True,force_leave=True);p.cycle_runner.general_pending=True
        with patch.object(module,'map_movement_blocked',return_value=True),patch.object(module,'world_map',return_value=.99),patch.object(module,'locate',return_value=(.98,770,20)),patch.object(module,'click_client_point') as click,patch.object(p.cycle_runner,'start_remaining') as observe,patch.object(r,'log'):
            self.assertTrue(module.protect_hunt(r,Mock()))
            click.assert_called_once_with(r.handle,770/800,20/600)
            self.assertFalse(r.active);self.assertFalse(p.cycle_runner.general_pending)
            self.assertFalse(p.cycle_runner.general_force_leave)
            observe.assert_called_once_with(chained=True)
    def test_blocked_map_without_verified_close_sends_no_input(self):
        import movement_guard as module
        self.bind_all();p=self.app.profiles[1];r=p.general_runner;r.start(chained=True)
        with patch.object(module,'map_movement_blocked',return_value=True),patch.object(module,'world_map',return_value=.99),patch.object(module,'locate',return_value=(.5,770,20)),patch.object(module,'click_client_point') as click,patch.object(p.cycle_runner,'start_remaining') as observe,patch.object(r,'log'):
            self.assertTrue(module.protect_hunt(r,Mock()))
            click.assert_not_called();observe.assert_not_called();self.assertFalse(r.active)
    def test_timed_hunt_protection_applies_to_supply_and_forced_general(self):
        import movement_guard as module
        self.bind_all();p=self.app.profiles[1]
        for r in (p.supply_runner,p.general_runner):
            r.active=True;r.handle=p.window_link.hwnd;r.force_leave=True
            with patch.object(module,'map_movement_blocked',return_value=False),patch.object(module,'world_map',return_value=0),patch.object(module,'special_hud_timer',return_value=.95),patch.object(module,'ordinary_departure',return_value=False),patch.object(module,'click_client_point') as click,patch.object(p.cycle_runner,'start_remaining') as observe,patch.object(r,'log'):
                self.assertTrue(module.protect_hunt(r,Mock()))
                click.assert_not_called();self.assertFalse(r.active);observe.assert_called_once_with(chained=True)
    def test_known_general_countdown_does_not_block_normal_travel(self):
        import movement_guard as module
        self.bind_all();r=self.app.profiles[0].general_runner;r.active=True
        with patch.object(module,'map_movement_blocked',return_value=False),patch.object(module,'world_map',return_value=0),patch.object(module,'special_hud_timer',return_value=.95),patch.object(module,'ordinary_departure',return_value=True),patch.object(module,'click_client_point') as click:
            self.assertFalse(module.protect_hunt(r,Mock()));self.assertTrue(r.active);click.assert_not_called()
    def test_general_hud_alone_is_not_departure_permission(self):
        import movement_guard as module
        with patch.object(module,'town',return_value=.3),patch.object(module,'general_location',return_value=.4),patch.object(module,'auto_control',return_value=(.99,770,120)):
            self.assertFalse(module.ordinary_departure(Mock(),'ship'))
    def test_old_event_return_callback_cannot_requeue_travel_after_guard(self):
        import movement_guard as module
        self.bind_all();p=self.app.profiles[1];r=p.general_runner;r.active=True;r.handle=p.window_link.hwnd
        p.event_scheduler.return_check=(Mock(),Mock());p.event_scheduler.return_check_queued=True
        r.done=Mock(side_effect=lambda ok:self.assertIsNone(p.event_scheduler.return_check))
        with patch.object(module,'map_movement_blocked',return_value=False),patch.object(module,'world_map',return_value=0),patch.object(module,'special_hud_timer',return_value=.95),patch.object(module,'ordinary_departure',return_value=False),patch.object(p.cycle_runner,'start_remaining'),patch.object(r,'log'),patch.object(p.event_scheduler,'log'):
            done=r.done;module.protect_hunt(r,Mock());done.assert_called_once_with(False)
            self.assertFalse(p.event_scheduler.return_check_queued)
    def test_departure_runners_guard_before_any_travel_click(self):
        from contextlib import ExitStack
        import movement_guard as guard
        import supply_runner,general_runner
        self.bind_all();p=self.app.profiles[1]
        for module,r in ((supply_runner,p.supply_runner),(general_runner,p.general_runner)):
            with ExitStack() as stack:
                for name,value in [('map_movement_blocked',False),('world_map',0),('special_hud_timer',.95),('ordinary_departure',False)]:
                    stack.enter_context(patch.object(guard,name,return_value=value))
                stack.enter_context(patch.object(module,'capture',return_value=b'fake'))
                stack.enter_context(patch.object(module,'from_capture',return_value=Mock()))
                stack.enter_context(patch.object(module,'dismiss_attendance',return_value=False))
                stack.enter_context(patch.object(module,'check_game_view'))
                if hasattr(module,'ensure_view'):stack.enter_context(patch.object(module,'ensure_view',return_value=True))
                stack.enter_context(patch.object(r,'log'))
                observe=stack.enter_context(patch.object(p.cycle_runner,'start_remaining'))
                click=stack.enter_context(patch.object(module,'click_client_point'))
                if module is general_runner:r.start(chained=True,force_leave=True)
                else:r.start()
                r.tick();click.assert_not_called();observe.assert_called_once_with(chained=True)
                self.assertFalse(r.active)
    def test_strong_return_name_unblocks_cycle_despite_timer_banner(self):
        import passive_observer as module
        from contextlib import ExitStack
        from PIL import Image
        self.bind_all();r=self.app.profiles[0].cycle_runner
        r.active=True;r.phase='observe';r.handle=100;r.hunt_confirmed=True
        with ExitStack() as stack:
            for name,value in [('check_game_view',None),('check_observation_area',1),('capture',b'fake'),('from_capture',Image.new('RGB',(800,600))),('observe_menu',False),('special_screen',0),('special_icon',(0,0,0)),('special_hud_timer',.95),('town',.2),('general_location',.94)]:
                stack.enter_context(patch.object(module,name,return_value=value))
            stack.enter_context(patch.object(module,'note_frame'));stack.enter_context(patch.object(r,'log'))
            inspect=stack.enter_context(patch.object(r,'inspect'))
            module.observe_return(r);module.observe_return(r);inspect.assert_not_called()
            module.observe_return(r);inspect.assert_called_once_with()
    def test_weak_return_name_does_not_end_current_timed_hunt(self):
        import passive_observer as module
        from contextlib import ExitStack
        from PIL import Image
        self.bind_all();r=self.app.profiles[0].cycle_runner
        r.active=True;r.phase='observe';r.handle=100;r.hunt_confirmed=True
        with ExitStack() as stack:
            for name,value in [('check_game_view',None),('check_observation_area',1),('capture',b'fake'),('from_capture',Image.new('RGB',(800,600))),('observe_menu',False),('special_screen',0),('special_icon',(0,0,0)),('special_hud_timer',.95),('town',.2),('general_location',.84)]:stack.enter_context(patch.object(module,name,return_value=value))
            stack.enter_context(patch.object(module,'note_frame'))
            inspect=stack.enter_context(patch.object(r,'inspect'))
            for _ in range(5):module.observe_return(r)
            inspect.assert_not_called();self.assertTrue(r.active)
    def test_hidden_input_releases_instead_of_blocking_all_four_forever(self):
        from runner_focus import ensure_view
        self.bind_all();r=self.app.profiles[0].special_runner
        r.active=True;r.handle=100;r.hidden_since=1
        check=Mock(side_effect=RuntimeError('게임 화면이 가려져 중지했습니다.'))
        with patch('runner_focus.time.monotonic',return_value=25),patch.object(self.app.focus_runner,'start') as focus:
            with self.assertRaisesRegex(RuntimeError,'8초 초과'):ensure_view(r,check)
            focus.assert_not_called()
            self.assertFalse(ensure_view(r,check,observing=True))
    def special_scan_patches(self,r):
        import special_runner as module
        from contextlib import ExitStack
        stack=ExitStack()
        constants={'ensure_view':True,'capture':b'fake','from_capture':Mock(),'dismiss_attendance':False,
                   'special_screen':.99,'region_card':(.99,14,100),'full_card':True,'selected_card':True,
                   'special_expired':(0,0),'special_remaining':(True,.99,.99),'special_charged_remaining':False}
        for name,value in constants.items():stack.enter_context(patch.object(module,name,return_value=value))
        stack.enter_context(patch.object(r,'log'));stack.enter_context(patch.object(r,'save'))
        return stack
    def test_earlier_remaining_region_waits_for_required_expiry_without_retry_loop(self):
        self.bind_all();p=self.app.profiles[0];r=p.special_runner;p.cycle_runner.active=True;p.cycle_runner.required_expired=3
        with self.special_scan_patches(r),patch.object(r,'finish') as finish:
            r.start(chained=True);r.phase='inspect';r.tick();r.tick()
            finish.assert_not_called();self.assertEqual(r.phase,'find');self.assertEqual(r.index,1)
            self.assertTrue(r.results[0]['remaining'])
    def test_scan_returns_to_first_remaining_after_required_expiry_is_known(self):
        self.bind_all();p=self.app.profiles[0];r=p.special_runner;p.cycle_runner.active=True;p.cycle_runner.required_expired=3
        with self.special_scan_patches(r),patch.object(r,'finish') as finish:
            r.start(chained=True);r.phase='inspect';r.index=4
            r.results=[{'remaining':i==0,'expired':i!=0} for i in range(4)]
            r.tick();r.tick();finish.assert_not_called()
            self.assertEqual(r.index,0);self.assertEqual(r.phase,'prepare_find')
    def test_diagnostic_zip_excludes_settings_and_masks_tokens(self):
        import diagnostic_export as module
        from zipfile import ZipFile
        self.bind_all()
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'special_check.log').write_text('token 123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890')
            (root/'telegram_settings.json').write_text('secret');(root/'four_profiles.json').write_text('settings')
            path=module.export_bundle(self.app,root/'result.zip',root)
            with ZipFile(path) as archive:
                self.assertIn('current_state.json',archive.namelist())
                self.assertNotIn('telegram_settings.json',archive.namelist());self.assertNotIn('four_profiles.json',archive.namelist())
                self.assertNotIn('ABCDEFGHIJKLMNOPQRSTUVWXYZ',archive.read('logs/special_check.log').decode())
    def test_blocked_character_yields_queue_to_the_next_character(self):
        from runner_focus import ensure_view
        self.bind_all();q=self.app.work_coordinator;calls=[]
        p=self.app.profiles[0];r=p.special_runner
        def first():
            p.cycle_runner.active=True;r.start(chained=True);r.hidden_since=1
        q.submit(0,'첫 캐릭터 특수지역 검사',first)
        q.submit(1,'둘째 캐릭터 작업',lambda:calls.append(1))
        def focus(handle,ready,failed,say):ready()
        with patch.object(self.app.focus_runner,'start',side_effect=focus),patch.object(r,'log'),patch.object(p.cycle_runner,'log'):
            q.tick_once();self.assertTrue(r.active)
            with patch('runner_focus.time.monotonic',return_value=25):
                try:ensure_view(r,Mock(side_effect=RuntimeError('게임 화면이 가려져 중지했습니다.')))
                except RuntimeError as exc:r.finish(str(exc))
            self.assertFalse(r.active);self.assertEqual(p.cycle_runner.phase,'retry_wait')
            q.tick_once();self.assertEqual(calls,[1])
    def test_verified_special_auto_hands_queue_to_next_character(self):
        self.bind_all();q=self.app.work_coordinator;calls=[];p=self.app.profiles[0]
        p.cycle_runner.active=True;p.cycle_runner.phase='entry'
        p.entry_runner.active=True;p.entry_runner.expected=(0,*p.routes[0])
        p.entry_runner.handle=100;p.entry_runner.phase='combat'
        q.active=True;q.current={'index':0,'handle':100,'kind':'특수지역'}
        q.submit(1,'다음 캐릭터',lambda:calls.append(1))
        with patch.object(p.entry_runner,'save'),patch.object(p.entry_runner,'log'),patch.object(p.cycle_runner,'checkpoint'),patch.object(p.cycle_runner,'log'):
            p.entry_runner.complete(Mock())
        self.assertFalse(p.entry_runner.active);self.assertEqual(p.cycle_runner.phase,'observe')
        with patch.object(self.app.focus_runner,'start',side_effect=lambda h,ready,failed,say:ready()):
            callback,args=self.app.jobs[q.job];callback(*args)
        self.assertEqual(calls,[1]);self.assertTrue(p.cycle_runner.active)
    def test_verified_general_auto_hands_queue_to_next_character(self):
        self.bind_all();q=self.app.work_coordinator;calls=[];p=self.app.profiles[0];r=p.general_runner
        r.active=True;r.handle=100;r.phase='combat';r.done=None
        q.active=True;q.current={'index':0,'handle':100,'kind':'일반사냥'}
        q.submit(3,'다음 캐릭터',lambda:calls.append(3))
        with patch.object(r,'save'),patch.object(r,'log'):r.complete(Mock())
        with patch.object(self.app.focus_runner,'start',side_effect=lambda h,ready,failed,say:ready()):
            callback,args=self.app.jobs[q.job];callback(*args)
        self.assertEqual(calls,[3]);self.assertFalse(r.active)
    def test_handoff_does_not_interrupt_nested_unfinished_action(self):
        self.bind_all();q=self.app.work_coordinator;p=self.app.profiles[0]
        q.active=True;q.current={'index':0,'handle':100,'kind':'AUTO 확인'}
        p.recovery_runner.active=True
        q.submit(1,'next',Mock());q.handoff(p)
        with patch.object(self.app.focus_runner,'start') as start:
            callback,args=self.app.jobs[q.job];callback(*args);start.assert_not_called()
        self.assertTrue(q.active)
    def test_focus_timeout_yields_other_character_after_six_seconds(self):
        self.bind_all();q=self.app.work_coordinator;clock=[100];calls=[]
        q.submit(0,'막힌 창',lambda:calls.append(0));q.submit(1,'다음 창',lambda:calls.append(1))
        with patch('focus_runner.time.monotonic',side_effect=lambda:clock[0]),patch('focus_runner.ensure_on_screen',return_value=None),patch('focus_runner.request_game_foreground',return_value=True),patch('focus_runner.check_game_view',side_effect=RuntimeError('게임 화면이 가려져 중지했습니다.')),patch.object(self.app.focus_runner,'log'):
            q.tick_once();self.app.focus_runner.tick();clock[0]=106;self.app.focus_runner.tick()
            self.assertFalse(q.active);self.assertFalse(self.app.focus_runner.active)
        with patch('work_coordinator.time.monotonic',return_value=106),patch.object(self.app.focus_runner,'start',side_effect=lambda h,ready,failed,say:ready()):q.tick_once()
        self.assertEqual(calls,[1]);self.assertEqual(q.pending[0]['index'],0)
    def test_daily_supply_attendance_and_special_are_ordered_once(self):
        from datetime import datetime
        from daily_scheduler import KST
        self.bind_all();p=self.app.profiles[0];p.supply.set('04:50');p.start.set('05:01')
        scheduler=p.daily_scheduler
        at=lambda h,m:datetime(2026,11,3,h,m,tzinfo=KST)
        with patch.object(scheduler,'now',return_value=at(4,49)),patch.object(self.app,'launch_recovery'):
            scheduler.arm()
        q=self.app.work_coordinator
        with patch.object(self.app,'launch_supply') as supply,patch.object(self.app,'launch_remaining') as special:
            with patch.object(scheduler,'now',return_value=at(4,50)):scheduler.tick();scheduler.tick()
            supply.assert_called_once_with(0,scheduled=True);special.assert_not_called()
            with patch.object(scheduler,'now',return_value=at(5,0)):scheduler.tick();scheduler.tick()
            self.assertEqual(sum(r['kind']=='05시 출석창 확인' for r in q.pending),1)
            scheduler.supply_ok=True
            with patch.object(scheduler,'now',return_value=at(5,1)):scheduler.tick();scheduler.tick()
            special.assert_called_once_with(0,scheduled=True,morning_only=True)
    def test_attendance_job_only_uses_verified_attendance_close(self):
        import attendance_runner as module
        self.bind_all();r=self.app.profiles[0].attendance_runner
        with patch.object(module,'ensure_view',return_value=True),patch.object(module,'capture',return_value=b'fake'),patch.object(module,'from_capture',return_value=Mock()),patch.object(module,'dismiss_attendance',side_effect=[True,False,False]) as dismiss,patch.object(r,'log'):
            r.start();r.tick();self.assertTrue(r.active)
            r.tick();self.assertTrue(r.active)
            r.tick();self.assertFalse(r.active);self.assertEqual(dismiss.call_count,3)
    def test_recovery_on_requires_two_frames_before_handoff(self):
        import recovery_runner as module
        from contextlib import ExitStack
        self.bind_all();p=self.app.profiles[0];r=p.recovery_runner;done=Mock()
        constants={'notice':0,'shop':0,'warehouse':0,'special_screen':0,'world_map':0,'quest_travel':0,'bag_panel':0,'special_icon':(0,0,0),'auto_control':(.95,770,120),'auto_mode':'on','combat_active':0,'special_hud_timer':.95,'general_location':0,'town':0,'town_minimap_score':0,'event_return_location':0,'ensure_view':True,'capture':b'fake','from_capture':Mock(),'dismiss_attendance':False}
        with ExitStack() as stack:
            for name,value in constants.items():stack.enter_context(patch.object(module,name,return_value=value))
            stack.enter_context(patch.object(r,'log'));stack.enter_context(patch.object(r,'finish',wraps=r.finish))
            stack.enter_context(patch.object(module,'click_client_point'))
            stack.enter_context(patch.object(module.Path,'mkdir'))
            r.start(require='special',done=done);r.tick();done.assert_not_called()
            r.tick();done.assert_called_once_with(True);self.assertFalse(r.active)

    def test_special_auto_on_under_open_menu_cannot_release_queue(self):
        import entry_runner as module
        from contextlib import ExitStack
        self.bind_all();r=self.app.profiles[0].entry_runner
        r.start(chained=True);r.phase='combat';r.expected=(0,*r.routes[0])
        constants={'ensure_view':True,'capture':b'fake','from_capture':Mock(),'dismiss_attendance':False,
                   'special_entry_dialog':(0,0),'special_screen':.95,'notice':0,
                   'combat_active':.95,'auto_mode':'on','auto_control':(.95,770,120)}
        with ExitStack() as stack:
            for name,value in constants.items():stack.enter_context(patch.object(module,name,return_value=value))
            complete=stack.enter_context(patch.object(r,'complete'))
            r.tick();r.tick();complete.assert_not_called();self.assertTrue(r.active)
            with patch.object(module,'special_screen',return_value=0):
                r.tick();complete.assert_not_called();r.tick();complete.assert_called_once()

    def current_hud(self,name):
        from PIL import Image
        im=Image.new('RGB',(800,600))
        with Image.open(ROOT.parent/'tests/fixtures/current_hud'/f'{name}.png') as tile:
            im.paste(tile,(650,0) if name=='special_header' else (640,65))
        return im
    def test_current_hud_variants_identify_general_on_and_two_towns(self):
        import vision
        general=self.current_hud('general')
        self.assertGreaterEqual(vision.general_location(general,'ship'),.82)
        self.assertGreaterEqual(vision.auto_control(general)[0],.90)
        self.assertEqual(vision.auto_mode(general),'on')
        self.assertLess(vision.town(general),.85)
        for name in ('town2','town4'):
            im=self.current_hud(name)
            self.assertGreaterEqual(vision.town(im),.90)
            self.assertLess(vision.general_location(im,'ship'),.78)
            self.assertEqual(vision.auto_mode(im),'off')
    def test_existing_general_hunt_after_morning_is_kept_without_special_scan(self):
        from startup_resume import resume_route
        p=self.startup_case(hour=13)
        with patch.object(self.app,'launch_remaining') as remaining,patch.object(self.app,'launch_general') as general:
            resume_route(self.app,0,'general');remaining.assert_not_called();general.assert_not_called()
        self.assertFalse(p.startup_unresolved)
    def test_unfinished_town_after_morning_checks_remaining_and_special_keeps_observer(self):
        from startup_resume import resume_route
        self.startup_case(hour=13)
        with patch.object(self.app,'launch_remaining') as remaining,patch.object(self.app,'launch_general') as general:
            resume_route(self.app,0,'town');general.assert_not_called();remaining.assert_called_once_with(0,scheduled=True)
            remaining.reset_mock();resume_route(self.app,0,'special');remaining.assert_called_once_with(0,scheduled=True)
    def test_expired_queued_job_does_not_stop_hunt_or_focus(self):
        self.bind_all();q=self.app.work_coordinator;p=self.app.profiles[0]
        action=Mock();failed=Mock();p.stop=Mock()
        q.submit(0,'지난 보급',action,failed,valid=lambda:False)
        with patch.object(self.app.focus_runner,'start') as focus:q.tick_once();focus.assert_not_called()
        action.assert_not_called();p.stop.assert_not_called();failed.assert_called_once()
        self.assertFalse(q.pending);self.assertFalse(q.active)
    def test_job_expiring_during_focus_preserves_existing_observer(self):
        self.bind_all();q=self.app.work_coordinator;p=self.app.profiles[0]
        alive=[True];action=Mock();p.stop=Mock()
        q.submit(0,'보급',action,valid=lambda:alive[0])
        def focus(handle,ready,failed,say):alive[0]=False;ready()
        with patch.object(self.app.focus_runner,'start',side_effect=focus):q.tick_once()
        p.stop.assert_not_called();action.assert_not_called();self.assertFalse(q.active)
    def test_known_special_menu_closes_then_requires_clear_frames(self):
        import menu_visibility as module
        from PIL import Image
        r=NS(handle=100,log=Mock());module.reset_menu(r)
        menu=self.current_hud('special_header');clear=self.current_hud('general')
        with patch.object(module,'click_client_point') as click:
            self.assertTrue(module.expose_minimap(r,menu));click.assert_not_called()
            self.assertTrue(module.expose_minimap(r,menu));click.assert_called_once()
            self.assertTrue(module.expose_minimap(r,clear))
            self.assertFalse(module.expose_minimap(r,clear))
    def test_menu_cleanup_does_not_click_without_verified_x_or_over_payment(self):
        import menu_visibility as module
        r=NS(handle=100,log=Mock());module.reset_menu(r);menu=self.current_hud('special_header')
        with patch.object(module,'locate',return_value=(.5,770,20)),patch.object(module,'click_client_point') as click:
            module.expose_minimap(r,menu);module.expose_minimap(r,menu);click.assert_not_called()
        with patch.object(module,'special_entry_dialog',return_value=(.95,.95)),patch.object(module,'click_client_point') as click:
            with self.assertRaisesRegex(RuntimeError,'대화'):module.expose_minimap(r,menu)
            click.assert_not_called()
    def test_startup_recovery_clears_menu_then_identifies_general_without_auto_toggle(self):
        import recovery_runner as module
        import menu_visibility
        from PIL import Image
        self.bind_all();p=self.app.profiles[0];p.general_key='ship';r=p.recovery_runner;done=Mock()
        menu=self.current_hud('special_header');field=self.current_hud('general')
        with patch.object(module,'ensure_view',return_value=True),patch.object(module,'capture',return_value=b'fake'),patch.object(module,'from_capture',side_effect=[menu,menu,field,field,field]),patch.object(module,'dismiss_attendance',return_value=False),patch.object(menu_visibility,'click_client_point') as close,patch.object(module,'click_client_point') as auto,patch.object(r,'log'),patch.object(Image.Image,'save'):
            r.start(done=done)
            for _ in range(4):r.tick()
            done.assert_not_called();r.tick()
            done.assert_called_once_with(True);close.assert_called_once();auto.assert_not_called()
            self.assertEqual(r.last_field,'general')
    def test_scheduled_supply_request_expires_before_late_town_return(self):
        from datetime import datetime,time,timezone,timedelta
        self.bind_all();p=self.app.profiles[0];d=p.daily_scheduler;d.active=True
        d.supply_time=time(4,50);d.special_time=time(5,1)
        now=[datetime(2026,11,3,4,50,tzinfo=timezone(timedelta(hours=9)))]
        with patch.object(d,'now',side_effect=lambda:now[0]),patch.object(self.app,'profile_ready',return_value=True):
            self.app.launch_supply(0,scheduled=True)
            request=self.app.work_coordinator.pending[0];self.assertTrue(request['valid']())
            now[0]=now[0].replace(hour=13);self.assertFalse(request['valid']())

    def test_verified_menu_close_uses_detected_button_instead_of_fixed_point(self):
        import menu_visibility as module
        r=NS(handle=100);im=self.current_hud('general')
        with patch.object(module,'main_menu_button',return_value=(.99,777,561)),patch.object(module,'click_client_point') as click:
            module.close_verified_menu(r,im,'main');click.assert_called_once_with(100,777/800,561/600)
        with patch.object(module,'locate',return_value=(.4,777,20)),patch.object(module,'click_client_point') as click:
            with self.assertRaisesRegex(RuntimeError,'임의'):module.close_verified_menu(r,im,'panel')
            click.assert_not_called()
    def test_today_basic_completion_survives_checkpoint_without_blocking_next_day(self):
        from datetime import timedelta,datetime
        from startup_resume import resume_route
        p=self.startup_case(hour=8);now=p.daily_scheduler.now()
        with patch.object(session_state,'datetime',wraps=datetime) as clock:
            clock.now.return_value=now;session_state.mark_basic_done(p)
            session_state.checkpoint(p)
        self.assertTrue(session_state.basic_done_today(p,now))
        with patch.object(self.app,'launch_remaining') as remaining:
            resume_route(self.app,0,'general');remaining.assert_not_called()
            p.daily_scheduler.now.return_value=now+timedelta(days=1)
            resume_route(self.app,0,'general');remaining.assert_called_once_with(0,scheduled=True)
    def test_diagnostics_include_actual_administrator_status(self):
        import diagnostic_export
        with patch.object(diagnostic_export,'is_admin',return_value=True):
            self.assertTrue(diagnostic_export.runtime_snapshot(self.app)['administrator'])

    def test_dim_town_label_is_recognized_without_lowering_similarity_threshold(self):
        import vision
        image=self.current_hud('town_dim')
        self.assertGreaterEqual(vision.town_minimap_score(image),.90)
        self.assertGreaterEqual(vision.town(image),.90)
        self.assertEqual(vision.auto_mode(image),'off')
        for key in ('general','town2','town4'):
            if key=='general':self.assertLess(vision.town_minimap_score(self.current_hud(key)),.90)
    def test_dim_town_return_queues_next_region_even_without_previous_timer_sample(self):
        import passive_observer as module
        from contextlib import ExitStack
        from status_board import profile_status
        self.bind_all();p=self.app.profiles[3];r=p.cycle_runner
        r.active=True;r.phase='observe';r.handle=103;r.required_expired=0;r.completed_indices=set()
        r.charged_hunt=False;r.hunt_confirmed=False;r.passive_seen_timer=False
        with ExitStack() as stack:
            stack.enter_context(patch.object(module,'check_game_view'))
            stack.enter_context(patch.object(module,'check_observation_area',return_value=1))
            stack.enter_context(patch.object(module,'capture',return_value=b'fake'))
            stack.enter_context(patch.object(module,'from_capture',return_value=self.current_hud('town_dim')))
            stack.enter_context(patch.object(module,'observe_menu',return_value=False))
            stack.enter_context(patch.object(module,'note_frame'));stack.enter_context(patch.object(r,'log'))
            module.observe_return(r);module.observe_return(r)
            self.assertFalse(self.app.work_coordinator.pending)
            self.assertIn('복귀 확인 중',profile_status(self.app,3))
            module.observe_return(r)
        request=self.app.work_coordinator.pending[0]
        self.assertEqual(request['index'],3);self.assertEqual(request['kind'],'다음 특수지역 검사')
        with patch.object(p.special_runner,'start') as scan:
            request['action']();scan.assert_called_once_with(chained=True)
    def test_completed_town_goes_to_general_but_unfinished_town_resumes(self):
        from datetime import datetime
        from startup_resume import resume_route
        p=self.startup_case(hour=14);now=p.daily_scheduler.now()
        with patch.object(session_state,'datetime',wraps=datetime) as clock:
            clock.now.return_value=now;session_state.mark_basic_done(p)
        with patch.object(self.app,'launch_general') as general,patch.object(self.app,'launch_remaining') as remaining:
            resume_route(self.app,0,'town');general.assert_called_once_with(0);remaining.assert_not_called()
    def test_shorter_interval_applies_without_waiting_for_previous_sixty_second_deadline(self):
        self.app.dual_runner.due=500;self.app.dual_runner.next_attempt=500
        self.app.observation_interval_var.set('30')
        with patch('chosun_gui.time.monotonic',return_value=100):self.app.change_observation_interval()
        self.assertEqual(self.app.dual_runner.due,130);self.assertEqual(self.app.dual_runner.next_attempt,130)
        self.app.observation_interval_var.set('15');self.assertEqual(self.app.observation_seconds(),15)
    def test_sixty_second_speed_migration_is_once_and_later_preference_is_preserved(self):
        settings.update('_app',observation_switch_seconds=60,observation_speed_revision=15)
        first=gui.App();self.assertEqual(first.observation_seconds(),30)
        settings.update('_app',observation_switch_seconds=60)
        second=gui.App();self.assertEqual(second.observation_seconds(),60)
    def test_observe_phase_alone_does_not_claim_special_hunting(self):
        from status_board import profile_status
        self.bind_all();r=self.app.profiles[3].cycle_runner;r.active=True;r.phase='observe'
        r.required_expired=None;r.observation_state='unknown'
        self.assertIn('사냥 여부 미확정',profile_status(self.app,3))
        r.observation_state='hidden';self.assertIn('화면 노출 대기',profile_status(self.app,3))

    def death_frame(self):
        from PIL import Image
        im=self.current_hud('general')
        for name,point in [('new_title',(345,45)),('new_grave',(430,531))]:
            with Image.open(ROOT.parent/'tests/fixtures/death'/f'{name}.png') as tile:im.paste(tile,point)
        return im
    def restore_frame(self,kind):
        from PIL import Image
        im=Image.new('RGB',(800,600))
        for suffix,point in [('list',(0,0)),('footer',(0,524))]:
            with Image.open(ROOT.parent/'tests/fixtures/death'/f'{kind}_{suffix}.png') as tile:im.paste(tile,point)
        return im
    def restore_confirmation(self):
        from PIL import Image
        im=self.restore_frame('exp')
        with Image.open(ROOT.parent/'tests/fixtures/death/free_confirmation_dialog.png') as tile:im.paste(tile,(190,186))
        return im
    def test_actual_death_overlay_cannot_be_reported_as_auto_on_or_combat(self):
        import vision,death_vision
        image=self.death_frame()
        self.assertTrue(death_vision.death_screen(image)[0])
        self.assertEqual(vision.auto_mode(image),'dead')
        self.assertEqual(vision.combat_active(image),0)
        self.assertEqual(vision.auto_control(image)[0],0)
        self.assertFalse(death_vision.death_screen(self.current_hud('general'))[0])
    def test_death_intercepts_startup_before_auto_and_preserves_other_characters(self):
        import recovery_runner as module
        self.bind_all();p=self.app.profiles[0];p.daily_scheduler.active=True;r=p.recovery_runner
        other=self.app.profiles[1].cycle_runner;other.active=True;other.phase='observe'
        with patch.object(module,'ensure_view',return_value=True),patch.object(module,'capture',return_value=b'fake'),patch.object(module,'from_capture',return_value=self.death_frame()),patch.object(module,'auto_mode') as auto,patch.object(module,'click_client_point') as click,patch.object(p.death_runner,'log'):
            r.start();r.tick();auto.assert_not_called();click.assert_not_called()
        self.assertFalse(r.active);self.assertTrue(other.active)
        self.assertTrue(p.death_runner.queued)
        self.assertTrue(self.app.work_coordinator.pending[0]['kind'].startswith('사망'))
    def test_death_preempts_own_old_requests_but_keeps_other_characters_queue(self):
        self.bind_all();q=self.app.work_coordinator;p=self.app.profiles[0];p.daily_scheduler.active=True
        q.active=True;q.current={'index':0,'handle':100,'kind':'일반사냥'}
        q.submit(0,'이전 일반 이동',Mock());q.submit(2,'다른 캐릭터',Mock())
        with patch.object(p.death_runner,'log'):self.assertTrue(p.death_runner.observe(self.death_frame()))
        self.assertEqual([r['index'] for r in q.pending],[0,2])
        self.assertNotIn('이전 일반 이동',[r['kind'] for r in q.pending])
    def death_tick_patches(self,r):
        import death_runner as module
        from contextlib import ExitStack
        stack=ExitStack();stack.enter_context(patch.object(module,'ensure_view',return_value=True))
        stack.enter_context(patch.object(module,'capture',return_value=b'fake'))
        stack.enter_context(patch.object(r,'log'));stack.enter_context(patch.object(module.Image.Image,'save'))
        return stack
    def test_grave_revive_requires_two_frames_and_sends_only_once(self):
        import death_runner as module
        self.bind_all();r=self.app.profiles[0].death_runner
        with self.death_tick_patches(r),patch.object(module,'from_capture',return_value=self.death_frame()),patch.object(module,'click_client_point') as click:
            r.start(('general',None,None));r.tick();click.assert_not_called()
            r.tick();click.assert_called_once();self.assertEqual(r.phase,'revive_wait')
            r.tick();r.tick();click.assert_called_once()
    def test_free_quota_must_be_positive_and_zero_never_means_unknown(self):
        import death_vision
        from PIL import Image
        image=self.restore_frame('exp');self.assertEqual(death_vision.restoration_count(image,'free'),3)
        self.assertEqual(death_vision.restoration_count(image,'ticket'),0)
        zero=image.copy()
        with Image.open(ROOT/'assets/restore_digit_0.png') as tile:zero.paste(tile,(203,536))
        self.assertEqual(death_vision.restoration_count(zero,'free'),0)
        unknown=image.copy();unknown.paste((30,38,55),(203,536,209,546))
        self.assertIsNone(death_vision.restoration_count(unknown,'free'))
    def test_zero_free_and_zero_tickets_skip_without_paid_click(self):
        import death_runner as module
        from PIL import Image
        self.bind_all();r=self.app.profiles[0].death_runner;image=self.restore_frame('exp')
        with Image.open(ROOT/'assets/restore_digit_0.png') as tile:image.paste(tile,(203,536))
        with self.death_tick_patches(r),patch.object(module,'from_capture',return_value=image),patch.object(module,'click_client_point') as click:
            r.start(('general',None,None));r.phase='scan';r.tick();r.tick()
            click.assert_not_called();self.assertEqual(r.phase,'switch_tab');self.assertEqual(r.tab,1)
    def test_unknown_quota_holds_and_free_zero_never_uses_owned_tickets(self):
        import death_runner as module
        self.bind_all();r=self.app.profiles[0].death_runner;image=self.restore_frame('exp')
        with self.death_tick_patches(r),patch.object(module,'from_capture',return_value=image),patch.object(module,'click_client_point') as click:
            with patch.object(module.vision,'restoration_count',return_value=None):
                r.start(('general',None,None));r.phase='scan';r.tick();self.assertTrue(r.hold)
            with patch.object(module.vision,'restoration_count',side_effect=lambda im,k:0 if k=='free' else 2):
                r.start(('general',None,None));r.phase='scan';r.tick();r.tick();self.assertFalse(r.hold)
                self.assertEqual(r.tab,1)
            click.assert_not_called()
    def test_free_confirmation_requires_free_charge_one_and_ticket_cost_zero(self):
        import death_vision
        image=self.restore_confirmation();self.assertTrue(death_vision.free_confirmation(image)[0])
        bad=image.copy();bad.paste((35,35,35),(420,310,447,337))
        self.assertFalse(death_vision.free_confirmation(bad)[0])
        bad=image.copy();bad.paste((35,35,35),(420,286,445,310))
        self.assertFalse(death_vision.free_confirmation(bad)[0])
        from PIL import Image
        with Image.open(ROOT/'assets/restore_one.png') as one:
            paid=image.copy();paid.paste((35,35,35),(420,310,448,337));paid.paste(one,(426,315))
            self.assertFalse(death_vision.free_confirmation(paid)[0])
            paid=image.copy();paid.paste((35,35,35),(420,336,448,364));paid.paste(one,(426,338))
            self.assertFalse(death_vision.free_confirmation(paid)[0])
    def test_owned_confirmation_is_not_resent_after_dispatch(self):
        import death_runner as module
        self.bind_all();r=self.app.profiles[0].death_runner
        with self.death_tick_patches(r),patch.object(module,'from_capture',return_value=self.restore_confirmation()),patch.object(module,'click_client_point') as click:
            r.start(('general',None,None));r.phase='confirm';r.confirm_owned=True;r.last_quota=3
            r.tick();click.assert_not_called();r.tick();click.assert_called_once()
            r.tick();r.tick();click.assert_called_once();self.assertEqual(r.phase,'verify')
    def test_full_grave_free_experience_empty_items_and_general_resume(self):
        import death_runner as module
        from PIL import Image
        self.bind_all();p=self.app.profiles[0];r=p.death_runner
        exp=self.restore_frame('exp');empty=exp.copy();empty.paste((20,20,20),(0,35,222,95))
        items=self.restore_frame('items');confirm=self.restore_confirmation();field=self.current_hud('town2')
        frames=[self.death_frame()]*2+[exp]*2+[exp]*2+[exp]*2+[exp]*2+[confirm]*2+[empty]*2+[empty]*2+[items]*2+[items]*2+[items]*2+[field]*2
        with self.death_tick_patches(r),patch.object(module,'from_capture',side_effect=frames),patch.object(module,'click_client_point') as click,patch.object(self.app,'launch_general') as resume:
            r.start(('general',None,None))
            for _ in frames:r.tick()
            self.assertFalse(r.active);self.assertFalse(r.hold);self.assertEqual(r.restored,1)
            resume.assert_called_once_with(0);self.assertEqual(click.call_count,4)
    def test_death_hold_blocks_ordinary_travel_but_not_other_character(self):
        self.bind_all();p=self.app.profiles[0];p.death_runner.hold=True;q=self.app.work_coordinator
        q.submit(0,'일반사냥',Mock());q.submit(1,'다른 캐릭터',Mock())
        self.assertEqual([r['index'] for r in q.pending],[1])
    def test_automation_off_never_schedules_automatic_grave_revival(self):
        self.bind_all();p=self.app.profiles[0]
        with patch.object(p.death_runner,'log'):p.death_runner.observe(self.death_frame())
        self.assertFalse(p.death_runner.queued);self.assertFalse(self.app.work_coordinator.pending)

    def test_current_restore_icon_and_eight_free_quota_are_recognized(self):
        import death_vision
        from PIL import Image
        im=Image.new('RGB',(800,600))
        with Image.open(ROOT.parent/'tests/fixtures/death/current_restore_icon.png') as tile:im.paste(tile,(590,0))
        self.assertGreaterEqual(death_vision.restoration_icon(im)[0],.90)
        with Image.open(ROOT.parent/'tests/fixtures/death/current_free8_footer.png') as tile:im.paste(tile,(0,525))
        self.assertEqual(death_vision.restoration_count(im,'free'),8)
        self.assertGreaterEqual(death_vision.batch_button(im)[0],.90)
    def test_batch_is_clicked_directly_without_extra_free_button_click(self):
        import death_runner as module
        self.bind_all();r=self.app.profiles[0].death_runner
        with self.death_tick_patches(r),patch.object(module,'from_capture',return_value=self.restore_frame('exp')),patch.object(module,'click_client_point') as click:
            r.start(('general',None,None));r.phase='scan';r.tick();r.tick()
            self.assertEqual(r.phase,'confirm');self.assertEqual(click.call_count,1)
            self.assertAlmostEqual(click.call_args.args[1],110/800)
            self.assertGreater(click.call_args.args[2],.93)
            r.tick();r.tick();self.assertEqual(click.call_count,1)
    def test_free_confirmation_rejects_nonzero_or_unreadable_selected_currency(self):
        import death_vision
        im=self.restore_confirmation();self.assertTrue(death_vision.free_confirmation(im)[0])
        im.paste((35,35,35),(420,336,448,364))
        self.assertFalse(death_vision.free_confirmation(im)[0])
    def test_restoration_icon_remaining_reopens_tabs_without_resuming_hunt(self):
        import death_runner as module
        from PIL import Image
        self.bind_all();r=self.app.profiles[0].death_runner;field=self.current_hud('town2')
        with Image.open(ROOT.parent/'tests/fixtures/death/current_restore_icon.png') as tile:field.paste(tile,(590,0))
        with self.death_tick_patches(r),patch.object(module,'from_capture',return_value=field),patch.object(module,'click_client_point') as click,patch.object(self.app,'launch_general') as resume:
            r.start(('general',None,None));r.phase='closed';r.tick();r.tick()
            click.assert_called_once();resume.assert_not_called();self.assertEqual(r.phase,'panel_wait')
    def test_remaining_icon_after_free_limit_does_not_spend_tickets(self):
        import death_runner as module
        from PIL import Image
        self.bind_all();r=self.app.profiles[0].death_runner;field=self.current_hud('town2')
        with Image.open(ROOT.parent/'tests/fixtures/death/current_restore_icon.png') as tile:field.paste(tile,(590,0))
        with self.death_tick_patches(r),patch.object(module,'from_capture',return_value=field),patch.object(module,'click_client_point') as click,patch.object(self.app,'launch_general') as resume:
            r.start(('general',None,None));r.phase='closed';r.skipped=[0];r.tick();r.tick()
            click.assert_not_called();resume.assert_called_once_with(0)
    def test_special_death_resume_requests_remaining_scan_instead_of_general(self):
        self.bind_all();r=self.app.profiles[0].death_runner
        with patch.object(r,'log'),patch.object(self.app,'launch_remaining') as remaining,patch.object(self.app,'launch_general') as general:
            r.start(('special',(1,'부패한 도성','3층'),None));r.resume(None)
            remaining.assert_called_once_with(0,scheduled=True);general.assert_not_called()

    def test_disabled_gray_free_zero_is_read_without_clicking_or_using_tickets(self):
        import death_vision,death_runner as module
        from PIL import Image
        self.bind_all();r=self.app.profiles[0].death_runner;im=self.restore_frame('exp')
        with Image.open(ROOT/'assets/restore_digit_0.png') as tile:im.paste(tile,(203,536))
        im.paste(im.crop((145,525,222,555)).convert('L').convert('RGB'),(145,525))
        self.assertEqual(death_vision.restoration_count(im,'free'),0)
        self.assertEqual(death_vision.free_button(im)[0],0)
        with self.death_tick_patches(r),patch.object(module,'from_capture',return_value=im),patch.object(module,'click_client_point') as click:
            r.start(('general',None,None));r.phase='scan';r.tick();r.tick()
            click.assert_not_called();self.assertEqual(r.tab,1);self.assertFalse(r.hold)

    def test_free_bulk_charge_is_bounded_by_available_quota(self):
        import death_vision
        from PIL import Image
        im=self.restore_confirmation();im.paste((35,35,35),(419,288,446,309))
        with Image.open(ROOT/'assets/restore_digit_8.png') as tile:im.paste(tile,(427,292))
        self.assertEqual(death_vision.free_charge_count(im),8)
        self.assertFalse(death_vision.free_confirmation(im,3)[0])
        self.assertTrue(death_vision.free_confirmation(im,8)[0])
        self.assertFalse(death_vision.free_confirmation(im,0)[0])
    def test_unreadable_or_multi_digit_charge_is_not_treated_as_one(self):
        import death_vision
        from PIL import Image
        im=self.restore_confirmation();im.paste((35,35,35),(419,288,446,309))
        with Image.open(ROOT/'assets/restore_digit_8.png') as tile:
            im.paste(tile,(422,292));im.paste(tile,(432,292))
        self.assertIsNone(death_vision.free_charge_count(im))
        self.assertFalse(death_vision.free_confirmation(im,8)[0])

    def confirm_runner(self):
        self.bind_all();p=self.app.profiles[0];r=p.entry_runner
        patcher=patch('entry_runner.entry_confirm_button',return_value=(.99,494,381));patcher.start();self.addCleanup(patcher.stop)
        r.start(chained=True);r.phase='confirm'
        r.confirm_selection=(4,'조선왕릉','2층',14,520);r.confirm_heading=object();r.expected=r.confirm_selection[:3]
        return r
    def test_cursor_mismatch_is_proven_unsent(self):
        with patch('window_identity.validate'),patch.object(game_actions,'require_admin'),patch.object(game_actions,'title',return_value='HeroOfChosunClassic'),patch.object(game_actions,'bounds',return_value=(0,0,800,600)),patch.object(game_actions.u,'GetForegroundWindow',return_value=100),patch.object(game_actions.u,'GetAncestor',return_value=100),patch.object(game_actions.u,'SetCursorPos',return_value=1),patch.object(game_actions.u,'GetCursorPos',return_value=1),patch.object(game_actions.time,'sleep'),patch.object(game_actions.u,'SendInput') as send:
            with self.assertRaises(game_actions.ClickNotSent):game_actions.click_client_point(100,.622,.643)
            send.assert_not_called()
    def test_unsent_confirm_preserves_verified_target_and_retries(self):
        r=self.confirm_runner();before=r.confirm_selection
        with patch.object(r,'log'),patch('entry_runner.click_client_point',side_effect=game_actions.ClickNotSent('cursor moved')),patch('entry_runner.wallet',return_value=object()),patch.object(r,'save'):
            with self.assertRaises(game_actions.ClickNotSent) as caught:r.confirm(Mock(),r.confirm_selection)
            self.assertFalse(r.payment_sent);self.assertFalse(r.payment_uncertain)
            self.assertTrue(r.retry_unsent_confirm(caught.exception))
        self.assertEqual(r.confirm_selection,before);self.assertTrue(r.active);self.assertEqual(r.phase,'confirm')
    def test_unsent_confirmation_retry_is_bounded(self):
        r=self.confirm_runner()
        with patch.object(r,'log'):
            self.assertTrue(r.retry_unsent_confirm(game_actions.ClickNotSent('cursor')))
            self.assertTrue(r.retry_unsent_confirm(game_actions.ClickNotSent('cursor')))
            self.assertTrue(r.retry_unsent_confirm(game_actions.ClickNotSent('cursor')))
            self.assertFalse(r.retry_unsent_confirm(game_actions.ClickNotSent('cursor')))
        self.assertTrue(r.confirm_retry_exhausted)
    def test_uncertain_dispatch_is_never_retried_as_unsent(self):
        r=self.confirm_runner()
        with patch('entry_runner.click_client_point',side_effect=RuntimeError('mouse-up failed')),patch('entry_runner.wallet',return_value=object()),patch.object(r,'save'):
            with self.assertRaises(RuntimeError) as caught:r.confirm(Mock(),r.confirm_selection)
        self.assertTrue(r.payment_uncertain)
        self.assertFalse(r.retry_unsent_confirm(caught.exception))
        self.assertFalse(r.retry_unsent_confirm(game_actions.ClickNotSent('fake')))
    def test_successful_confirm_is_not_replayed(self):
        r=self.confirm_runner()
        with patch('entry_runner.click_client_point') as click,patch('entry_runner.wallet',return_value=object()),patch.object(r,'save'),patch.object(r,'log'):
            r.confirm(Mock(),r.confirm_selection);click.assert_called_once()
        self.assertTrue(r.payment_sent);self.assertEqual(r.phase,'arrival')
        self.assertFalse(r.retry_unsent_confirm(game_actions.ClickNotSent('cursor')))
    def test_changed_target_blocks_unsent_retry(self):
        r=self.confirm_runner();r.expected=(3,'전리품 매립지','3층')
        self.assertFalse(r.retry_unsent_confirm(game_actions.ClickNotSent('cursor')))
    def test_unowned_open_modal_stops_in_actionable_hold(self):
        import cycle_runner as module
        from contextlib import ExitStack
        self.bind_all();p=self.app.profiles[0];c=p.cycle_runner
        values={'special_screen':.97,'special_hud_timer':0,'auto_control':(0,0,0),'special_icon':(0,0,0),'special_entry_dialog':(.97,.98),'purchase_dialog':(0,0)}
        with ExitStack() as stack:
            for name,value in values.items():stack.enter_context(patch.object(module,name,return_value=value))
            stack.enter_context(patch.object(module,'ensure_view',return_value=True));stack.enter_context(patch.object(module,'capture',return_value=b'fake'));stack.enter_context(patch.object(module,'from_capture',return_value=Mock()));stack.enter_context(patch.object(module,'dismiss_attendance',return_value=False));stack.enter_context(patch.object(c,'save'));stack.enter_context(patch.object(c,'log'))
            scan=stack.enter_context(patch.object(p.special_runner,'start'))
            c.start_remaining(chained=True);c.resume_check()
            self.assertTrue(p.entry_confirmation_hold);self.assertFalse(c.active);scan.assert_not_called()
    def test_confirm_button_locator_finds_shifted_blue_button(self):
        from PIL import Image,ImageDraw
        import vision
        image=Image.new('RGB',(800,600),(30,30,30));draw=ImageDraw.Draw(image)
        draw.rectangle((430,350,590,405),fill=(35,60,95))
        label=Image.open(ROOT/'assets/entry_confirm_button_label.png').convert('RGB')
        image.paste(label,(500,365))
        score,x,y=vision.entry_confirm_button(image)
        self.assertGreater(score,.99);self.assertEqual((x,y),(514,374))
    def test_confirm_text_without_blue_button_is_rejected(self):
        from PIL import Image
        import vision
        image=Image.new('RGB',(800,600),(50,50,50))
        label=Image.open(ROOT/'assets/entry_confirm_button_label.png').convert('RGB')
        image.paste(label,(480,372))
        self.assertEqual(vision.entry_confirm_button(image)[0],0)
    def test_confirm_uses_detected_coordinates(self):
        r=self.confirm_runner()
        with patch('entry_runner.entry_confirm_button',return_value=(.99,520,390)),patch('entry_runner.click_client_point') as click,patch('entry_runner.wallet',return_value=object()),patch.object(r,'save'),patch.object(r,'log'):
            r.confirm(Mock(),r.confirm_selection)
            click.assert_called_once_with(100,520/800,390/600)
    def test_no_confirm_click_when_button_is_not_recognized(self):
        r=self.confirm_runner()
        with patch('entry_runner.entry_confirm_button',return_value=(0,490,380)),patch('entry_runner.click_client_point') as click:
            with self.assertRaisesRegex(RuntimeError,'버튼'):r.confirm(Mock(),r.confirm_selection)
            click.assert_not_called();self.assertFalse(r.payment_sent);self.assertFalse(r.payment_uncertain)
    def test_rendering_modal_does_not_rescan_dimmed_cards(self):
        import entry_runner as module
        r=self.confirm_runner()
        with patch.object(module,'ensure_view',return_value=True),patch.object(module,'capture',return_value=b'fake'),patch.object(module,'from_capture',return_value=Mock()),patch.object(module,'dismiss_attendance',return_value=False),patch.object(module,'special_entry_dialog',return_value=(.2,.3)),patch.object(module,'special_screen',return_value=.97),patch.object(module,'notice',return_value=0),patch.object(r,'selection') as selection,patch.object(module,'click_client_point') as click,patch.object(r,'finish') as finish,patch.object(r,'log'):
            r.tick();selection.assert_not_called();click.assert_not_called();finish.assert_not_called()
        self.assertEqual(r.phase,'confirm');self.assertTrue(r.active)
    def test_resume_hints_do_not_cross_profiles(self):
        p=self.app.profiles[3];session_state.checkpoint(p,True,(1,'부패한 도성','4층'),[0])
        self.assertTrue(session_state.note(p)['charged'])
        self.assertEqual(session_state.note(self.app.profiles[0]),{})

if __name__=='__main__':unittest.main(verbosity=2)
