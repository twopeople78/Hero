"""A HWND is session-local: never silently assign a replacement by screen position."""
import ctypes as c
from ctypes import wintypes as w
from window_link import u, title

u.GetWindowThreadProcessId.argtypes = [w.HWND, c.POINTER(w.DWORD)]
u.GetWindowThreadProcessId.restype = w.DWORD
k = c.WinDLL('kernel32', use_last_error=True)
k.OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]
k.OpenProcess.restype = w.HANDLE
k.GetProcessTimes.argtypes = [w.HANDLE] + [c.POINTER(w.FILETIME)]*4
k.GetProcessTimes.restype = w.BOOL
k.CloseHandle.argtypes = [w.HANDLE]

def identity(hwnd):
    if not hwnd or not u.IsWindow(hwnd) or title(hwnd).strip().lower() != 'heroofchosunclassic': return None
    pid = w.DWORD()
    if not u.GetWindowThreadProcessId(hwnd, c.byref(pid)): return None
    process = k.OpenProcess(0x1000, False, pid.value)
    if not process: return None
    times = [w.FILETIME() for _ in range(4)]
    try:
        if not k.GetProcessTimes(process, *(c.byref(t) for t in times)): return None
        created = times[0].dwLowDateTime | (times[0].dwHighDateTime << 32)
        return (int(hwnd), pid.value, created)
    finally:
        k.CloseHandle(process)

# Only a manually connected window is eligible for capture/input in this process.
authorized = {}

def validate(hwnd):
    expected=authorized.get(hwnd)
    if expected is None or identity(hwnd)!=expected:
        raise RuntimeError('게임 창의 연결 정보가 바뀌었습니다. 해당 캐릭터를 다시 연결하세요.')
