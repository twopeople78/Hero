"""Explicit Windows UAC launch; never dispatch game input without elevation."""
import ctypes
from ctypes import wintypes
from pathlib import Path
import subprocess
import sys

BUILD = 'FOUR-WINDOW · REV.20 · 20261107'


def is_admin():
    shell = ctypes.WinDLL('shell32', use_last_error=True)
    shell.IsUserAnAdmin.argtypes = []
    shell.IsUserAnAdmin.restype = wintypes.BOOL
    return bool(shell.IsUserAnAdmin())


def require_admin():
    if not is_admin():
        raise RuntimeError('관리자 권한이 없어 입력 취소 · GUI를 닫고 다시 실행하여 권한 요청을 승인하세요.')


def launch_as_admin(script):
    """Return True only in the elevated process; cancellation never opens the GUI."""
    if is_admin():
        return True
    script = Path(script).resolve()
    try:
        if '--admin-relaunch' in sys.argv:
            raise RuntimeError('재실행 후에도 관리자 권한이 없습니다.')
        executable = Path(sys.executable)
        windowless = executable.with_name('pythonw.exe')
        if windowless.is_file():
            executable = windowless
        shell = ctypes.WinDLL('shell32', use_last_error=True)
        shell.ShellExecuteW.argtypes = [wintypes.HWND, wintypes.LPCWSTR,
                                       wintypes.LPCWSTR, wintypes.LPCWSTR,
                                       wintypes.LPCWSTR, ctypes.c_int]
        shell.ShellExecuteW.restype = ctypes.c_void_p
        arguments = subprocess.list2cmdline([str(script), '--admin-relaunch'])
        result = shell.ShellExecuteW(None, 'runas', str(executable), arguments,
                                    str(script.parent), 1)
        if not result or result <= 32:
            raise RuntimeError(f'관리자 실행 요청이 취소되었거나 실패했습니다. 코드: {result}')
    except Exception as exc:
        user = ctypes.WinDLL('user32', use_last_error=True)
        user.MessageBoxW.argtypes = [wintypes.HWND, wintypes.LPCWSTR,
                                    wintypes.LPCWSTR, wintypes.UINT]
        user.MessageBoxW(None, str(exc), '조선 사냥 일정 관리 · 실행 실패', 0x10)
    return False
