from runner_timer import runner_after, invalidate
from runner_focus import ensure_view
from attendance import dismiss_attendance, reset_attendance
"""One event entry, AUTO, observation and scheduled return to general hunt."""
import time
import numpy as np
from datetime import datetime
from pathlib import Path
from window_link import capture
from game_actions import check_game_view,check_observation_area,click_client_point,scroll_region_list
from buy_runner import wallet,wallet_similarity
from special_runner import full_card
from vision import (from_capture,special_screen,special_icon,world_map,selected_card,
    auto_control,auto_mode,combat_active,notice,shop,warehouse,quest_travel,special_hud_timer,town,general_location,main_menu_button)
from event_vision import event_card,tab_score,floor_one,event_dialog,event_location
from event_schedule import events_for
from stall_watch import note_frame
from passive_observer import event_return_visible

class EventRunner:
    def __init__(self,owner):
        self.owner=owner;self.active=False;self.job=None;self.phase='idle'

    def stop(self):
        self.menu_repair_pending=False
        self.observed_menu_hits=0
        recovery=getattr(self.owner,'recovery_runner',None)
        if self.phase=='auto_recovery' and recovery is not None and recovery.active:recovery.stop()
        invalidate(self)
        self.active=False
        if self.job is not None:self.owner.after_cancel(self.job);self.job=None

    def log(self,text):
        self.owner.town_log('[이벤트 진행] '+text)
        try:
            path=Path(__file__).resolve().parent/'diagnostics';path.mkdir(exist_ok=True)
            with (path/'event_entry.log').open('a',encoding='utf-8') as f:
                f.write(f'{datetime.now():%Y-%m-%d %H:%M:%S} 창{getattr(self,"handle",0)} {self.phase} {text}\n')
        except OSError:pass

    def save(self,image,label):
        try:
            path=Path(__file__).resolve().parent/'diagnostics';path.mkdir(exist_ok=True)
            image.save(path/f'{datetime.now():%Y%m%d_%H%M%S}_{self.handle}_event_{self.event.key}_{label}.png')
        except OSError:pass

    def start(self,event,deadline):
        self.stop();self.event=event;self.end=deadline
        current=self.owner.event_scheduler.now()
        if (not self.owner.daily_scheduler.active or current>=deadline or
                event not in events_for(self.owner,current.date()) or
                not event.start<=current.time()<event.end):
            self.log('예약이 꺼졌거나 이벤트 종료 시각이 지나 입장하지 않습니다.');return
        self.handle=self.owner.window_link.hwnd
        self.phase='origin';reset_attendance(self)
        self.active=True;self.hits=0;self.touched=False
        self.origin_closed=False;self.origin_menu_closed=False
        self.clicked_icon=False;self.menu_opened=False;self.map_closed=False;self.tab_clicked=False
        self.scrolled=0;self.seen_timer=False;self.paused=False;self.entry_clicked=False;self.confirmed=False
        self.seen_combat=False
        self.resumed_existing=False;self.resume_queued=False;self.identity_retry_at=0
        self.passive_event_hits=0
        self.hidden_since=None;self.focus_retry_at=0
        self.menu_attempts=0;self.icon_attempts=0;self.last_open_at=-100
        self.last_origin_trace=-100
        self.deadline=time.monotonic()+180;self.limit=time.monotonic()+25
        self.owner.event_scheduler.entering(event,deadline)
        self.log(event.name+' 1층 · 일반 사냥에서 이벤트 메뉴 이동 시작')
        self.job=runner_after(self,1000,self.tick)

    def later(self):self.job=runner_after(self,1500 if self.phase in ('observe','identify_existing') else 300,self.tick)

    def resume_after_entry(self,event,deadline):
        """An entry was attempted: inspect the existing hunt, never pay again."""
        self.stop();self.event=event;self.end=deadline
        if not self.owner.daily_scheduler.active or not self.owner.event_scheduler.active:return
        if self.owner.event_scheduler.now()>=deadline:
            self.owner.event_scheduler.request_return(event,deadline,'입장 결과 확인 중 예약 종료');return
        self.handle=self.owner.window_link.hwnd
        self.active=True;self.phase='identify_existing';self.hits=0
        self.resumed_existing=True;self.resume_queued=False;self.identity_retry_at=0
        self.passive_event_hits=0;self.hidden_since=None
        self.owner.event_scheduler.entering(event,deadline)
        self.log('입장 결과 재확인 · 현재 사냥 유지 · 재입장·강제 일반사냥 이동 없음')
        self.later()

    def auto_recovered(self,success):
        if not self.active or self.phase!='auto_recovery':return
        if not success:
            if self.resumed_existing:
                self.change('identify_existing');self.identity_retry_at=time.monotonic()+30
                self.resume_queued=False
                self.log('현재 이벤트 사냥 유지 · AUTO 확인 보류 · 재입장 없이 노출된 HUD 재확인')
                return
            self.fail('이벤트 AUTO 켜짐 확인 보류 · 현재 사냥 유지')
            return
        self.phase='observe';self.hits=0;self.entered_at=time.monotonic();self.seen_timer=False
        self.log(self.event.name+' 1층 AUTO 켜짐 확인 → 종료 후 '+self.owner.destination+' 복귀')
        self.owner.winfo_toplevel().work_coordinator.handoff(self.owner)
    def stable(self,valid):
        self.hits=self.hits+1 if valid else 0
        return self.hits>=2
    def change(self,phase,limit=20):
        self.phase=phase;self.hits=0;self.limit=time.monotonic()+limit

    def fail(self,text,image=None):
        if image is not None:self.save(image,'error')
        self.stop();self.log(text)
        self.owner.event_scheduler.entry_failed(self.event,self.end,text,restore=self.touched,
                                               paid=self.confirmed,entry_clicked=self.entry_clicked)

    def tick(self):
        self.job=None
        if not self.active:return
        image=None
        try:
            if self.handle!=self.owner.window_link.hwnd:raise RuntimeError('연결된 게임 창 변경')
            if not self.owner.event_scheduler.active:self.stop();return
            if self.owner.event_scheduler.now()>=self.end:
                self.owner.event_scheduler.request_return(self.event,self.end,'예약 종료 시각');self.stop();return
            if self.phase=='identify_existing':
                # Read only the independently visible HUD, without focus/input.
                try:
                    if not ensure_view(self,check_game_view,observing=True):self.hits=0;self.later();return
                    before=check_observation_area(self.handle)
                    source=from_capture(capture(self.handle))
                    if check_observation_area(self.handle)!=before:raise RuntimeError('HUD 위치 변경')
                except RuntimeError:
                    self.hits=0;self.later();return
                known=(event_location(source,self.event.key)>=.90 and special_hud_timer(source)>=.78)
                # Before any entry click, a positively identified ordinary field
                # can release a timer-only hold. An uncertain paid entry cannot.
                ordinary=(general_location(source,self.owner.general_key)>=.82 or town(source)>=.85)
                safe_field=(ordinary and auto_control(source)[0]>=.90 and not known and
                            max(notice(source),shop(source),warehouse(source),quest_travel(source),special_screen(source),world_map(source))<.70)
                self.ordinary_hits=getattr(self,'ordinary_hits',0)+1 if safe_field else 0
                if self.ordinary_hits>=3 and not getattr(self,'entry_clicked',False) and not getattr(self,'confirmed',False):
                    self.log('미니맵 일반사냥·마을 연속 확인 → 시간표시만의 대기 해제 · 이벤트 입장 재예약')
                    self.owner.event_scheduler.recheck_from_field('general')
                    return
                auto_known=auto_mode(source) in ('on','off')
                if self.stable(known) and auto_known and not self.resume_queued and time.monotonic()>=self.identity_retry_at:
                    app=self.owner.winfo_toplevel();index=app.profiles.index(self.owner)
                    self.resume_queued=True
                    app.work_coordinator.submit(index,'이벤트 사냥 이어받기',
                        lambda:self.start(self.event,self.end),scheduled=True,priority=True)
                self.later();return
            if self.phase=='auto_recovery':self.later();return
            if self.phase=='observe' and event_return_visible(self):
                self.owner.event_scheduler.request_return(self.event,self.end,'노출된 HUD에서 일반사냥 자동 복귀 확인')
                self.stop();return
            if not ensure_view(self,check_game_view,observing=self.phase=='observe'):
                self.later();return
            image=from_capture(capture(self.handle))
            if dismiss_attendance(self,image):self.later();return
            now=time.monotonic()
            if self.phase!='observe' and (now>self.deadline or now>self.limit):
                raise RuntimeError(self.phase+' 확인 시간 초과 · 입장·AUTO를 반복하지 않습니다.')
            if self.phase=='observe':
                timer=special_hud_timer(image)
                self.seen_timer=self.seen_timer or timer>=.78
                field=auto_control(image)[0]>=.78 or auto_mode(image)=='on'
                blocked=max(notice(image),shop(image),warehouse(image),quest_travel(image),special_screen(image),world_map(image))>=.70
                if field and not blocked:note_frame(self.owner,image,hunting=True)
                back=general_location(image,self.owner.general_key)>=.85
                if self.stable(field and back and not blocked) and now-self.entered_at>=10:
                    self.save(image,'early_return')
                    self.owner.event_scheduler.request_return(self.event,self.end,'실제 이벤트 종료·필드 복귀 확인')
                    self.stop();return
                self.later();return
            if max(notice(image),shop(image),warehouse(image),quest_travel(image))>=.82:
                raise RuntimeError('알림·상점·창고 등 다른 화면이 있어 입장 중지')
            screen=special_screen(image)
            if self.phase=='origin':
                already_here=(screen<.70 and world_map(image)<.70 and
                              event_location(image,self.event.key)>=.90 and
                              special_hud_timer(image)>=.78)
                if already_here:
                    if self.stable(True):
                        self.phase='auto_recovery';self.hits=0
                        self.resumed_existing=True
                        self.log(self.event.name+' 실제 미니맵 위치·남은시간 연속 확인 → 재입장 없이 AUTO 확인·이벤트 관찰 재개')
                        self.owner.recovery_runner.start(require='event',done=self.auto_recovered)
                elif screen>=.85 or world_map(image)>=.85:
                    self.hits=0
                    if not self.origin_closed:
                        click_client_point(self.handle,774/800,20/600);self.origin_closed=True
                elif special_icon(image)[0]>=.82:
                    if self.stable(True):
                        self.log('이미 열린 전체 메뉴 연속 확인 → 닫기 없이 특수지역으로 연결')
                        self.change('open')
                else:
                    known_origin=(general_location(image,self.owner.general_key)>=.82 or town(image)>=.85) and auto_control(image)[0]>=.90
                    if special_hud_timer(image)>=.60 and not known_origin:
                        self.ordinary_hits=0
                        self.change('identify_existing')
                        self.log('현재 시간제 사냥 유지 · 지역명 확인 대기 · 재입장·주기적 창 전환 없음')
                        self.later();return
                    known_score=max(town(image),general_location(image,self.owner.general_key))
                    known=known_score>=.78
                    hud=auto_control(image)[0]
                    mode=auto_mode(image)
                    field=(known and (hud>=.78 or mode=='on' or combat_active(image)>=.80 or main_menu_button(image)[0]>=.90)) or (hud>=.90 and mode in ('on','off'))
                    if now-self.last_origin_trace>=5:
                        self.log(f'출발 화면 판독 · 지역 {known_score:.3f} / 필드 {hud:.3f} / AUTO {mode} / 출발 가능 {field}')
                        self.last_origin_trace=now
                    if self.stable(field):
                        self.log('일반 사냥터 또는 한밭마을 출발 화면 연속 확인')
                        self.change('open')
            elif self.phase=='open':
                if screen>=.85:
                    if self.stable(True):self.touched=True;self.change('tab')
                elif world_map(image)>=.85:
                    if not self.map_closed:
                        click_client_point(self.handle,774/800,20/600);self.map_closed=True;self.touched=True
                else:
                    self.hits=0
                    known_origin=(general_location(image,self.owner.general_key)>=.82 or town(image)>=.85) and auto_control(image)[0]>=.90
                    if special_hud_timer(image)>=.60 and not known_origin:
                        raise RuntimeError('이미 다른 시간제 지역 사냥 중 · 중복 입장하지 않습니다.')
                    score,x,y=special_icon(image)
                    if score>=.82 and self.icon_attempts<3 and time.monotonic()-self.last_open_at>=3:
                        click_client_point(self.handle,x/800,y/600);self.clicked_icon=True;self.touched=True
                        self.icon_attempts+=1;self.last_open_at=time.monotonic()
                    elif score<.82 and self.menu_attempts<3 and time.monotonic()-self.last_open_at>=3:
                        button,bx,by=main_menu_button(image)
                        if button>=.82:
                            click_client_point(self.handle,bx/800,by/600);self.menu_opened=True;self.touched=True
                            self.menu_attempts+=1;self.last_open_at=time.monotonic()
            elif screen<.85 and self.phase not in ('arrival','combat'):
                raise RuntimeError('특수지역 메뉴가 확인되지 않습니다.')
            elif self.phase=='tab':
                if self.stable(tab_score(image,self.event.tab)>=.85):self.change('find',25)
                elif not self.tab_clicked and tab_score(image,self.event.tab)<.85:
                    click_client_point(self.handle,(65 if self.event.tab=='special' else 266)/800,65/600)
                    self.tab_clicked=True
            elif self.phase=='find':
                score,left,top=event_card(image,self.event.key)
                if score>=.85 and full_card(left,top):
                    click_client_point(self.handle,(left+95)/800,(top+38)/600)
                    self.log(self.event.name+' 이름·카드 확인 → 선택')
                    self.change('floor')
                elif self.scrolled<10:
                    scroll_region_list(self.handle,240 if self.scrolled<2 else -240);self.scrolled+=1
                else:raise RuntimeError(self.event.name+' 전체 카드를 찾지 못했습니다.')
            elif self.phase in ('floor','ready','confirm'):
                score,left,top=event_card(image,self.event.key)
                selected=(score>=.85 and full_card(left,top) and selected_card(image,left,top)
                          and tab_score(image,self.event.tab)>=.85)
                if self.phase=='confirm':
                    # The confirmation dialog can cover the end of a card's
                    # name. Preserve its verified, unobscured artwork instead.
                    top=self.selected_top
                    patch=np.asarray(image.convert('L'),dtype=float)[top+10:top+65,25:140]
                    selected=(selected_card(image,17,top) and tab_score(image,self.event.tab)>=.85
                              and wallet_similarity(self.selection_patch,patch)>=.90)
                if self.phase=='floor':
                    if self.stable(selected):
                        if self.event.key in ('abandoned','gadeok'):
                            self.log(self.event.name+' 선택 연속 확인 · 단일 층이므로 층 클릭 없이 입장 준비')
                        else:
                            click_client_point(self.handle,681/800,484/600)
                        self.change('ready')
                else:
                    gold,x,y=floor_one(image,self.event.tab)
                    valid=selected and gold>=.82
                    dialog=event_dialog(image)
                    if self.phase=='ready' and self.stable(valid and not dialog):
                        self.save(image,'selected_1f')
                        self.selected_top=top
                        self.selection_patch=np.asarray(image.convert('L'),dtype=float)[top+10:top+65,25:140].copy()
                        click_client_point(self.handle,.85,.95);self.entry_clicked=True
                        self.change('confirm',12)
                        self.log(self.event.name+' 1층 연속 확인 → 입장 1회')
                    elif self.phase=='confirm' and self.stable(valid and dialog):
                        self.before_wallet=wallet(image);self.save(image,'before_confirm')
                        click_client_point(self.handle,.622,.643);self.confirmed=True
                        self.change('arrival',30);self.log('입장 질문·지불 엽전·선택 지역 1층 확인 → 확인 1회')
            elif self.phase=='arrival':
                auto,x,y=auto_control(image)
                located=(event_location(image,self.event.key)>=.90 and special_hud_timer(image)>=.78)
                valid=self.confirmed and self.entry_clicked and screen<.70 and not event_dialog(image) and (located or auto>=.78 or auto_mode(image) in ('on','off')) and wallet_similarity(self.before_wallet,wallet(image))<.98
                if self.stable(valid):
                    self.phase='auto_recovery';self.hits=0
                    self.resumed_existing=True
                    self.log('이벤트 필드·재화 변화 확인 → 공통 AUTO 상태 확인·복구')
                    # Our own confirmed fee and wallet transition prove arrival.
                    # Event countdown announcements also exist outside the zone;
                    # do not require or trust them as the daily-region timer.
                    self.owner.recovery_runner.start(require='event' if located else 'arrival',done=self.auto_recovered)
            elif self.phase=='combat':
                if self.stable(screen<.70 and auto_control(image)[0]>=.78 and combat_active(image)>=.80):
                    self.save(image,'combat');self.phase='observe';self.hits=0;self.entered_at=now
                    self.log(self.event.name+' 1층 자동 전투 확인 → 종료 후 '+self.owner.destination+' 복귀')
            self.later()
        except Exception as exc:self.fail(str(exc),image)
