"""Export per-character runtime state and bounded logs; never export credentials."""
import json,re,struct,sys,math
from datetime import datetime,timezone,timedelta
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from admin_launch import BUILD

RUNNERS=('supply_runner','special_runner','entry_runner','cycle_runner','general_runner','event_runner','recovery_runner','observation_menu_runner')


def scrub(text):
    return re.sub(r'\b[0-9]{6,}:[A-Za-z0-9_-]{20,}\b','[Telegram 토큰 가림]',text)


def runtime_snapshot(app):
    from status_board import profile_status
    profiles=[]
    for i,p in enumerate(app.profiles):
        runners={}
        for name in RUNNERS:
            runner=getattr(p,name,None)
            if runner is None:continue
            runners[name]={k:getattr(runner,k,None) for k in ('active','phase','required_expired','index','retry_count','general_pending','hidden_since','deadline','limit','phase_deadline')}
            runners[name]={k:'무제한' if isinstance(v,float) and not math.isfinite(v) else v for k,v in runners[name].items()}
        scheduler=p.event_scheduler
        profiles.append(dict(character=i+1,profile_id=p.profile_id,window=p.window_link.hwnd,
            status=profile_status(app,i),routes=p.routes,general=p.general_key,
            events=sorted(p.selected_events),daily_active=p.daily_scheduler.active,
            startup_unresolved=getattr(p,'startup_unresolved',False),
            confirmed_field=getattr(p,'confirmed_field',None),runners=runners,
            event_active=scheduler.active,event_session=str(scheduler.session),
            event_return_check=str(scheduler.return_check),event_attempted=str(scheduler.attempted)))
    q=app.work_coordinator
    def request(r):return None if r is None else {k:r.get(k) for k in ('index','handle','kind','scheduled','priority','not_before','retry_reason')}
    return dict(build=BUILD,created=datetime.now(timezone(timedelta(hours=9))).isoformat(),
        python=sys.version,python_bits=struct.calcsize('P')*8,
        profiles=profiles,queue=dict(active=q.active,current=request(q.current),pending=[request(r) for r in q.pending]),
        focus_active=app.focus_runner.active)


def export_bundle(app,destination,log_dir=None):
    folder=Path(log_dir) if log_dir is not None else Path(__file__).resolve().parent/'diagnostics'
    destination=Path(destination)
    snapshot=runtime_snapshot(app)
    with ZipFile(destination,'w',ZIP_DEFLATED) as archive:
        archive.writestr('current_state.json',json.dumps(snapshot,ensure_ascii=False,indent=2,allow_nan=True))
        for path in sorted(folder.glob('*.log')):
            if path.is_file():
                with path.open('rb') as stream:
                    stream.seek(0,2);size=stream.tell();stream.seek(max(0,size-2*1024*1024))
                    data=stream.read().decode('utf-8',errors='replace')
                archive.writestr('logs/'+path.name,scrub(data))
        handles={str(p.window_link.hwnd) for p in app.profiles}
        images={handle:[] for handle in handles}
        for path in folder.glob('*.png'):
            match=re.match(r'^\d{8}_\d{6}_(\d+)_',path.name)
            if match and match[1] in images and path.is_file() and path.stat().st_size<=2*1024*1024:
                images[match[1]].append(path)
        for candidates in images.values():
            for path in sorted(candidates,key=lambda p:p.stat().st_mtime,reverse=True)[:2]:
                archive.write(path,'recent_game_captures/'+path.name)
        for path in sorted(folder.glob('*_special_results.json'),key=lambda p:p.stat().st_mtime,reverse=True)[:8]:
            if re.match(r'^\d{8}_\d{6}_\d+_special_results.json$',path.name) and path.stat().st_size<256*1024:
                archive.writestr('recognition_results/'+path.name,scrub(path.read_text(encoding='utf-8',errors='replace')))
        archive.writestr('안내.txt' ,'현재 네 캐릭터 상태와 최근 로그입니다. 계정 설정·Telegram 인증 파일은 포함하지 않습니다. 최근 게임 진단 캡처는 창별 최대 2장 포함되며 현재 시점 사진이 아닐 수 있습니다.\n')
    return destination


def save_dialog(app):
    from tkinter import filedialog,messagebox
    target=filedialog.asksaveasfilename(parent=app,title='진단 로그 ZIP 저장',defaultextension='.zip',
        initialfile='HeroClassic_진단_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.zip',filetypes=[('ZIP 파일','*.zip')])
    if not target:return
    try:
        export_bundle(app,target)
        messagebox.showinfo('진단 로그 저장','진단 ZIP을 저장했습니다. 이 파일을 대화에 첨부해 주세요.',parent=app)
    except (OSError,ValueError) as exc:messagebox.showerror('진단 로그 저장 실패',str(exc),parent=app)
