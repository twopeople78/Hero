"""Independent daily clocks dispatch through the shared foreground queue."""
from datetime import datetime, timezone, timedelta, time as clock_time
from pathlib import Path

KST = timezone(timedelta(hours=9))


class DailyScheduler:
    def __init__(self, owner):
        self.owner = owner
        self.active = False
        self.job = None

    def stop(self):
        was_active = self.active
        self.active = False
        if hasattr(self.owner,'reconnect_watch'):self.owner.reconnect_watch.stop()
        if hasattr(self.owner,'event_scheduler'):self.owner.event_scheduler.stop()
        app=self.owner.winfo_toplevel()
        if hasattr(app,'work_coordinator') and self.owner in app.profiles:
            app.work_coordinator.cancel_scheduled(app.profiles.index(self.owner))
        if self.job is not None:
            self.owner.after_cancel(self.job)
            self.job = None
        if hasattr(self.owner, 'reservation_status'):
            self.owner.reservation_status.set('매일 예약 꺼짐')
        if was_active:
            self.log('예약 꺼짐 · 현재 게임의 AUTO는 토글하지 않습니다.')

    def log(self, text):
        self.owner.town_log('[매일 예약] '+text)
        try:
            folder=Path(__file__).resolve().parent/'diagnostics'
            folder.mkdir(exist_ok=True)
            with (folder/'daily_schedule.log').open('a',encoding='utf-8') as stream:
                stream.write(f'{self.now():%Y-%m-%d %H:%M:%S %z} 창{getattr(self,"handle",0)} {text}\n')
        except OSError:
            pass

    def update_status(self, now):
        if getattr(self,'special_day',None)==now.date():
            state='오늘 특수지역 예약 실행됨 · 진행 상태는 캐릭터 현황 확인'
        elif getattr(self,'supply_retry_at',None) is not None:
            state='출발 확인 재검사 대기 · '+self.supply_retry_at.strftime('%H:%M:%S')
        elif self.failed and self.supply_day == now.date():
            state='보급 실패 · '+self.special_time.strftime('%H:%M')+' 특수지역 검사 예정'
        elif self.supply_started and self.supply_day == now.date() and not self.supply_ok:
            state='보급 진행·확인 대기'
        elif self.supply_ok and self.special_day != now.date():
            state='보급 완료 · 특수지역 '+self.special_time.strftime('%H:%M')+' 대기'
        else:
            state='사냥 유지'
        next_day=now.date() if now.time() < self.supply_time else now.date()+timedelta(days=1)
        self.owner.reservation_status.set(
            f'매일 예약 켜짐 · {state} · 다음 보급 {next_day:%m/%d} {self.supply_time:%H:%M} / 특수지역 {self.special_time:%H:%M} (한국 시간)')

    @staticmethod
    def now():
        return datetime.now(KST)

    def arm(self):
        if not self.owner.window_link.hwnd:
            self.owner.town_log('[매일 예약] 게임 창을 먼저 연결하세요. 예약을 켜지 않았습니다.')
            return
        try:
            self.supply_time = datetime.strptime(self.owner.supply.get(), '%H:%M').time()
            self.special_time = datetime.strptime(self.owner.start.get(), '%H:%M').time()
            if self.special_time <= self.supply_time:
                raise ValueError('특수지역 시작 시각은 보급 시각보다 뒤여야 합니다.')
        except ValueError as exc:
            self.owner.town_log('[매일 예약] 시간 설정 오류 · '+str(exc))
            return
        self.stop()
        self.handle=self.owner.window_link.hwnd
        # Two profiles may be armed, but never against the same game window.
        for profile in self.owner.winfo_toplevel().profiles:
            if (profile is not self.owner and profile.daily_scheduler.active and
                    profile.window_link.hwnd == self.handle):
                self.log('같은 게임 창이 다른 캐릭터 예약에 연결되어 예약을 켜지 않았습니다.')
                return
        now = self.now()
        self.supply_day = now.date() if now.time() >= self.supply_time else None
        self.special_day = now.date() if now.time() >= self.special_time else None
        self.attendance_day=None;self.attendance_slot=None;self.attendance_closed_day=None
        self.supply_retry_at=None;self.supply_retry_count=0
        self.supply_ok = False
        self.supply_started = False
        self.failed = False
        self.active = True
        self.owner.death_runner.hold=False
        if hasattr(self.owner,'reconnect_watch'):self.owner.reconnect_watch.start()
        self.update_status(now)
        self.log('켜짐 · 현재 사냥 유지 · 이미 지난 당일 시각은 소급 실행하지 않습니다. 프로그램을 켜두세요.')
        self.job = self.owner.after(1000, self.tick)
        if hasattr(self.owner,'event_scheduler') and self.owner.event_enabled.get():
            self.owner.event_scheduler.arm()
        app=self.owner.winfo_toplevel()
        self.owner.startup_unresolved=True
        if hasattr(app,'launch_recovery'):app.launch_recovery(app.profiles.index(self.owner),scheduled=True,resume_route=True)
        if any(p.daily_scheduler.active for p in app.profiles):
            app.dual_runner.start()

    def supply_complete(self):
        if self.active:
            self.supply_ok = True
            self.failed=False;self.supply_retry_at=None
            self.log('보급 완료 · '+self.special_time.strftime('%H:%M')+' 특수지역 시작 대기')
            self.update_status(self.now())

    def supply_failed(self, reason, retryable=False):
        if self.active:
            self.failed = True
            now=self.now()
            count=getattr(self,'supply_retry_count',0)
            if (retryable and count<2 and self.supply_day==now.date() and now.time()<self.special_time):
                self.supply_retry_count=count+1
                self.supply_retry_at=now+timedelta(seconds=30*2**count)
                self.log(f'이동 전 출발 판독 일시 실패 → 재검사 {count+1}/2 예약 · '+reason)
            else:
                self.supply_retry_at=None
                self.log('보급 확인 실패 · 예약 시각에 보급 없이 특수지역 검사 · '+reason)
            self.update_status(now)

    def tick(self):
        self.job = None
        if not self.active:
            return
        now = self.now()
        day = now.date()
        app = self.owner.winfo_toplevel()
        index = app.profiles.index(self.owner)
        if self.owner.window_link.hwnd != self.handle:
            self.stop()
            self.log('연결된 게임 창이 바뀌어 예약 해제 · 연결 확인 후 다시 예약을 켜세요.')
            return
        if now.time() >= self.supply_time and self.supply_day != day:
            self.supply_day = day
            self.supply_retry_at=None;self.supply_retry_count=0
            self.supply_ok = False
            self.supply_started = True
            self.failed = False
            self.log('보급 시각 도달 → 게임 활성화·한밭마을 복귀')
            app.launch_supply(index, scheduled=True)
        retry_at=getattr(self,'supply_retry_at',None)
        if retry_at is not None and now>=retry_at:
            self.supply_retry_at=None
            if self.supply_day==day and now.time()<self.special_time:
                self.failed=False
                self.log('이동 전 출발 판독 재검사 → 다른 창 작업과 순서대로 보급 재개')
                app.launch_supply(index,scheduled=True,retry=True)
        # Short, separate turns catch popups rendered after the first 05:00 check.
        elapsed=now.hour*3600+now.minute*60+now.second-5*3600
        if 0<=elapsed<600 and getattr(self,'attendance_closed_day',None)!=day:
            slots=(0,30,60,120,240,480)
            slot=max(t for t in slots if t<=elapsed)
            key=(day,slot)
            if getattr(self,'attendance_slot',None)!=key:
                self.attendance_slot=key;self.attendance_day=day
                self.log('출석창 확인 예약 · 지연 표시 재검사 포함')
                app.work_coordinator.submit(index,'05시 출석창 확인',
                    self.owner.attendance_runner.start,scheduled=True)
        if (self.active and now.time() >= self.special_time and self.special_day != day
                and self.supply_day == day):
            # A queued, not-yet-started supply must yield to the 05:01 route.
            from collections import deque
            q=app.work_coordinator
            waiting=[r for r in q.pending if r['index']==index and r['kind']=='예약 보급']
            if waiting:
                q.pending=deque(r for r in q.pending if r not in waiting)
                self.failed=True
                self.log('특수지역 시각 도달 · 미시작 보급 대기 취소 → 특수지역 우선')
            if self.supply_ok or self.failed:
                self.special_day = day;self.supply_retry_at=None
                self.log(('보급 완료' if self.supply_ok else '보급 실패에도 예약 유지')+' → 현재 이용시간 재검사 · 특수지역 진행')
                app.launch_remaining(index, scheduled=True,morning_only=True)
            # An already-running supply completes or fails before yielding.
        if self.active:
            self.update_status(now)
            self.job = self.owner.after(1000, self.tick)
