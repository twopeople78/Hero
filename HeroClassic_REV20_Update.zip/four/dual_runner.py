"""Four-window read turns. Foreground actions always take precedence."""
import time
from runner_timer import runner_after, invalidate
from focus_guard import focus_allowed, switching_paused
from work_coordinator import WorkCoordinator

class DualRunner:
    def __init__(self, app):
        self.app=app;self.active=False;self.job=None
        self.current=None;self.due=0;self.last={};self.next_attempt=0

    def stop(self):
        invalidate(self);self.active=False
        if self.job is not None:self.app.after_cancel(self.job);self.job=None

    def start(self):
        if self.active:return
        self.active=True;self.last={};self.due=time.monotonic()+2
        self.job=runner_after(self,1000,self.tick)

    @staticmethod
    def observing(profile):
        return any(getattr(r,'active',False) and getattr(r,'phase',None) in ('observe','identify_existing')
                   for r in (profile.cycle_runner,profile.event_runner))

    busy=staticmethod(WorkCoordinator.busy)

    def tick(self):
        self.job=None
        if not self.active:return
        try:self.tick_once()
        finally:
            if self.active:self.job=runner_after(self,1000,self.tick)

    def tick_once(self):
        app=self.app;now=time.monotonic();q=app.work_coordinator
        if (switching_paused(app) or app.focus_runner.active or q.active or q.ready_pending(now)
                or any(self.busy(p) for p in app.profiles) or now<max(self.due,self.next_attempt)):
            return
        eligible=[i for i,p in enumerate(app.profiles)
                  if (p.daily_scheduler.active or self.observing(p)) and p.window_link.valid()]
        if not eligible:return
        interval=self.app.observation_seconds()
        ready=[i for i in eligible if now-self.last.get(i,-1e9)>=interval*len(self.app.profiles)]
        if not ready:return
        index=min(ready,key=lambda i:(self.last.get(i,-1e9),i))
        profile=app.profiles[index];handle=profile.window_link.hwnd
        if not focus_allowed(app,handle):return
        self.next_attempt=now+interval
        def success():
            if not self.active or profile.window_link.hwnd!=handle or not profile.window_link.valid():return
            self.current=index;self.last[index]=time.monotonic();self.due=time.monotonic()+interval
            app.mode.set(profile.display_name+' · 미니맵·시간표시 확인 중')
            # Reuse this already-authorized foreground turn; no extra polling focus.
            from attendance import attendance_point
            from vision import from_capture
            from window_link import capture
            try:
                score,_,_=attendance_point(from_capture(capture(handle)))
                if score>=.88:
                    profile.town_log('[화면 순회] 출석창 발견 → 닫힘 확인 작업 등록')
                    q.submit(index,'05시 출석창 확인',profile.attendance_runner.start,scheduled=True,priority=True)
            except (OSError,ValueError,RuntimeError) as exc:
                profile.town_log('[출석 확인] 화면 검사 보류 · '+str(exc),update_status=False)
            profile.town_log('[화면 순회] 활성화·전체 화면 노출 확인 → 현재 화면 확인',update_status=False)
        def failed(text):
            self.last[index]=time.monotonic();self.due=time.monotonic()+interval
            profile.town_log('[화면 순회] '+text+' · 사냥 종료로 판단하지 않음')
        app.focus_runner.start(handle,success,failed,profile.town_log)
