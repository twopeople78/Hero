"""Read-only Windows game window selection and client-area preview."""
import ctypes as c
from ctypes import wintypes as w
import tkinter as tk
from tkinter import ttk

u = c.WinDLL('user32', use_last_error=True)
g = c.WinDLL('gdi32', use_last_error=True)
CALLBACK = c.WINFUNCTYPE(w.BOOL, w.HWND, w.LPARAM)
u.EnumWindows.argtypes = [CALLBACK, w.LPARAM]
u.GetWindowTextW.argtypes = [w.HWND, w.LPWSTR, c.c_int]
u.GetWindowTextLengthW.argtypes = [w.HWND]
u.IsWindowVisible.argtypes = [w.HWND]
u.IsWindow.argtypes = [w.HWND]
u.IsIconic.argtypes = [w.HWND]
u.GetClientRect.argtypes = [w.HWND, c.POINTER(w.RECT)]
u.ClientToScreen.argtypes = [w.HWND, c.POINTER(w.POINT)]
u.GetDC.argtypes = [w.HWND]
u.GetDC.restype = w.HDC
u.ReleaseDC.argtypes = [w.HWND, w.HDC]
g.CreateCompatibleDC.argtypes = [w.HDC]
g.CreateCompatibleDC.restype = w.HDC
g.CreateCompatibleBitmap.argtypes = [w.HDC, c.c_int, c.c_int]
g.CreateCompatibleBitmap.restype = w.HBITMAP
g.SelectObject.argtypes = [w.HDC, w.HGDIOBJ]
g.SelectObject.restype = w.HGDIOBJ
g.BitBlt.argtypes = [w.HDC, c.c_int, c.c_int, c.c_int, c.c_int, w.HDC, c.c_int, c.c_int, w.DWORD]
g.DeleteObject.argtypes = [w.HGDIOBJ]
g.DeleteDC.argtypes = [w.HDC]

class Header(c.Structure):
    _fields_ = [('size',w.DWORD),('width',w.LONG),('height',w.LONG),('planes',w.WORD),('bits',w.WORD),('compression',w.DWORD),('image_size',w.DWORD),('x',w.LONG),('y',w.LONG),('used',w.DWORD),('important',w.DWORD)]

g.GetDIBits.argtypes = [w.HDC,w.HBITMAP,w.UINT,w.UINT,c.c_void_p,c.c_void_p,w.UINT]

def title(hwnd):
    buf = c.create_unicode_buffer(u.GetWindowTextLengthW(hwnd)+1)
    u.GetWindowTextW(hwnd,buf,len(buf))
    return buf.value

def bounds(hwnd):
    if not u.IsWindow(hwnd):
        raise RuntimeError('게임 창이 닫혔습니다. 다시 연결하세요.')
    if u.IsIconic(hwnd):
        raise RuntimeError('게임 창이 최소화되었습니다. 복원하세요.')
    rect, pt = w.RECT(), w.POINT(0,0)
    if not u.GetClientRect(hwnd,c.byref(rect)) or not u.ClientToScreen(hwnd,c.byref(pt)):
        raise RuntimeError('창 위치를 읽을 수 없습니다.')
    return pt.x,pt.y,rect.right,rect.bottom

def windows():
    found=[]
    @CALLBACK
    def callback(hwnd,_):
        name=title(hwnd)
        if u.IsWindowVisible(hwnd) and name.strip().lower()=='heroofchosunclassic':
            try:
                x,y,width,height=bounds(hwnd)
                found.append((hwnd,f'{name} | 위치 {x},{y} | {width}×{height} | ID {hwnd}'))
            except RuntimeError:
                found.append((hwnd,f'{name} | 최소화 | ID {hwnd}'))
        return True
    u.EnumWindows(callback,0)
    return found

def capture(hwnd):
    from game_actions import check_game_view
    check_game_view(hwnd)
    before=bounds(hwnd)
    x,y,width,height=before
    if width<=0 or height<=0 or width*height>16000000:
        raise RuntimeError('캡처할 수 없는 창 크기입니다.')
    screen=u.GetDC(None)
    dc=g.CreateCompatibleDC(screen)
    bitmap=g.CreateCompatibleBitmap(screen,width,height)
    old=None
    try:
        if not screen or not dc or not bitmap:
            raise RuntimeError('화면 캡처 준비에 실패했습니다.')
        old=g.SelectObject(dc,bitmap)
        if not g.BitBlt(dc,0,0,width,height,screen,x,y,0x00CC0020):
            raise RuntimeError('화면을 읽을 수 없습니다.')
        g.SelectObject(dc,old)
        old=None
        header=Header(c.sizeof(Header),width,-height,1,32,0,0,0,0,0,0)
        raw=c.create_string_buffer(width*height*4)
        if g.GetDIBits(dc,bitmap,0,height,raw,c.byref(header),0)!=height:
            raise RuntimeError('화면 이미지 변환에 실패했습니다.')
        source=raw.raw
        rgb=bytearray(width*height*3)
        rgb[0::3]=source[2::4]
        rgb[1::3]=source[1::4]
        rgb[2::3]=source[0::4]
        check_game_view(hwnd)
        if bounds(hwnd)!=before:raise RuntimeError('캡처 중 창 위치 변경 · 화면 폐기')
        return f'P6\n{width} {height}\n255\n'.encode()+rgb
    finally:
        if old: g.SelectObject(dc,old)
        if bitmap: g.DeleteObject(bitmap)
        if dc: g.DeleteDC(dc)
        if screen: u.ReleaseDC(None,screen)

class WindowLink(ttk.Frame):
    def __init__(self,parent,profile):
        super().__init__(parent)
        self.profile=profile
        self.signature=None
        self.hwnd=None
        self.preview_window=None
        self.choices=[]
        self.job=None
        ttk.Label(self,text='게임 창 연결 · 위치를 보고 해당 캐릭터 창을 선택하세요').pack(anchor='w')
        row=ttk.Frame(self)
        row.pack(fill='x',pady=4)
        self.combo=ttk.Combobox(row,state='readonly',width=52)
        self.combo.pack(side='left',fill='x',expand=True)
        ttk.Button(row,text='목록 새로고침',command=lambda: self.winfo_toplevel().auto_connect()).pack(side='left',padx=4)
        ttk.Button(row,text='연결',command=self.connect).pack(side='left')
        ttk.Button(row,text='화면 확인',command=self.preview).pack(side='left',padx=4)
        self.state=tk.StringVar(value='연결 전 · 실제 클릭과 키 입력은 수행하지 않습니다.')
        ttk.Label(self,textvariable=self.state,wraplength=900).pack(anchor='w')
        self.refresh()
        self.poll()
        self.bind('<Destroy>',self.cleanup)

    def refresh(self):
        self.choices=windows()
        def position(item):
            try:
                return bounds(item[0])[:2]
            except RuntimeError:
                return (100000,100000)
        self.choices.sort(key=position)
        self.combo['values']=[label for _,label in self.choices]
        self.combo.set('')
        if not self.choices:
            self.state.set('실행 중인 게임 창이 없습니다. 게임을 켠 뒤 새로고침하세요.')
            return
        selected=next((i for i,item in enumerate(self.choices) if item[0]==self.hwnd),None)
        if selected is None:
            selected=0
        self.combo.current(selected)
        if self.hwnd:
            self.update_state()
        else:
            side=self.profile.display_name
            self.state.set(f'{len(self.choices)}개 창 검색됨 · {side} 후보 선택됨 · 연결 버튼을 누른 뒤 화면 확인하세요.')

    def connect(self):
        index=self.combo.current()
        if index<0:
            self.state.set('먼저 게임 창을 선택하세요.')
            return
        handle=self.choices[index][0]
        root=self.winfo_toplevel()
        for profile in getattr(root,'profiles',[]):
            link=getattr(profile,'window_link',None)
            if link and link is not self and link.hwnd==handle:
                self.state.set('다른 캐릭터 탭에 이미 연결된 창입니다. 다른 창을 선택하세요.')
                return
        if (root.focus_runner.active or root.work_coordinator.active or root.work_coordinator.pending
                or any(root.work_coordinator.busy(p) for p in root.profiles)
                or self.profile.daily_scheduler.active or root.dual_runner.observing(self.profile)):
            self.state.set('자동화를 정지한 뒤 창 연결을 변경하세요.');return
        from window_identity import identity,authorized
        signature=identity(handle)
        if signature is None:
            self.state.set('게임 프로세스를 확인할 수 없습니다. 관리자 실행·게임 실행 상태를 확인하세요.');return
        self.hwnd=handle;self.signature=signature
        authorized[handle]=signature
        self.update_state()

    def valid(self):
        from window_identity import identity
        return self.signature is not None and identity(self.hwnd)==self.signature

    def update_state(self):
        if self.hwnd:
            try:
                if not self.valid():
                    raise RuntimeError('게임 창을 다시 연결하세요.')
                x,y,width,height=bounds(self.hwnd)
                self.state.set(f'연결됨 · ID {self.hwnd} · 화면 위치 ({x}, {y}) · 내부 크기 {width}×{height}')
            except RuntimeError as exc:
                self.state.set(str(exc))

    def poll(self):
        if self.hwnd and not self.valid():
            app=self.winfo_toplevel();index=app.profiles.index(self.profile)
            app.work_coordinator.cancel_profile(index)
            self.profile.daily_scheduler.stop();self.profile.stop()
            self.hwnd=None;self.signature=None
            self.state.set('기존 게임 창 종료·변경 · 이 계정만 연결 해제. 새 창은 직접 연결하세요.')
        else:self.update_state()
        self.job=self.after(1000,self.poll)

    def preview(self):
        root=self.winfo_toplevel()
        if not self.valid():self.state.set('먼저 이 캐릭터의 게임 창을 직접 연결하세요.');return
        if root.focus_runner.active or root.work_coordinator.active or root.work_coordinator.pending or any(root.work_coordinator.busy(p) for p in root.profiles):
            self.state.set('진행 중인 작업이 끝난 뒤 화면 확인을 누르세요.');return
        handle=self.hwnd
        root.focus_runner.start(handle,lambda:self.show_preview() if self.hwnd==handle and self.valid() else None,
                                self.state.set,self.state.set)

    def show_preview(self):
        if not self.hwnd:
            self.state.set('목록에서 해당 창 선택 → 연결 버튼 → 화면 확인 순서로 진행하세요.')
            return
        try:
            data=capture(self.hwnd)
            image=tk.PhotoImage(data=data,format='PPM',master=self)
            factor=max(1,(image.width()+799)//800,(image.height()+599)//600)
            image=image.subsample(factor)
            if self.preview_window and self.preview_window.winfo_exists():
                self.preview_window.destroy()
            win=tk.Toplevel(self)
            self.preview_window=win
            side=self.profile.display_name
            win.title(f'{side} 캐릭터 · ID {self.hwnd} · 화면 확인')
            ttk.Label(win,text='선택한 게임을 활성화하고 전체 노출을 확인한 뒤 캡처한 정지 이미지입니다.').pack(padx=12,pady=8)
            label=ttk.Label(win,image=image)
            label.image=image
            label.pack(padx=12,pady=8)
        except (RuntimeError,tk.TclError) as exc:
            self.state.set(f'화면 확인 실패: {exc}')

    def cleanup(self,event):
        if event.widget is self and self.job:
            self.after_cancel(self.job)
            self.job=None
