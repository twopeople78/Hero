"""Fit only an out-of-work-area game window, preserving client size and Z order."""
import ctypes as c
from ctypes import wintypes as w
from window_link import u

class MonitorInfo(c.Structure):
    _fields_=[('cbSize',w.DWORD),('monitor',w.RECT),('work',w.RECT),('flags',w.DWORD)]

u.MonitorFromWindow.argtypes=[w.HWND,w.DWORD]
u.MonitorFromWindow.restype=w.HANDLE
u.GetMonitorInfoW.argtypes=[w.HANDLE,c.POINTER(MonitorInfo)]
u.GetMonitorInfoW.restype=w.BOOL

def fitted_position(rect,work):
    left,top,right,bottom=rect
    x0,y0,x1,y1=work
    width,height=right-left,bottom-top
    if width<=0 or height<=0 or width>x1-x0 or height>y1-y0:
        raise RuntimeError('게임 창 전체가 모니터 작업 영역에 들어가지 않습니다. 화면 배율·해상도를 확인하세요.')
    return max(x0,min(left,x1-width)),max(y0,min(top,y1-height))

def ensure_on_screen(hwnd):
    from window_identity import validate
    validate(hwnd)
    rect=w.RECT();info=MonitorInfo();info.cbSize=c.sizeof(info)
    monitor=u.MonitorFromWindow(hwnd,2)
    if not monitor or not u.GetMonitorInfoW(monitor,c.byref(info)) or not u.GetWindowRect(hwnd,c.byref(rect)):
        raise RuntimeError('모니터 작업 영역·창 위치를 확인할 수 없습니다.')
    before=(rect.left,rect.top,rect.right,rect.bottom)
    area=(info.work.left,info.work.top,info.work.right,info.work.bottom)
    x,y=fitted_position(before,area)
    if (x,y)==before[:2]:return None
    # SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE. No permanent topmost change.
    if not u.SetWindowPos(hwnd,None,x,y,0,0,0x0001|0x0004|0x0010):
        raise RuntimeError('화면 밖 게임 창의 위치를 보정하지 못했습니다.')
    return f'화면 밖 창 위치 보정 · {before[:2]} → {(x,y)} · 크기 유지'
