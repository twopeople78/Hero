"""Independent four-character settings. Never import two-character secrets/settings."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SETTINGS = ROOT / 'four_profiles.json'
PROFILE_SPECS = (('char1', '좌상 · 캐릭터1'), ('char2', '우상 · 캐릭터2'),
                 ('char3', '좌하 · 캐릭터3'), ('char4', '우하 · 캐릭터4'))
DESTINATIONS = {'wol': ('월정사 · 대웅전 입구', 'MAP → 전체 → 월정사 → 11. 대웅전 입구 → 이동하기 → AUTO'),
                'ship': ('대한해협 · 왜구 함선1 내부', 'MAP → 전체 → 대한해협 → 07. 왜구 함선1 내부 → 이동하기 → AUTO')}

def read():
    try:
        data = json.loads(SETTINGS.read_text(encoding='utf-8'))
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}

def get(profile_id):
    data = read().get(profile_id, {})
    return data if isinstance(data, dict) else {}

def update(profile_id, **values):
    data = read()
    item = get(profile_id)
    item.update(values)
    data[profile_id] = item
    tmp = SETTINGS.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(SETTINGS)

def load_routes(defaults, profile_id):
    stored = get(profile_id).get('floors', {})
    if not isinstance(stored, dict): stored = {}
    return [(name, str(stored[name])+'층' if type(stored.get(name)) is int and 1 <= stored[name] <= 4 else floor)
            for name, floor in defaults]

def save_routes(routes, profile_id):
    floors = {name: int(floor.replace('층', '')) for name, floor in routes}
    if any(not 1 <= value <= 4 for value in floors.values()): raise ValueError('1~4층만 선택하세요.')
    update(profile_id, floors=floors)
